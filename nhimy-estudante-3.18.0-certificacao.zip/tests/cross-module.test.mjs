import test from "node:test";
import assert from "node:assert/strict";

function makeStorage() {
  return { store: new Map(), getItem(key) { return this.store.get(key) ?? null; }, setItem(key, value) { this.store.set(key, String(value)); }, removeItem(key) { this.store.delete(key); } };
}

globalThis.localStorage = makeStorage();
globalThis.sessionStorage = makeStorage();


globalThis.window = { location: { replace() {} } };

globalThis.document = {};

const organizeStorage = await import("../public/js/core/organize/storage.js");
const tasks = await import("../public/js/core/organize/tasks.js");
const goals = await import("../public/js/core/organize/goals.js");
const events = await import("../public/js/core/organize/events.js");
const organizeSummary = await import("../public/js/core/organize/summary.js");
const workStorage = await import("../public/js/core/work/storage.js");
const workflow = await import("../public/js/core/work/workflow.js");
const homeState = await import("../public/js/core/home/state.js");


test("Home lê o mesmo estado central do Organizar", () => {
  organizeStorage.clearState();
  tasks.createTask({ title: "Revisar matéria", priority: "high" });
  goals.createGoal({ title: "Concluir capítulo" });
  events.createEvent({ title: "Aula", date: "2099-01-02", time: "10:00" });

  const state = homeState.getHomeState();
  const summary = organizeSummary.getOrganizeSummary(new Date());

  assert.equal(state.organize.tasks.length, summary.tasks.length);
  assert.equal(state.organize.goals.length, summary.goals.length);
  assert.equal(state.organize.events.length, summary.events.length);
  assert.equal(state.organizeSummary.pendingTasks, summary.pendingTasks);
  assert.equal(state.organizeSummary.activeGoals.length, summary.activeGoals.length);
});

test("Home usa o workflow central de Trabalhos", () => {
  workStorage.clearProject();
  let project = workStorage.createProject({ title: "Projeto", subject: "Disciplina", type: "Pesquisa" });
  workStorage.setProject(project);
  project = workStorage.saveOrientation(project, { title: "Projeto", orientation: "tema", orientationContext: "Contexto" });
  workStorage.setProject(project);
  project = workStorage.saveStructure(project, [{ id: "intro", title: "Introdução" }]);
  workStorage.setProject(project);

  const state = homeState.getHomeState();
  assert.equal(state.work.current, workflow.getCurrentWorkStage(project));
  assert.equal(state.work.progress, workflow.getWorkProgress(project));
});

import { getStudentState } from "../public/js/core/student/state.js";

test("estado central consolida os módulos sem criar uma segunda fonte de verdade", () => {
  const state = getStudentState();
  assert.equal(state.version, 3);
  assert.ok(state.study && state.work && state.organize);
  assert.equal(typeof state.study.progress, "number");
  assert.equal(typeof state.work.progress, "number");
  assert.equal(typeof state.organize.progress, "number");
  assert.equal(typeof state.generatedAt, "string");
});

const integration = await import("../public/js/core/student/integration.js");
const actions = await import("../public/js/core/student/actions.js");

test("Evolução 2.2 cria plano integrado sem duplicar estado", () => {
  const state = homeState.getHomeState();
  const plan = integration.getIntegrationSummary(state);
  assert.ok(Array.isArray(plan.actions));
  assert.ok(plan.actionCount >= 0);
  if (state.study.active && state.work.active) assert.ok(plan.links.includes("estudar→trabalhos"));
});

test("Evolução 2.2 transforma estudo atual em tarefa usando Organizar", () => {
  organizeStorage.clearState();
  globalThis.sessionStorage.setItem("nhimy.study.session", JSON.stringify({ id: "s1", topic: "Matemática", source: "Álgebra", stage: "preparar" }));
  const task = actions.createTaskFromCurrentStudy();
  assert.ok(task);
  assert.equal(task.category, "Estudar");
  assert.match(task.title, /Matemática/);
  assert.equal(tasks.getTasks().length, 1);
});

test("Evolução 2.2 transforma trabalho atual em tarefa usando Organizar", () => {
  organizeStorage.clearState();
  workStorage.clearProject();
  const project = workStorage.createProject({ title: "Trabalho de Biologia", subject: "Biologia" });
  workStorage.setProject(project);
  const task = actions.createTaskFromCurrentWork();
  assert.ok(task);
  assert.equal(task.category, "Trabalhos");
  assert.match(task.title, /Trabalho de Biologia/);
});

test("Trabalhos oferece ação funcional para enviar o projeto ao Organizar", async () => {
  const fs = await import("node:fs/promises");
  const html = await fs.readFile("public/trabalhos/index.html", "utf8");
  const js = await fs.readFile("public/trabalhos/index.js", "utf8");
  assert.match(html, /id="workIntegration"/);
  assert.match(js, /createTaskFromCurrentWork/);
  assert.match(js, /id="createWorkTask"/);
  assert.match(js, /Tarefa criada/);
});

test("Evolução 2.11 cria rascunho de trabalho a partir do estudo atual", () => {
  organizeStorage.clearState();
  workStorage.clearProject();
  globalThis.sessionStorage.setItem("nhimy.study.session", JSON.stringify({
    id: "study-bridge",
    topic: "Fotossíntese",
    source: "As plantas usam luz para produzir matéria orgânica.",
    prepared: "Conceitos principais: luz, clorofila e produção de glicose.",
    stage: "compreender"
  }));
  const project = actions.createWorkFromCurrentStudy();
  assert.ok(project);
  assert.equal(project.title, "Fotossíntese");
  assert.equal(project.subject, "A definir");
  assert.equal(project.orientationReady, false);
  assert.equal(project.orientationContext, "Conceitos principais: luz, clorofila e produção de glicose.");
  assert.equal(workStorage.getProject().id, project.id);
  assert.equal(workflow.getCurrentWorkStage(project), "orientar");
});

test("Evolução 2.11 não sobrescreve trabalho existente ao usar estudo como ponte", () => {
  workStorage.clearProject();
  globalThis.sessionStorage.setItem("nhimy.study.session", JSON.stringify({ id: "study-2", topic: "Matemática", stage: "preparar" }));
  const existing = workStorage.createProject({ title: "Trabalho existente", subject: "Biologia" });
  workStorage.setProject(existing);
  assert.equal(actions.createWorkFromCurrentStudy(), null);
  assert.equal(workStorage.getProject().title, "Trabalho existente");
});

test("Evolução 2.11 oferece ponte Estudar→Trabalhos no plano integrado", () => {
  workStorage.clearProject();
  globalThis.sessionStorage.setItem("nhimy.study.session", JSON.stringify({ id: "study-3", topic: "Química", stage: "preparar" }));
  const state = homeState.getHomeState();
  const plan = integration.getIntegrationSummary(state);
  assert.ok(plan.actions.some(action => action.id === "study-to-work"));
  assert.equal(plan.actions.find(action => action.id === "study-to-work")?.href, "/trabalhos/criar/");
});
