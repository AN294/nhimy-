import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const serverSource = await readFile(new URL("../server.js", import.meta.url), "utf8");

 test("3.17 exige origem configurada em produção", () => {
  assert.match(serverSource, /NHIMY_APP_ORIGIN/);
  assert.match(serverSource, /NODE_ENV === "production"/);
  assert.match(serverSource, /Origem não autorizada/);
});

test("3.17 usa cookie __Host- seguro em produção", () => {
  assert.match(serverSource, /__Host-nhimy_session/);
  assert.match(serverSource, /Secure/);
  assert.match(serverSource, /HttpOnly/);
  assert.match(serverSource, /SameSite=Lax/);
});

test("3.17 permite trust proxy somente por configuração explícita", () => {
  assert.match(serverSource, /NHIMY_TRUST_PROXY === "1"/);
  assert.doesNotMatch(serverSource, /app\.set\("trust proxy", true\)/);
});

test("3.17 health verifica PostgreSQL quando o backend está ativo", () => {
  assert.match(serverSource, /postgresPool\.query\("SELECT 1"\)/);
  assert.match(serverSource, /status: "degraded"/);
  assert.match(serverSource, /res\.status\(503\)/);
});

test("3.17 encerra servidor e pool PostgreSQL de forma controlada", () => {
  assert.match(serverSource, /server\.close/);
  assert.match(serverSource, /postgresPool\.end/);
  assert.match(serverSource, /SIGTERM/);
  assert.match(serverSource, /SIGINT/);
});
