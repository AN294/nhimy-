import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

const repository = await fs.readFile("public/js/core/persistence/repository.js", "utf8");
const adapter = await fs.readFile("public/js/core/persistence/file-repository.js", "utf8");
const server = await fs.readFile("server.js", "utf8");
const migration = await fs.readFile("migrations/001-initial-postgres.sql", "utf8");

 test("3.12 define contrato mínimo de persistência", () => {
  assert.match(repository, /REQUIRED_METHODS/);
  assert.match(repository, /getUserData/);
  assert.match(repository, /replaceUserData/);
  assert.match(repository, /validateRepository/);
});

test("3.12 adapter atual preserva o armazenamento já existente", () => {
  assert.match(adapter, /from "\.\.\/account\/server\.js"/);
  assert.match(adapter, /validateRepository/);
  assert.match(adapter, /fileRepository/);
});

test("3.12 servidor usa a abstração de persistência", () => {
  assert.match(server, /fileRepository/);
  assert.match(server, /const dataRepository = fileRepository/);
  assert.match(server, /dataRepository\.getUserData\(user\.id\)/);
  assert.match(server, /dataRepository\.replaceUserData\(user\.id/);
  assert.doesNotMatch(server, /import \{ getUserData, replaceUserData \} from/);
});

test("3.12 esquema futuro mantém propriedade por utilizador", () => {
  assert.match(migration, /CREATE TABLE IF NOT EXISTS users/);
  assert.match(migration, /CREATE TABLE IF NOT EXISTS sessions/);
  assert.match(migration, /CREATE TABLE IF NOT EXISTS account_data/);
  assert.match(migration, /user_id UUID PRIMARY KEY REFERENCES users\(id\) ON DELETE CASCADE/);
  assert.match(migration, /token_hash CHAR\(64\)/);
  assert.match(migration, /password_hash TEXT/);
});
