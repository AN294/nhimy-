import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

const server = await fs.readFile("server.js", "utf8");
const sync = await fs.readFile("public/js/core/account/sync.js", "utf8");
const nav = await fs.readFile("public/js/ui/navigation.js", "utf8");

test("3.11 endpoints de dados exigem utilizador derivado da sessão", () => {
  assert.match(server, /async function requireUser\(req, res\)/);
  assert.match(server, /getUserBySession\(getSessionToken\(req\)\)/);
  assert.match(server, /app\.get\("\/api\/me\/data"/);
  assert.match(server, /app\.put\("\/api\/me\/data"/);
});

test("3.11 nunca aceita userId do pedido para escolher o proprietário", () => {
  assert.doesNotMatch(server, /req\.body\??\.userId/);
  assert.match(server, /getUserData\(user\.id\)/);
  assert.match(server, /replaceUserData\(user\.id/);
});

test("3.11 sincronização usa a sessão autenticada e não um id enviado pelo cliente", () => {
  assert.match(sync, /getCurrentUser\(\)/);
  assert.match(sync, /getAccountData\(\)/);
  assert.match(sync, /saveAccountData\(local\)/);
  assert.doesNotMatch(sync, /userId\s*:\s*local/);
});

test("3.11 sincronização é ligada ao ciclo de estado e autenticação", () => {
  assert.match(sync, /onStateChange/);
  assert.match(sync, /nhimy:auth-change/);
  assert.match(nav, /initAccountSync\(\)/);
});
