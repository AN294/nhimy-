import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

test("3.18 administração exige papel admin e não expõe credenciais", async () => {
  const source = await readFile("routes/admin.js", "utf8");
  assert.match(source, /user\.role !== "admin"/);
  assert.match(source, /403/);
  assert.doesNotMatch(source, /password_hash/);
});

test("3.18 migração administrativa é não destrutiva", async () => {
  const migration = await readFile("migrations/004-admin-role.sql", "utf8");
  assert.match(migration, /ADD COLUMN IF NOT EXISTS role/);
  assert.doesNotMatch(migration, /DROP TABLE|DROP COLUMN/i);
});

test("3.18 painel não promete receita sem fornecedor real", async () => {
  const html = await readFile("public/admin/index.html", "utf8");
  assert.match(html, /preparado, não ativado/);
  assert.match(html, /não inventa|não.*receita|fornecedor/i);
});

test("3.18 promoção administrativa é explícita por configuração do servidor", async () => {
  const server = await readFile("server.js", "utf8");
  assert.match(server, /NHIMY_ADMIN_EMAILS/);
  assert.match(server, /UPDATE users SET role/);
});
