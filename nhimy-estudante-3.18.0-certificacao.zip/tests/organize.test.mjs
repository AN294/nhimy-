import test from "node:test";
import assert from "node:assert/strict";

function makeStorage() {
  return { store: new Map(), getItem(key) { return this.store.get(key) ?? null; }, setItem(key, value) { this.store.set(key, String(value)); }, removeItem(key) { this.store.delete(key); } };
}

globalThis.localStorage = makeStorage();
globalThis.sessionStorage = makeStorage();

const storage = await import("../public/js/core/organize/storage.js");
const tasks = await import("../public/js/core/organize/tasks.js");
const goals = await import("../public/js/core/organize/goals.js");
const events = await import("../public/js/core/organize/events.js");
const summary = await import("../public/js/core/organize/summary.js");

test("estado de organizar usa persistência e mantém as coleções", () => {
  storage.clearState();
  tasks.createTask({ title: "Estudar", dueDate: "2099-01-01", priority: "high" });
  goals.createGoal({ title: "Concluir semestre" });
  events.createEvent({ title: "Prova", date: "2099-01-02", time: "10:00" });
  assert.equal(storage.getState().version, 2);
  assert.equal(tasks.getTasks().length, 1);
  assert.equal(goals.getGoals().length, 1);
  assert.equal(events.getEvents().length, 1);
  assert.equal(localStorage.getItem(storage.KEY) !== null, true);
});

test("estado legado em sessionStorage é migrado", () => {
  storage.clearState();
  sessionStorage.setItem(storage.KEY, JSON.stringify({ tasks: [{ id: "legacy", title: "Legado" }] }));
  const state = storage.getState();
  assert.equal(state.tasks.length, 1);
  assert.equal(state.tasks[0].id, "legacy");
  assert.equal(localStorage.getItem(storage.KEY) !== null, true);
});

test("summary identifica tarefas prioritárias e atrasadas", () => {
  storage.clearState();
  tasks.createTask({ title: "Atrasada", dueDate: "2020-01-01", priority: "high" });
  tasks.createTask({ title: "Futuro", dueDate: "2099-01-01", priority: "high" });
  const result = summary.getOrganizeSummary(new Date("2026-09-02T10:00:00"));
  assert.equal(result.overdueTasks.length, 1);
  assert.equal(result.highPriority.length, 2);
  assert.equal(result.pendingTasks, 2);
});
