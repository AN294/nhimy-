import test from "node:test";
import assert from "node:assert/strict";

function makeStorage() {
  return {
    store: new Map(),
    getItem(key) { return this.store.get(key) ?? null; },
    setItem(key, value) { this.store.set(key, String(value)); },
    removeItem(key) { this.store.delete(key); }
  };
}

globalThis.localStorage = makeStorage();
globalThis.sessionStorage = makeStorage();

const storage = await import("../public/js/core/organize/storage.js");
const tasks = await import("../public/js/core/organize/tasks.js");
const goals = await import("../public/js/core/organize/goals.js");
const notes = await import("../public/js/core/organize/notes.js");
const events = await import("../public/js/core/organize/events.js");
const summary = await import("../public/js/core/organize/summary.js");

test("Organizar CRUD mantém tarefas, metas, notas e agenda no estado central", () => {
  storage.clearState();

  const task = tasks.createTask({ title: "Estudar capítulo 5", dueDate: "2026-09-04", priority: "high" });
  const goal = goals.createGoal({ title: "Concluir revisão", description: "Revisar antes da prova", targetDate: "2026-09-10" });
  const note = notes.createNote({ title: "Lembrete", content: "Revisar conceitos principais" });
  const event = events.createEvent({ title: "Sessão de estudo", date: "2026-09-04", time: "18:00" });

  assert.ok(task?.id);
  assert.ok(goal?.id);
  assert.ok(note?.id);
  assert.ok(event?.id);
  assert.equal(storage.getState().tasks.length, 1);
  assert.equal(storage.getState().goals.length, 1);
  assert.equal(storage.getState().notes.length, 1);
  assert.equal(storage.getState().events.length, 1);
});

test("Organizar permite editar, concluir e excluir cada tipo de item", () => {
  storage.clearState();

  const task = tasks.createTask({ title: "Tarefa" });
  const goal = goals.createGoal({ title: "Meta" });
  const note = notes.createNote({ title: "Nota", content: "Conteúdo" });
  const event = events.createEvent({ title: "Evento", date: "2026-09-05" });

  assert.equal(tasks.updateTask(task.id, { title: "Tarefa atualizada", priority: "high" }).title, "Tarefa atualizada");
  assert.equal(tasks.toggleTask(task.id).completed, true);
  assert.equal(tasks.deleteTask(task.id), true);

  assert.equal(goals.updateGoal(goal.id, { title: "Meta atualizada" }).title, "Meta atualizada");
  assert.equal(goals.toggleGoal(goal.id).completed, true);
  assert.equal(goals.deleteGoal(goal.id), true);

  assert.equal(notes.updateNote(note.id, { title: "Nota atualizada", content: "Novo conteúdo" }).title, "Nota atualizada");
  assert.equal(notes.deleteNote(note.id), true);

  assert.equal(events.updateEvent(event.id, { title: "Evento atualizado", time: "09:30" }).time, "09:30");
  assert.equal(events.toggleEvent(event.id).completed, true);
  assert.equal(events.deleteEvent(event.id), true);

  assert.deepEqual(storage.getState().tasks, []);
  assert.deepEqual(storage.getState().goals, []);
  assert.deepEqual(storage.getState().notes, []);
  assert.deepEqual(storage.getState().events, []);
});

test("Resumo do Organizar integra pendências, prioridades, agenda, notas e progresso", () => {
  storage.clearState();

  tasks.createTask({ title: "Atrasada", dueDate: "2026-09-02", priority: "high" });
  tasks.createTask({ title: "Hoje", dueDate: "2026-09-03", priority: "medium" });
  const done = tasks.createTask({ title: "Concluída" });
  tasks.toggleTask(done.id);
  goals.createGoal({ title: "Meta ativa" });
  const completedGoal = goals.createGoal({ title: "Meta concluída" });
  goals.toggleGoal(completedGoal.id);
  notes.createNote({ title: "Nota recente", content: "Importante" });
  events.createEvent({ title: "Evento hoje", date: "2026-09-03", time: "20:00" });

  const result = summary.getOrganizeSummary(new Date("2026-09-03T10:00:00"));

  assert.equal(result.pendingTasks, 2);
  assert.equal(result.overdueTasks.length, 1);
  assert.equal(result.todayTasks.length, 1);
  assert.equal(result.highPriority.length, 1);
  assert.equal(result.activeGoals.length, 1);
  assert.equal(result.completedGoals, 1);
  assert.equal(result.todayEvents.length, 1);
  assert.equal(result.recentNotes.length, 1);
  assert.equal(result.taskCompletion, 33);
  assert.equal(result.progress, 40);
  assert.equal(result.hasFocus, true);
});
