import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

const PUBLIC = path.resolve("public");

function localTargetExists(url) {
  const clean = url.split("#")[0].split("?")[0];
  if (!clean.startsWith("/") || clean.startsWith("//") || clean.startsWith("/api/")) return true;
  if (clean === "/") return fs.existsSync(path.join(PUBLIC, "index.html"));
  const relative = clean.slice(1);
  if (clean.endsWith("/")) return fs.existsSync(path.join(PUBLIC, relative, "index.html"));
  return fs.existsSync(path.join(PUBLIC, relative));
}

test("HTMLs não contêm atributos duplicados", () => {
  const htmlFiles = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.endsWith(".html")) htmlFiles.push(full);
    }
  }
  walk(PUBLIC);

  const duplicates = [];
  const tagPattern = /<([a-z][^>]*?)>/gi;
  for (const file of htmlFiles) {
    const html = fs.readFileSync(file, "utf8");
    for (const match of html.matchAll(tagPattern)) {
      const attrs = [...match[1].matchAll(/\s([a-zA-Z_:][\w:.-]*)\s*=/g)].map(m => m[1].toLowerCase());
      const seen = new Set();
      for (const attr of attrs) {
        if (seen.has(attr)) duplicates.push(`${path.relative(process.cwd(), file)} -> ${attr}`);
        seen.add(attr);
      }
    }
  }
  assert.deepEqual(duplicates, []);
});

test("referências locais dos HTMLs apontam para recursos existentes", () => {
  const htmlFiles = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.endsWith(".html")) htmlFiles.push(full);
    }
  }
  walk(PUBLIC);

  const missing = [];
  const pattern = /(?:href|src)="([^"]+)"/g;
  for (const file of htmlFiles) {
    const html = fs.readFileSync(file, "utf8");
    for (const match of html.matchAll(pattern)) {
      if (!localTargetExists(match[1])) missing.push(`${path.relative(process.cwd(), file)} -> ${match[1]}`);
    }
  }
  assert.deepEqual(missing, []);
});

test("módulos de estudo não acessam sessionStorage diretamente pela interface", () => {
  const files = [
    "public/estudar/flashcards/app.js",
    "public/estudar/quiz/app.js",
    "public/estudar/revisar/app.js"
  ];
  const violations = files.filter(file => /sessionStorage\s*\./.test(fs.readFileSync(file, "utf8")));
  assert.deepEqual(violations, []);
});

test("server.js contém limites básicos para entrada JSON", () => {
  const server = fs.readFileSync("server.js", "utf8");
  assert.match(server, /express\.json\(\{\s*limit:\s*["']100kb["']/s);
  assert.match(server, /X-Content-Type-Options/);
  assert.match(server, /X-Frame-Options/);
  assert.match(server, /Referrer-Policy/);
  assert.match(server, /Permissions-Policy/);
});

import { validateResearchRequest } from "../public/js/core/work/research/service.js";

test("Research request aplica limites de superfície", () => {
  const questions = Array.from({ length: 21 }, (_, i) => `Pergunta ${i + 1}`);
  const result = validateResearchRequest({
    type: "work-research-request",
    topic: "Tema",
    questions
  });
  assert.equal(result.valid, false);
  assert.match(result.error, /20/);
});

test("server mantém CSP e políticas básicas de segurança", () => {
  const source = fs.readFileSync(path.resolve("server.js"), "utf8");
  assert.match(source, /Content-Security-Policy/);
  assert.match(source, /frame-ancestors/);
});

test("Ferramentas usa o runtime modular único", () => {
  const html = fs.readFileSync("public/ferramentas/index.html", "utf8");
  assert.match(html, /<script type="module" src="\/js\/core\/app\.js"><\/script>/);
  assert.doesNotMatch(html, /<script src="\/app\.js"><\/script>/);
});

test("Páginas de estudo não dependem de estilos inline bloqueados pela CSP", () => {
  const files = [
    "public/estudar/index.html",
    "public/estudar/preparar/index.html",
    "public/estudar/compreender/index.html",
    "public/estudar/praticar/index.html"
  ];
  const violations = files.filter(file => /\sstyle="/i.test(fs.readFileSync(file, "utf8")));
  assert.deepEqual(violations, []);
});

test("Etapas visuais da jornada de Estudar estão numeradas de forma coerente", () => {
  const expected = {
    "public/estudar/preparar/index.html": "Etapa 2 de 6",
    "public/estudar/compreender/index.html": "Etapa 3 de 6",
    "public/estudar/praticar/index.html": "Etapa 5 de 6"
  };
  for (const [file, label] of Object.entries(expected)) {
    assert.match(fs.readFileSync(file, "utf8"), new RegExp(label));
  }
});

test("âncoras locais dos HTMLs apontam para IDs existentes", () => {
  const htmlFiles = [];
  function walk(dir) {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else if (entry.name.endsWith(".html")) htmlFiles.push(full);
    }
  }
  walk(PUBLIC);

  const missing = [];
  for (const file of htmlFiles) {
    const html = fs.readFileSync(file, "utf8");
    for (const match of html.matchAll(/href="#([^\"]+)"/g)) {
      if (!new RegExp(`id=["']${match[1].replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}["']`).test(html)) {
        missing.push(`${path.relative(process.cwd(), file)} -> #${match[1]}`);
      }
    }
  }
  assert.deepEqual(missing, []);
});

test("menu mobile tem comportamento implementado", () => {
  const navigation = fs.readFileSync("public/js/ui/navigation.js", "utf8");
  const header = fs.readFileSync("public/css/layout/header.css", "utf8");
  assert.match(navigation, /menu-button/);
  assert.match(navigation, /aria-expanded/);
  assert.match(navigation, /is-open/);
  assert.match(header, /\.desktop-nav\.is-open/);
});

test("Home aponta atalhos rápidos para âncoras reais das Ferramentas", () => {
  const home = fs.readFileSync("public/index.html", "utf8");
  const tools = fs.readFileSync("public/ferramentas/index.html", "utf8");
  for (const id of ["tool-pdf", "tool-converter", "tool-texto", "tool-imagem"]) {
    assert.match(home, new RegExp(`/ferramentas/#${id}`));
    assert.match(tools, new RegExp(`id=["']${id}["']`));
  }
});
