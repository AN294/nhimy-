import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

test("3.18 painel administrativo expõe métricas agregadas úteis sem enviar dados de conta", async () => {
  const route = await readFile("routes/admin.js", "utf8");
  const app = await readFile("public/admin/app.js", "utf8");
  for (const token of ["study_practiced", "study_measured", "work_finalized", "completed_tasks", "library_items", "last_data_update"]) assert.match(route, new RegExp(token));
  assert.doesNotMatch(route, /SELECT[\\s\\S]*profile[\\s\\S]*FROM account_data/);
  for (const token of ["Estudar — praticaram", "Trabalhos — finalizados", "Tarefas", "Biblioteca"]) assert.match(app, new RegExp(token));
});
