const root = process.cwd();
import path from "node:path";
import fs from "node:fs";
import test from 'node:test';import assert from 'node:assert/strict';
function makeStorage(){return{store:new Map(),getItem(k){return this.store.get(k)??null},setItem(k,v){this.store.set(k,String(v))},removeItem(k){this.store.delete(k)}}}
globalThis.localStorage=makeStorage();
globalThis.sessionStorage=makeStorage();
const profile=await import('../public/js/core/student/profile.js');
test('Perfil guarda e normaliza dados',()=>{profile.clearProfile();assert.equal(profile.setProfile({name:'  Ana  ',course:'Enfermagem',institution:'Instituto X'}),true);const p=profile.getProfile();assert.equal(p.name,'Ana');assert.equal(p.course,'Enfermagem');assert.equal(p.institution,'Instituto X');assert.equal(p.version,1)});
test('Perfil aplica limites e limpeza',()=>{profile.setProfile({name:'x'.repeat(200),course:'y'.repeat(200),institution:'z'.repeat(300)});const p=profile.getProfile();assert.equal(p.name.length,80);assert.equal(p.course.length,120);assert.equal(p.institution.length,160);profile.clearProfile();assert.deepEqual(profile.getProfile(),{version:1,name:'',course:'',institution:''})});
test('Perfil não é exposto como bloco extra na Home',async()=>{const fs=await import('node:fs/promises');const home=await fs.readFile('public/index.html','utf8');assert.doesNotMatch(home,/class="home-area-card[^>]*>[^<]*.*Perfil/);assert.match(home,/href="\/estudar\//)});
test('Página de Perfil usa armazenamento próprio',async()=>{const fs=await import('node:fs/promises');const html=await fs.readFile('public/perfil/index.html','utf8');const js=await fs.readFile('public/perfil/app.js','utf8');assert.match(html,/id="profileForm"/);assert.match(js,/getProfile/);assert.match(js,/setProfile/)});

test('Sessão do estudante preserva contexto sem autenticação',async()=>{
  const session=await import('../public/js/core/student/session.js');
  session.clearSession();
  assert.equal(session.touch('estudar','/estudar/preparar/'),true);
  const s=session.getSession();
  assert.equal(s.module,'estudar');
  assert.equal(s.route,'/estudar/preparar/');
  assert.ok(s.startedAt);
  assert.ok(s.lastActiveAt);
  session.clearSession();
  assert.equal(session.getSession().module,'');
});

test('Estado central inclui perfil e sessão sem criar blocos de Home',async()=>{
  const fs=await import('node:fs/promises');
  const state=await import('../public/js/core/student/state.js');
  const s=state.getStudentState();
  assert.ok('profile' in s);
  assert.ok('session' in s);
  const home=await fs.readFile('public/index.html','utf8');
  assert.doesNotMatch(home,/session|lastActiveAt|startedAt/i);
});


test("Perfil respeita CSP sem CSS inline", () => {
  const html = fs.readFileSync(path.join(root, "public/perfil/index.html"), "utf8");
  assert.doesNotMatch(html, /<style\b/i);
  assert.match(html, /href=["']\/perfil\/style\.css["']/);
});
