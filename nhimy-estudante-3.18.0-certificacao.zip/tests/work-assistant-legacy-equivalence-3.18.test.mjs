import test from "node:test";
import assert from "node:assert/strict";
import { buildWritingGuide, buildSectionDraft } from "../public/js/core/work/assistant.js";

test("assistant preserva associação semântica de evidências do desenvolvimento histórico", () => {
  const project = {
    title: "Tema",
    subject: "Disciplina",
    research: { findings: [
      { section: "Fatores relacionados", question: "Quais fatores estão relacionados?", text: "Evidência A", sourceIds: ["SRC-1"], sources: [{ title: "Fonte A" }] },
      { section: "Introdução", question: "O que é o tema?", text: "Evidência B", sourceIds: ["SRC-2"], sources: [{ title: "Fonte B" }] }
    ]},
    structure: [{ id: "s1", title: "Fatores relacionados", purpose: "Analisar fatores." }],
    content: {}
  };
  const guide = buildWritingGuide(project, 0);
  assert.equal(guide.evidence.length, 1);
  assert.equal(guide.evidence[0].sourceIds[0], "SRC-1");
  assert.match(buildSectionDraft(project, 0), /Evidência A/);
});
