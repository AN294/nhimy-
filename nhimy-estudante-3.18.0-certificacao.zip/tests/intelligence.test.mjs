import test from "node:test";
import assert from "node:assert/strict";

const intelligence = await import("../public/js/core/student/intelligence.js");

function state(overrides = {}) {
  return {
    study: { active: false, progress: 0, current: "conteudo", session: null },
    work: { active: false, progress: 0, current: "criar", project: null, title: "" },
    organize: { tasks: [], activeGoals: [] },
    ...overrides
  };
}

test("Evolução 2.3 escolhe uma próxima ação transparente", () => {
  const result = intelligence.getJourneyIntelligence(state());
  assert.equal(result.version, 1);
  assert.equal(result.mode, "open");
  assert.equal(result.principle, "orientar-sem-pressionar");
  assert.equal(result.primary.id, "journey-start");
  assert.ok(result.primary.reason.length > 0);
});

test("Evolução 2.3 prioriza pendência atrasada sobre ação genérica", () => {
  const result = intelligence.getJourneyIntelligence(state({
    study: { active: true, progress: 40, current: "compreender", session: { topic: "Biologia" } },
    organize: { tasks: [{ title: "Entrega", dueDate: "2020-01-01", priority: "medium", completed: false }], activeGoals: [] }
  }), new Date("2026-09-02T10:00:00"));
  assert.equal(result.primary.id, "journey-overdue-task");
  assert.match(result.primary.text, /prazo|atras/i);
});

test("Evolução 2.3 entende bloqueio de trabalho como próxima etapa", () => {
  const project = { title: "Trabalho de História", subject: "História", orientationReady: false, structure: [], content: {}, reviewed: false, finalized: false };
  const result = intelligence.getJourneyIntelligence(state({
    work: { active: true, progress: 17, current: "orientar", project, title: project.title }
  }));
  assert.equal(result.primary.id, "journey-work-blocker");
  assert.equal(result.primary.href, "/trabalhos/orientar/");
});

test("Evolução 2.3 oferece alternativas sem criar novo estado", () => {
  const result = intelligence.getJourneyIntelligence(state({
    study: { active: true, progress: 40, current: "compreender", session: { topic: "Química" } },
    organize: { tasks: [{ title: "Revisar exercício", priority: "high", completed: false }], activeGoals: [] }
  }));
  assert.ok(result.primary);
  assert.ok(Array.isArray(result.alternatives));
  assert.ok(Array.isArray(result.candidates));
  assert.equal(result.candidates[0].rank, 1);
});

test("Home mantém o plano de ação enxuto", async () => {
  const fs = await import("node:fs/promises");
  const home = await fs.readFile("public/js/core/home/index.js", "utf8");
  assert.doesNotMatch(home, /ensureLibraryAction/);
  assert.doesNotMatch(home, /data-create=/);
  assert.doesNotMatch(home, /getIntegratedActions/);
  assert.match(home, /journey-primary/);
  assert.match(home, /journey-alternatives/);
});
