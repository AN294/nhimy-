import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const dir = await fs.mkdtemp(path.join(os.tmpdir(), "nhimy-auth-test-"));
process.env.NHIMY_AUTH_DIR = dir;
const auth = await import("../public/js/core/auth/server.js");

test("autenticação cria conta, autentica e não expõe a palavra-passe", async () => {
  const user = await auth.registerUser({ email: "Aluno@Example.COM", password: "Senha-forte-123", name: "Aluno" });
  assert.equal(user.email, "aluno@example.com");
  assert.equal(user.name, "Aluno");
  assert.equal("passwordHash" in user, false);
  assert.equal((await auth.authenticateUser({ email: "aluno@example.com", password: "Senha-forte-123" }))?.id, user.id);
  assert.equal(await auth.authenticateUser({ email: "aluno@example.com", password: "errada-123" }), null);
});

test("autenticação impede e-mail duplicado e valida credenciais", async () => {
  await assert.rejects(() => auth.registerUser({ email: "ALUNO@example.com", password: "Outra-123" }), /Já existe/);
  await assert.rejects(() => auth.registerUser({ email: "sem-email", password: "Outra-123" }), /e-mail válido/);
  await assert.rejects(() => auth.registerUser({ email: "novo@example.com", password: "curta" }), /entre 8 e 128/);
});

test("sessão usa token opaco, expira no servidor e pode ser destruída", async () => {
  const user = await auth.authenticateUser({ email: "aluno@example.com", password: "Senha-forte-123" });
  const token = await auth.createSession(user.id);
  assert.ok(token.length >= 40);
  const store = JSON.parse(await fs.readFile(path.join(dir, "auth.json"), "utf8"));
  assert.equal(store.sessions[0].tokenHash.length, 64);
  assert.notEqual(store.sessions[0].tokenHash, token);
  assert.equal((await auth.getUserBySession(token))?.id, user.id);
  await auth.destroySession(token);
  assert.equal(await auth.getUserBySession(token), null);
});

test("criação de nova sessão invalida a anterior do mesmo usuário", async () => {
  const user = await auth.authenticateUser({ email: "aluno@example.com", password: "Senha-forte-123" });
  const first = await auth.createSession(user.id);
  const second = await auth.createSession(user.id);
  assert.equal(await auth.getUserBySession(first), null);
  assert.equal((await auth.getUserBySession(second))?.id, user.id);
});

test("página de entrada usa controles de senha adequados", async () => {
  const html = await fs.readFile("public/entrar/index.html", "utf8");
  assert.match(html, /autocomplete="current-password"/);
  assert.match(html, /autocomplete="new-password"/);
  assert.match(html, /maxlength="128"/);
});

test("servidor expõe endpoints de autenticação e cookie protegido", async () => {
  const server = await fs.readFile("server.js", "utf8");
  assert.match(server, /\/api\/auth\/register/);
  assert.match(server, /\/api\/auth\/login/);
  assert.match(server, /\/api\/auth\/me/);
  assert.match(server, /\/api\/auth\/logout/);
  assert.match(server, /HttpOnly/);
  assert.match(server, /SameSite=Lax/);
  assert.match(server, /Secure/);
  assert.match(server, /Origin/);
});
