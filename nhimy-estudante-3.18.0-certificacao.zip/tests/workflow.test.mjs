import test from "node:test";
import assert from "node:assert/strict";

globalThis.sessionStorage = {
  store: new Map(),
  getItem(key) { return this.store.get(key) ?? null; },
  setItem(key, value) { this.store.set(key, String(value)); },
  removeItem(key) { this.store.delete(key); }
};

const storage = await import("../public/js/core/work/storage.js");
const workflow = await import("../public/js/core/work/workflow.js");

function projectReadyToReview() {
  let project = storage.createProject({ title: "Tema", subject: "Disciplina", type: "Pesquisa", orientation: "tema" });
  project = storage.saveOrientation(project, {
    title: "Tema", orientation: "tema", orientationContext: "Objetivo",
    researchStatus: "partial", research: { readyForStructure: false }
  });
  project = storage.saveStructure(project, [
    { title: "Introdução", purpose: "Contexto" },
    { title: "Desenvolvimento", purpose: "Conteúdo" }
  ]);
  project = storage.saveSectionContent(project, project.structure[0].id, "Texto da introdução com conteúdo suficiente para a etapa.");
  project = storage.saveSectionContent(project, project.structure[1].id, "Texto do desenvolvimento com conteúdo suficiente para a etapa.");
  return project;
}

test("workflow deriva a etapa correta sem depender da página", () => {
  let project = storage.createProject({ title: "Tema", subject: "Disciplina", type: "Pesquisa" });
  assert.equal(workflow.getCurrentWorkStage(project), "orientar");
  project = storage.saveOrientation(project, { title: "Tema", orientation: "tema", orientationContext: "" });
  assert.equal(workflow.getCurrentWorkStage(project), "estruturar");
  project = storage.saveStructure(project, [{ title: "Introdução" }]);
  assert.equal(workflow.getCurrentWorkStage(project), "desenvolver");
});

test("alterar conteúdo invalida revisão e finalização", () => {
  let project = projectReadyToReview();
  project = storage.saveReview(project, {}, { issues: [], completion: 100 }, true);
  project = storage.finalizeProject(project);
  assert.equal(project.finalized, true);
  project = storage.saveSectionContent(project, project.structure[0].id, "Conteúdo alterado depois da finalização.");
  assert.equal(project.reviewed, false);
  assert.equal(project.finalized, false);
  assert.equal(project.finalVersion, null);
});

test("alterar orientação invalida estrutura e conteúdo dependentes", () => {
  let project = projectReadyToReview();
  const changed = storage.saveOrientation(project, {
    title: "Tema", orientation: "instrucoes", orientationContext: "Nova instrução",
    researchStatus: "partial", research: { readyForStructure: false }
  });
  assert.equal(changed.orientationReady, true);
  assert.deepEqual(changed.structure, []);
  assert.deepEqual(changed.content, {});
  assert.equal(workflow.getCurrentWorkStage(changed), "estruturar");
});

test("progresso chega a 100% somente após finalização", () => {
  let project = projectReadyToReview();
  assert.equal(workflow.getWorkProgress(project), 67);
  project = storage.saveReview(project, {}, { issues: [], completion: 100 }, true);
  assert.equal(workflow.getWorkProgress(project), 83);
  project = storage.finalizeProject(project);
  assert.equal(workflow.getWorkProgress(project), 100);
});
