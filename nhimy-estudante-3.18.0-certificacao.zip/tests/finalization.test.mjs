import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();

test("Finalização oferece exportação PDF por impressão do navegador", () => {
  const html = fs.readFileSync(path.join(root, "public/trabalhos/finalizar/index.html"), "utf8");
  const app = fs.readFileSync(path.join(root, "public/trabalhos/finalizar/app.js"), "utf8");
  const css = fs.readFileSync(path.join(root, "public/trabalhos/finalizar/finalizar.css"), "utf8");
  assert.match(html, /id="printButton"[^>]*>Exportar PDF<\/button>/);
  assert.match(app, /printButton\?\.addEventListener\(\x27click\x27,\(\)=>window\.print\(\)\)/);
  assert.match(css, /@media print/);
  assert.match(css, /work-final-actions/);
});

test("Navegação atualiza o contexto da sessão do estudante", () => {
  const nav = fs.readFileSync(path.join(root, "public/js/ui/navigation.js"), "utf8");
  assert.match(nav, /student\/session\.js/);
  assert.match(nav, /touch\(/);
});
