import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

const dir = await fs.mkdtemp(path.join(os.tmpdir(), "nhimy-account-data-test-"));
process.env.NHIMY_DATA_DIR = dir;
const data = await import("../public/js/core/account/server.js");

const userA = "user-a-123";
const userB = "user-b-456";

test("dados de conta começam isolados por utilizador", async () => {
  const first = await data.getUserData(userA);
  const second = await data.getUserData(userB);
  assert.equal(first.hasData, false);
  assert.equal(second.hasData, false);
});

test("guardar dados associa-os ao utilizador autenticado e preserva coleções", async () => {
  const saved = await data.replaceUserData(userA, {
    profile: { name: "Aluno A" },
    study: { id: "study-1", topic: "Biologia" },
    work: { id: "work-1", title: "Trabalho A" },
    organize: { tasks: [{ id: "task-1", title: "Estudar" }] },
    library: { items: [{ id: "lib-1", title: "Resumo" }] }
  });
  assert.equal(saved.profile.name, "Aluno A");
  assert.equal((await data.getUserData(userA)).hasData, true);
  assert.equal((await data.getUserData(userA)).data.work.id, "work-1");
  assert.equal((await data.getUserData(userB)).hasData, false);
});

test("dados acima do limite são rejeitados", async () => {
  const huge = "x".repeat(data.MAX_BYTES + 1000);
  await assert.rejects(() => data.replaceUserData(userA, { profile: { name: huge } }), /limite permitido/);
});

test("arquivo de dados é criado com permissões restritas", async () => {
  const file = path.join(dir, `${userA}.json`);
  const stat = await fs.stat(file);
  assert.equal(stat.mode & 0o777, 0o600);
});

test("server protege os endpoints de dados por sessão", async () => {
  const server = await fs.readFile("server.js", "utf8");
  assert.match(server, /\/api\/me\/data/);
  assert.match(server, /É necessário iniciar sessão/);
  assert.match(server, /requireUser/);
});
