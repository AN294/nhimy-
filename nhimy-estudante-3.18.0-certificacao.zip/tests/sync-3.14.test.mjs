import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

const sync = await fs.readFile("public/js/core/account/sync.js", "utf8");
const data = await fs.readFile("public/js/core/account/data.js", "utf8");

 test("3.14 usa sincronização server-first", () => {
  assert.match(sync, /SYNC_VERSION = 2/);
  assert.match(sync, /remoteChanged/);
  assert.match(sync, /localChanged/);
  assert.match(sync, /server-authoritative/);
});

test("3.14 hidrata os módulos existentes a partir dos dados remotos", () => {
  assert.match(sync, /nhimy\.student\.profile/);
  assert.match(sync, /nhimy\.organize\.state/);
  assert.match(sync, /nhimy\.library\.state/);
  assert.match(sync, /nhimy\.study\.session/);
  assert.match(sync, /nhimy\.work\.project/);
});

test("3.14 não sobrescreve silenciosamente alterações concorrentes", () => {
  assert.match(sync, /preserveConflict/);
  assert.match(sync, /conflict-server-wins/);
  assert.match(sync, /CONFLICT_PREFIX/);
});

test("3.14 mantém importação inicial protegida contra troca de utilizador", () => {
  assert.match(sync, /marker\?\.userId && marker\.userId !== user\.id/);
  assert.match(sync, /action: "preserved"/);
});

test("3.14 mantém API de conta existente", () => {
  assert.match(data, /getAccountData/);
  assert.match(data, /saveAccountData/);
  assert.match(data, /credentials: "same-origin"/);
});
