import test from "node:test";
import assert from "node:assert/strict";
import { validateResearchRequest } from "../public/js/core/work/research/service.js";

test("Research rejeita unidade sem pergunta ou query", () => {
  const result = validateResearchRequest({
    type: "work-research-request",
    topic: "Biologia",
    researchUnits: [{}]
  });
  assert.equal(result.valid, false);
  assert.match(result.error, /pergunta|query/i);
});

test("Research rejeita tipos inválidos nos campos estruturais", () => {
  const result = validateResearchRequest({
    type: "work-research-request",
    topic: "Biologia",
    researchUnits: [{ question: "O que é?", query: "x", intent: 123 }]
  });
  assert.equal(result.valid, false);
  assert.match(result.error, /inválido/i);
});

test("Research limita o tamanho de campos por unidade", () => {
  const result = validateResearchRequest({
    type: "work-research-request",
    topic: "Biologia",
    researchUnits: [{ question: "x".repeat(501) }]
  });
  assert.equal(result.valid, false);
  assert.match(result.error, /demasiado (longa|longo)/i);
});


test("Research rejeita coleções estruturais com tipo incorreto", () => {
  const result = validateResearchRequest({
    type: "work-research-request",
    topic: "Biologia",
    researchUnits: [{ question: "O que é?" }],
    queries: { value: "não é uma lista" }
  });
  assert.equal(result.valid, false);
  assert.match(result.error, /queries/i);
});

test("Servidor mantém proteções básicas contra abuso e exposição", async () => {
  const fs = await import("node:fs/promises");
  const server = await fs.readFile("server.js", "utf8");
  assert.match(server, /app\.disable\("x-powered-by"\)/);
  assert.match(server, /express\.json\(\{\s*limit:\s*"100kb"/s);
  assert.match(server, /rateBuckets/);
  assert.match(server, /429/);
  assert.match(server, /Retry-After/);
  assert.match(server, /Strict-Transport-Security/);
  assert.match(server, /Cross-Origin-Opener-Policy/);
  assert.match(server, /Cache-Control.*no-store/);
});

test("Servidor não expõe endpoints administrativos ou de execução arbitrária", async () => {
  const fs = await import("node:fs/promises");
  const server = await fs.readFile("server.js", "utf8");
  assert.doesNotMatch(server, /child_process|exec\(|spawn\(|eval\(|new Function\(/);
  assert.doesNotMatch(server, /\/api\/(shell|exec|upload)/);
  assert.match(server, /createAdminRoutes/);
});

test("Trabalhos limita conteúdo persistido para reduzir abuso de armazenamento", async () => {
  const storage = await import("../public/js/core/work/storage.js");
  const project = storage.createProject({
    title: "T".repeat(storage.LIMITS.title + 100),
    subject: "S".repeat(storage.LIMITS.subject + 100),
    orientationContext: "O".repeat(storage.LIMITS.orientationContext + 100)
  });
  assert.equal(project.title.length, storage.LIMITS.title);
  assert.equal(project.subject.length, storage.LIMITS.subject);
  assert.equal(project.orientationContext.length, storage.LIMITS.orientationContext);

  const structure = Array.from({ length: 10 }, (_, i) => ({ id: `s${i}`, title: `Secção ${i + 1}` }));
  const prepared = storage.saveStructure(project, structure);
  const content = "x".repeat(storage.LIMITS.sectionContent + 100);
  const saved = storage.saveSectionContent(prepared, "s0", content);
  assert.equal(saved.content.s0.length, storage.LIMITS.sectionContent);
});

test("Trabalhos descarta objetos de pesquisa acima do limite seguro", async () => {
  const storage = await import("../public/js/core/work/storage.js");
  const huge = { payload: "x".repeat(storage.LIMITS.research + 1000) };
  const normalized = storage.normalizeProject({ research: huge, researchPlan: huge, researchRequest: huge, qualityReport: huge });
  assert.equal(normalized.research, null);
  assert.equal(normalized.researchPlan, null);
  assert.equal(normalized.researchRequest, null);
  assert.equal(normalized.qualityReport, null);
});
