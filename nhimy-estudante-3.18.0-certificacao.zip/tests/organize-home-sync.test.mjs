import test from "node:test";
import assert from "node:assert/strict";

function makeStorage() {
  return { store: new Map(), getItem(key) { return this.store.get(key) ?? null; }, setItem(key, value) { this.store.set(key, String(value)); }, removeItem(key) { this.store.delete(key); } };
}

globalThis.localStorage = makeStorage();
globalThis.sessionStorage = makeStorage();

const listeners = new Set();
globalThis.addEventListener = (name, listener) => { if (name === "nhimy:state-change") listeners.add(listener); };
globalThis.removeEventListener = (name, listener) => { if (name === "nhimy:state-change") listeners.delete(listener); };
globalThis.dispatchEvent = event => { for (const listener of listeners) listener(event); return true; };
globalThis.CustomEvent = class CustomEvent { constructor(type, init = {}) { this.type = type; this.detail = init.detail; } };

globalThis.window = { location: { replace() {} } };
globalThis.document = {};

const storage = await import("../public/js/core/organize/storage.js");
const tasks = await import("../public/js/core/organize/tasks.js");
const goals = await import("../public/js/core/organize/goals.js");
const notes = await import("../public/js/core/organize/notes.js");
const events = await import("../public/js/core/organize/events.js");
const { getHomeState } = await import("../public/js/core/home/state.js");
const { getContinueItems, getHomeSuggestions } = await import("../public/js/core/home/derived.js");


test("Organizar emite atualização para a experiência integrada", () => {
  storage.clearState();
  const received = [];
  const listener = event => received.push(event.detail);
  listeners.add(listener);

  tasks.createTask({ title: "Tarefa integrada" });
  goals.createGoal({ title: "Meta integrada" });
  notes.createNote({ title: "Nota integrada", content: "Conteúdo" });
  events.createEvent({ title: "Agenda integrada", date: "2099-01-01" });

  listeners.delete(listener);

  assert.ok(received.length >= 4);
  assert.ok(received.every(item => item.source === "organize"));
});

test("Home reflete imediatamente os dados reais do Organizar", () => {
  storage.clearState();
  tasks.createTask({ title: "Revisar prova", priority: "high" });
  goals.createGoal({ title: "Terminar capítulo" });
  notes.createNote({ title: "Resumo", content: "Pontos principais" });
  events.createEvent({ title: "Sessão", date: "2099-01-02", time: "10:00" });

  const state = getHomeState();
  assert.equal(state.organize.tasks.length, 1);
  assert.equal(state.organize.goals.length, 1);
  assert.equal(state.organize.notes.length, 1);
  assert.equal(state.organize.events.length, 1);
  assert.equal(state.organizeSummary.pendingTasks, 1);
  assert.equal(state.organizeSummary.activeGoals.length, 1);

  const continueItems = getContinueItems(state);
  const suggestions = getHomeSuggestions(state);
  assert.ok(continueItems.some(item => item.href === "/organizar/tarefas/"));
  assert.ok(suggestions.some(item => item.href === "/organizar/tarefas/"));
  assert.ok(suggestions.some(item => item.href === "/organizar/metas/"));
});

test("limpar Organizar também notifica a camada integrada", () => {
  tasks.createTask({ title: "Temporária" });
  let notified = false;
  const listener = event => { if (event.detail?.source === "organize") notified = true; };
  listeners.add(listener);
  storage.clearState();
  listeners.delete(listener);
  assert.equal(notified, true);
  const state = getHomeState();
  assert.equal(state.organize.tasks.length, 0);
  assert.equal(state.organize.goals.length, 0);
  assert.equal(state.organize.notes.length, 0);
  assert.equal(state.organize.events.length, 0);
});
