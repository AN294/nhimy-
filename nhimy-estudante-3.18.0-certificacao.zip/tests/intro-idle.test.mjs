import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const intro = fs.readFileSync(path.join(root, 'public/intro.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'public/css/components/intro.css'), 'utf8');
const html = fs.readFileSync(path.join(root, 'public/index.html'), 'utf8');

test('intro 3.0 — retorno após 3 minutos de inatividade', () => {
  assert.match(intro, /IDLE_RETURN_DELAY\s*=\s*180000/);
  assert.match(intro, /setTimeout\(showIntro, IDLE_RETURN_DELAY\)/);
  assert.match(intro, /sessionStorage\.getItem\(INTRO_KEY\)/);
  assert.match(intro, /intro\.style\.display\s*=\s*"none"/);
  assert.match(intro, /intro\.style\.display\s*=\s*"grid"/);
  assert.match(intro, /void intro\.offsetWidth/);
  assert.match(intro, /pointerdown/);
  assert.match(intro, /keydown/);
  assert.match(intro, /touchstart/);
});

test('intro 3.0 — apresentação mantém capelo sem N interno', () => {
  assert.match(html, /class="nhimy-cap"/);
  assert.doesNotMatch(html, /<text[^>]*>\s*N\s*<\/text>/i);
  assert.doesNotMatch(css, /Capelo \+ N/);
});
