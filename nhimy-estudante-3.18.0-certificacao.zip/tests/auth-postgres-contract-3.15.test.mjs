import test from "node:test";
import assert from "node:assert/strict";
import { createPostgresAuthStore } from "../public/js/core/auth/postgres-store.js";

test("adapter PostgreSQL de autenticação valida pool e contrato", () => {
  assert.throws(() => createPostgresAuthStore(null, {}), /Pool PostgreSQL inválido/);
  const calls = [];
  const pool = {
    query: async (...args) => { calls.push(["query", ...args]); return { rows: [], rowCount: 0 }; },
    connect: async () => ({ query: async (...args) => { calls.push(["client", ...args]); return { rows: [], rowCount: 0 }; }, release() {} })
  };
  const store = createPostgresAuthStore(pool, {
    hashPassword: async () => "scrypt$test$hash", verifyPassword: async () => true,
    normalizeEmail: value => String(value).trim().toLowerCase(), normalizeName: value => String(value || "").trim(),
    validEmail: value => /@/.test(value), passwordMin: 8, passwordMax: 128, sessionBytes: 32, sessionTtlMs: 1000,
    randomBytes: () => Buffer.alloc(32, 1), randomUUID: () => "00000000-0000-0000-0000-000000000001", hashToken: () => "a".repeat(64)
  });
  for (const method of ["registerUser", "authenticateUser", "createSession", "getUserBySession", "destroySession", "changePassword", "destroyAllSessions", "deleteUser"]) assert.equal(typeof store[method], "function");
  assert.equal(calls.length, 0);
});
