import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const read = (file) => fs.readFileSync(path.join(root, file), 'utf8');

test('3.7 controles essenciais de entrada têm nome acessível', () => {
  const files = [
    ['public/estudar/index.html', ['startInput']],
    ['public/estudar/compreender/index.html', ['question']],
    ['public/estudar/praticar/index.html', ['challengeAnswer', 'practiceNote']],
    ['public/ferramentas/index.html', [
      'qrInput', 'imageInput', 'resizeInput', 'pdfImages',
      'textCounterInput', 'textTransformInput', 'urlInput', 'urlOutput',
      'jsonInput', 'jsonOutput', 'generatedText'
    ]]
  ];
  for (const [file, ids] of files) {
    const html = read(file);
    for (const id of ids) {
      const escaped = id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      const control = new RegExp(`<[^>]+\\bid=["']${escaped}["'][^>]*>`, 'i').exec(html)?.[0] ?? '';
      assert.ok(control, `${file}: controle ${id} não encontrado`);
      assert.match(control, /aria-label=["'][^"']+|aria-labelledby=["'][^"']+/, `${file}: ${id} sem nome acessível`);
    }
  }
});

test('Ferramentas: limite do gerador de texto é consistente entre UI e runtime', () => {
  const html = read('public/ferramentas/index.html');
  const generator = read('public/js/modules/generator.js');
  assert.match(html, /id=\"textGeneratorLength\"[\s\S]*?max=\"500\"/);
  assert.match(generator, /Math\.min\(\s*500,/);
});

test('3.7 manifest corresponde exatamente ao inventário do pacote', () => {
  const listed = read('manifest.txt').split(/\r?\n/).map(s => s.trim()).filter(Boolean).map(s => s.replace(/^\.\//, ''));
  const actual = [];
  const walk = (dir) => {
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      if (entry.name === 'node_modules') continue;
      const full = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(full);
      else actual.push(path.relative(root, full).replaceAll(path.sep, '/'));
    }
  };
  walk(root);
  actual.sort();
  assert.deepEqual(listed, actual);
});
