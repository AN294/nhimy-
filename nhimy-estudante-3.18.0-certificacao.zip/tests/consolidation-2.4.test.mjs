import test from "node:test";
import assert from "node:assert/strict";

const home = await import("../public/js/core/home/derived.js");
const workflow = await import("../public/js/core/work/workflow.js");

function base() {
  return {
    study: { session: null, progress: 0, current: "conteudo" },
    work: { active: false, project: null, progress: 0, current: "criar", title: "" },
    organize: { tasks: [], goals: [], pendingTasks: 0, progress: 0 }
  };
}

test("Home 2.4 mostra trabalho ativo e usa a rota oficial", () => {
  const project = { title: "Projeto", subject: "História", orientationReady: false, structure: [], content: {}, reviewed: false, finalized: false };
  const state = { ...base(), work: { active: true, project, progress: 17, current: "orientar", title: "Projeto" } };
  const items = home.getContinueItems(state);
  assert.equal(items[0].title, "Projeto");
  assert.equal(items[0].href, workflow.getWorkRoute(project));
});

test("Home 2.4 mantém fallback quando não há atividade", () => {
  const items = home.getContinueItems(base());
  assert.equal(items.length, 1);
  assert.equal(items[0].href, "/estudar/");
});

test("Home 2.4 prioriza o estado real sem duplicá-lo", () => {
  const state = { ...base(), organize: { tasks: [{ title: "Tarefa", completed: false }], goals: [], pendingTasks: 1, progress: 0 } };
  const suggestions = home.getHomeSuggestions(state);
  assert.equal(suggestions[0].href, "/organizar/tarefas/");
});
