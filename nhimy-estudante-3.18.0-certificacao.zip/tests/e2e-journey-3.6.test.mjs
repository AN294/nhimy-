import test from "node:test";
import assert from "node:assert/strict";

function makeStorage() {
  return { store: new Map(), getItem(k) { return this.store.get(k) ?? null; }, setItem(k,v) { this.store.set(k,String(v)); }, removeItem(k) { this.store.delete(k); } };
}

globalThis.localStorage = makeStorage();
globalThis.sessionStorage = makeStorage();
globalThis.window = { location: { replace() {} } };
globalThis.document = {};

const study = await import("../public/js/core/study/storage.js");
const work = await import("../public/js/core/work/storage.js");
const workflow = await import("../public/js/core/work/workflow.js");
const actions = await import("../public/js/core/student/actions.js");
const tasks = await import("../public/js/core/organize/tasks.js");
const notes = await import("../public/js/core/organize/notes.js");
const events = await import("../public/js/core/organize/events.js");
const organize = await import("../public/js/core/organize/storage.js");
const library = await import("../public/js/core/library/storage.js");
const studentState = await import("../public/js/core/student/state.js");

function reset() {
  study.clearStudySession();
  work.clearProject();
  organize.clearState();
  library.clearState();
}

test("3.6 jornada E2E liga Estudar → Trabalhos → Organizar → Biblioteca → estado central", () => {
  reset();

  const s = study.startStudySession({
    topic: "Fotossíntese",
    source: "Texto base sobre fotossíntese",
    stage: "conteudo"
  });
  study.setSummary({ result: "A fotossíntese converte energia luminosa em energia química.", request: { topic: s.topic } });
  study.setStudySession({ prepared: "Luz, clorofila, água, CO2 e glicose.", comprehension: "A planta usa luz para produzir matéria orgânica." });
  study.setReviewed(true);
  study.setPracticeResult({ completed: true, score: 4, total: 5 });

  const project = actions.createWorkFromCurrentStudy({ subject: "Biologia" });
  assert.ok(project);
  assert.equal(project.subject, "Biologia");

  let current = work.getProject();
  current = work.saveOrientation(current, {
    title: "Fotossíntese",
    orientation: "Explicar o processo, etapas e importância.",
    orientationContext: "Basear o desenvolvimento no conteúdo estudado."
  });
  current = work.saveStructure(current, [
    { id: "intro", title: "Introdução", purpose: "Apresentar o tema." },
    { id: "dev", title: "Desenvolvimento", purpose: "Explicar o processo." },
    { id: "con", title: "Conclusão", purpose: "Sintetizar os pontos principais." }
  ]);
  current = work.saveSectionContent(current, "intro", "A fotossíntese é essencial para a vida e para os ecossistemas.");
  current = work.saveSectionContent(current, "dev", "A luz é captada pela clorofila e participa da produção de glicose.");
  current = work.saveSectionContent(current, "con", "O processo relaciona luz, água e dióxido de carbono na produção de matéria orgânica.");
  current = work.saveReview(current, { content: true, clarity: true, sources: true }, { quality: "ok" }, true);
  current = work.finalizeProject(current);
  work.setProject(current);

  assert.equal(workflow.getWorkProgress(current), 100);
  assert.equal(current.finalized, true);

  const finalItem = actions.createLibraryItemFromCurrentWork();
  assert.ok(finalItem);
  assert.equal(library.getItems().length, 1);

  const task = actions.createTaskFromCurrentWork({ title: "Entregar trabalho de Fotossíntese" });
  const note = notes.createNote({ title: "Nota da aula", content: "Rever a relação entre luz e clorofila." });
  const noteItem = actions.createLibraryItemFromNote(note.id);
  const event = events.createEvent({ title: "Entrega de Biologia", date: "2099-01-10", time: "10:00" });

  assert.ok(task);
  assert.ok(noteItem);
  assert.ok(event);
  assert.equal(tasks.getTasks().length, 1);
  assert.equal(notes.getNotes().length, 1);
  assert.equal(events.getEvents().length, 1);
  assert.equal(library.getItems().length, 2);

  const state = studentState.getStudentState();
  assert.equal(state.study.active, true);
  assert.equal(state.study.current, "resultado");
  assert.equal(state.work.current, "finalizar");
  assert.equal(state.work.progress, 100);
  assert.equal(state.organize.tasks.length, 1);
  assert.equal(state.organize.notes.length, 1);
  assert.equal(state.organize.events.length, 1);
  assert.equal(state.library.count, 2);
});

test("3.6 não cria duplicação ao guardar trabalho finalizado novamente", () => {
  const project = work.getProject();
  assert.ok(project?.finalized);
  const first = actions.createLibraryItemFromCurrentWork();
  const second = actions.createLibraryItemFromCurrentWork();
  assert.ok(first);
  assert.equal(second.id, first.id);
  assert.equal(library.getItems().length, 2);
});
