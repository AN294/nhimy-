import test from "node:test";
import assert from "node:assert/strict";
import { createPostgresRepository } from "../public/js/core/persistence/postgres-repository.js";

function fakePool() {
  let row = null;
  let txRow = null;
  const calls = [];
  const makeResult = (rows = []) => ({ rows });
  const client = {
    async query(sql, params = []) {
      calls.push({ sql, params });
      if (sql === "BEGIN") return makeResult();
      if (sql === "COMMIT") { row = txRow; return makeResult(); }
      if (sql === "ROLLBACK") { txRow = null; return makeResult(); }
      if (/SELECT revision/.test(sql)) return makeResult(txRow ? [{ revision: txRow.revision }] : []);
      if (/INSERT INTO account_data/.test(sql)) {
        const [, version, profile, study, work, organize, library, updatedAt, revision] = params;
        txRow = { version, profile: JSON.parse(profile), study: JSON.parse(study), work: JSON.parse(work), organize: JSON.parse(organize), library: JSON.parse(library), updated_at: updatedAt, revision };
        return makeResult([txRow]);
      }
      throw new Error(`SQL inesperado: ${sql}`);
    },
    release() {}
  };
  return {
    calls,
    async query(sql, params = []) {
      calls.push({ sql, params });
      if (/SELECT version, profile/.test(sql)) return makeResult(row ? [row] : []);
      if (/DELETE FROM account_data/.test(sql)) { row = null; return makeResult(); }
      throw new Error(`SQL inesperado no pool: ${sql}`);
    },
    async connect() { txRow = row ? structuredClone(row) : null; return client; }
  };
}

test("3.14 adapter PostgreSQL respeita o contrato e isola o utilizador", async () => {
  const pool = fakePool();
  const repo = createPostgresRepository(pool);
  const empty = await repo.getUserData("user-a");
  assert.equal(empty.hasData, false);
  const saved = await repo.replaceUserData("user-a", { profile: { name: "Aluno A" } });
  assert.equal(saved.profile.name, "Aluno A");
  assert.equal(saved.revision, 1);
  const loaded = await repo.getUserData("user-a");
  assert.equal(loaded.data.profile.name, "Aluno A");
});

test("3.14 adapter PostgreSQL rejeita escrita concorrente com revisão antiga", async () => {
  const pool = fakePool();
  const repo = createPostgresRepository(pool);
  const first = await repo.replaceUserData("user-a", { profile: { name: "A" } });
  assert.equal(first.revision, 1);
  await assert.rejects(
    () => repo.replaceUserData("user-a", { profile: { name: "B" } }, { expectedRevision: 0 }),
    error => error?.code === "DATA_CONFLICT"
  );
  assert.equal((await repo.getUserData("user-a")).data.profile.name, "A");
});

test("3.14 adapter PostgreSQL elimina apenas os dados do utilizador solicitado", async () => {
  const pool = fakePool();
  const repo = createPostgresRepository(pool);
  await repo.replaceUserData("user-a", { profile: { name: "A" } });
  await repo.deleteUserData("user-a");
  assert.equal((await repo.getUserData("user-a")).hasData, false);
  assert.ok(pool.calls.some(call => /DELETE FROM account_data/.test(call.sql)));
});

test("3.14 servidor só ativa PostgreSQL por configuração explícita", async () => {
  const server = await import("node:fs/promises").then(fs => fs.readFile("server.js", "utf8"));
  assert.match(server, /NHIMY_REPOSITORY === "postgres"/);
  assert.match(server, /DATABASE_URL \|\| process\.env\.NHIMY_DATABASE_URL/);
  assert.match(server, /createPostgresRepository/);
  assert.match(server, /import\("pg"\)/);
});
