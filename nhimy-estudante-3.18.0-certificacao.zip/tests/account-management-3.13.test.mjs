import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs/promises";

const auth = await fs.readFile("public/js/core/auth/server.js", "utf8");
const account = await fs.readFile("public/js/core/account/server.js", "utf8");
const repo = await fs.readFile("public/js/core/persistence/repository.js", "utf8");
const fileRepo = await fs.readFile("public/js/core/persistence/file-repository.js", "utf8");
const server = await fs.readFile("server.js", "utf8");

test("3.13 oferece alteração de palavra-passe", () => {
  assert.match(auth, /async function changePassword/);
  assert.match(auth, /verifyPassword\(current/);
  assert.match(auth, /user\.passwordHash = await hashPassword\(next\)/);
  assert.match(server, /\/api\/auth\/change-password/);
});

test("3.13 permite encerrar todas as sessões do utilizador", () => {
  assert.match(auth, /async function destroyAllSessions/);
  assert.match(auth, /session\.userId !== userId/);
  assert.match(server, /\/api\/auth\/logout-all/);
});

test("3.13 elimina conta somente após validar a palavra-passe", () => {
  assert.match(auth, /async function deleteUser/);
  assert.match(auth, /verifyPassword\(cleanPassword/);
  assert.match(auth, /data\.users\.splice/);
  assert.match(server, /app\.delete\("\/api\/auth\/account"/);
  assert.match(server, /dataRepository\.deleteUserData\(user\.id\)/);
});

test("3.13 eliminação de conta apaga também os dados associados", () => {
  assert.match(account, /async function deleteUserData/);
  assert.match(fileRepo, /deleteUserData/);
  assert.match(repo, /"deleteUserData"/);
});

test("3.13 não aceita userId enviado pelo cliente para gestão da conta", () => {
  assert.doesNotMatch(server, /changePassword\(req\.body\.userId/);
  assert.doesNotMatch(server, /destroyAllSessions\(req\.body\.userId/);
  assert.doesNotMatch(server, /deleteUser\(req\.body\.userId/);
});
