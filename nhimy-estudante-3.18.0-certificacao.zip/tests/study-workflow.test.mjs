import test from "node:test";
import assert from "node:assert/strict";

function makeStorage() {
  return { store: new Map(), getItem(k){ return this.store.get(k) ?? null; }, setItem(k,v){ this.store.set(k,String(v)); }, removeItem(k){ this.store.delete(k); } };
}

globalThis.sessionStorage = makeStorage();
globalThis.window = { location: { href: "" } };

const storage = await import("../public/js/core/study/storage.js");
const workflow = await import("../public/js/core/study/workflow.js");

test("sessão de estudo segue as 6 etapas centrais", () => {
  storage.clearStudySession();
  const session = storage.startStudySession({ topic: "Fotossíntese", sourceType: "topic" });
  assert.equal(workflow.getCurrentStudyStage(session), "conteudo");
  assert.equal(workflow.getStudyProgress(session), 0);

  storage.setStudySession({ prepared: "Ideia central", stage: "compreender" });
  assert.equal(workflow.getCurrentStudyStage(), "compreender");
  assert.equal(workflow.getStudyProgress(), 40);
  assert.deepEqual(workflow.getCompletedStudyStages(), ["conteudo", "preparar"]);

  storage.setStudySession({ comprehension: "essencial", stage: "revisar" });
  assert.equal(workflow.getStudyProgress(), 60);
  assert.equal(workflow.canAccessStudyStage("praticar"), false);
  storage.setStudySession({ stage: "praticar" });
  assert.equal(workflow.canAccessStudyStage("praticar"), true);
});

test("resultados de prática e quiz fecham a sessão", () => {
  storage.clearStudySession();
  storage.startStudySession({ source: "Conteúdo suficiente para estudar.", sourceType: "content", stage: "preparar" });
  storage.setStudySession({ prepared: "Preparação", comprehension: "essencial", stage: "revisar" });
  storage.setPracticeResult({ completed: true, confidence: "seguro" });
  assert.equal(storage.getStudySession().stage, "resultado");
  assert.equal(workflow.getStudyProgress(), 100);
  assert.equal(workflow.canAccessStudyStage("resultado"), true);

  storage.setQuizResult(4, 5);
  assert.deepEqual(storage.getQuizResult(), { score: 4, total: 5 });
  assert.equal(storage.isQuizCompleted(), true);
});

test("prática só abre depois da revisão", () => {
  storage.clearStudySession();
  storage.startStudySession({ topic: "Tema", source: "Conteúdo", stage: "conteudo" });
  storage.setStudySession({ prepared: "Preparação", stage: "compreender" });
  assert.equal(workflow.canAccessStudyStage("praticar"), false);
  storage.setStudySession({ comprehension: "essencial", stage: "revisar" });
  assert.equal(workflow.canAccessStudyStage("praticar"), false);
  storage.setStudySession({ stage: "praticar" });
  assert.equal(workflow.canAccessStudyStage("praticar"), true);
  assert.equal(workflow.getStudyReadiness().reviewed, true);
});
