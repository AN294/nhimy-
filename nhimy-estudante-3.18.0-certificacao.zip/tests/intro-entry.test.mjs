import test from "node:test";
import assert from "node:assert/strict";
import fs from "node:fs";

const home = fs.readFileSync("public/index.html", "utf8");
const intro = fs.readFileSync("public/intro.js", "utf8");
const css = fs.readFileSync("public/css/components/intro.css", "utf8");

test("Entrada do NHIMY está ligada à Home antes do conteúdo", () => {
  assert.match(home, /id="nhimyIntro"/);
  assert.match(home, /class="nhimy-intro"/);
  assert.match(home, /href="\/css\/components\/intro\.css"/);
  assert.match(home, /src="\/intro\.js"/);
  assert.ok(home.indexOf('id="nhimyIntro"') < home.indexOf('<header'));
});

test("Assinatura de entrada mantém entrada manual e automática", () => {
  assert.match(intro, /nhimy-intro-skip/);
  assert.match(intro, /AUTO_ENTER_DELAY/);
  assert.match(intro, /sessionStorage/);
});

test("CSS da assinatura contém animações e suporte a movimento reduzido", () => {
  assert.match(css, /\.nhimy-intro\s*\{/);
  assert.match(css, /@keyframes nhimyCapDraw/);
  assert.match(css, /prefers-reduced-motion/);
});
