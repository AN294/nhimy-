import test from "node:test";
import assert from "node:assert/strict";
function makeStorage(){return {store:new Map(),getItem(k){return this.store.get(k)??null},setItem(k,v){this.store.set(k,String(v))},removeItem(k){this.store.delete(k)}}}
globalThis.localStorage=makeStorage(); globalThis.sessionStorage=makeStorage();
const library=await import("../public/js/core/library/storage.js");
const actions=await import("../public/js/core/student/actions.js");
const work=await import("../public/js/core/work/storage.js");
test("Biblioteca cria, pesquisa, atualiza e exclui itens",()=>{library.clearState();const a=library.createItem({title:"Biologia",content:"Célula e metabolismo",type:"estudo",tags:"bio"});assert.ok(a);assert.equal(library.searchItems("metabolismo").length,1);const b=library.updateItem(a.id,{title:"Biologia celular"});assert.equal(b.title,"Biologia celular");assert.equal(library.deleteItem(a.id),true);assert.equal(library.getItems().length,0)});
test("Biblioteca aplica limites e não aceita conteúdo vazio",()=>{library.clearState();assert.equal(library.createItem({title:"",content:""}),null);const item=library.createItem({title:"x".repeat(500),content:"y".repeat(60000)});assert.equal(item.title.length,200);assert.equal(item.content.length,50000)});
test("Estudo atual pode ser guardado na Biblioteca sem criar fonte paralela",()=>{library.clearState();work.clearProject();sessionStorage.setItem("nhimy.study.session",JSON.stringify({id:"s-lib",topic:"Fotossíntese",source:"luz",prepared:"clorofila e glicose",stage:"preparar"}));const item=actions.createLibraryItemFromCurrentStudy();assert.ok(item);assert.equal(item.title,"Fotossíntese");assert.equal(library.getItems()[0].content,"clorofila e glicose")});
test("Estado central expõe somente uma visão derivada da Biblioteca",async()=>{const state=(await import("../public/js/core/student/state.js")).getStudentState();assert.equal(state.library.count,library.getItems().length);assert.equal(state.library.items.length,state.library.count)});
test("Página da Biblioteca possui pesquisa e CRUD",async()=>{const fs=await import("node:fs/promises");const html=await fs.readFile("public/biblioteca/index.html","utf8");const js=await fs.readFile("public/biblioteca/app.js","utf8");assert.match(html,/id="librarySearch"/);assert.match(html,/id="libraryForm"/);assert.match(js,/createItem/);assert.match(js,/updateItem/);assert.match(js,/deleteItem/);assert.match(js,/searchItems/)});

test("Nota do Organizar pode ser guardada na Biblioteca sem duplicar", async()=>{
  library.clearState();
  const notes=await import("../public/js/core/organize/notes.js");
  notes.createNote({title:"Minha nota",content:"Conteúdo importante"});
  const note=notes.getNotes()[0];
  const first=actions.createLibraryItemFromNote(note.id);
  const second=actions.createLibraryItemFromNote(note.id);
  assert.ok(first);
  assert.equal(second.id,first.id);
  assert.equal(library.getItems().length,1);
  assert.equal(library.getItems()[0].type,"nota");
});

test("Trabalho finalizado pode ser guardado na Biblioteca sem duplicar",()=>{
  library.clearState();
  work.clearProject();
  work.setProject({title:"Trabalho final",subject:"História",type:"Pesquisa",reviewed:true,finalized:true,structure:[{id:"intro",title:"Introdução"},{id:"fim",title:"Conclusão"}],content:{intro:"Texto da introdução",fim:"Texto da conclusão"}});
  const first=actions.createLibraryItemFromCurrentWork();
  const second=actions.createLibraryItemFromCurrentWork();
  assert.ok(first);
  assert.equal(second.id,first.id);
  assert.equal(library.getItems().length,1);
  assert.match(library.getItems()[0].content,/Introdução/);
  assert.match(library.getItems()[0].content,/Texto da conclusão/);
});

test("Trabalho não finalizado não entra na Biblioteca como versão final",()=>{
  library.clearState();
  work.clearProject();
  work.setProject({title:"Rascunho",reviewed:true,finalized:false,structure:[{id:"a",title:"A"}],content:{a:"Texto"}});
  assert.equal(actions.createLibraryItemFromCurrentWork(),null);
  assert.equal(library.getItems().length,0);
});

test("Interfaces de Notas e Finalização oferecem ponte para Biblioteca",async()=>{
  const fs=await import("node:fs/promises");
  const notes=await fs.readFile("public/organizar/notas/app.js","utf8");
  const final=await fs.readFile("public/trabalhos/finalizar/index.html","utf8");
  const finalJs=await fs.readFile("public/trabalhos/finalizar/app.js","utf8");
  assert.match(notes,/createLibraryItemFromNote/);
  assert.match(notes,/data-action="library"/);
  assert.match(final,/id="libraryButton"/);
  assert.match(finalJs,/createLibraryItemFromCurrentWork/);
});

