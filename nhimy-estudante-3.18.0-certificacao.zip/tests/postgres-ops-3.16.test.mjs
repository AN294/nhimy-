import test from "node:test";
import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

async function text(file) { return readFile(path.join(root, file), "utf8"); }

test("3.16 expõe migração e preflight PostgreSQL como comandos explícitos", async () => {
  const pkg = JSON.parse(await text("package.json"));
  assert.ok(/^3\.(1[6-9]|[2-9]\d)\.\d+$/.test(pkg.version), `versão incompatível: ${pkg.version}`);
  assert.equal(pkg.scripts["db:migrate"], "node scripts/migrate-postgres.mjs");
  assert.equal(pkg.scripts["preflight:postgres"], "node scripts/preflight-postgres.mjs");
});

test("3.16 runner aplica migrações em ordem e registra checksum", async () => {
  const source = await text("scripts/migrate-postgres.mjs");
  assert.match(source, /001-initial-postgres\.sql.*002-account-data-revision\.sql.*003-auth-postgres-server-first\.sql.*004-admin-role\.sql/s);
  assert.match(source, /nhimy_migrations/);
  assert.match(source, /checksum/);
  assert.doesNotMatch(source, /\b(DROP|TRUNCATE)\b/i);
});

test("3.16 preflight verifica conexão e contrato das tabelas", async () => {
  const source = await text("scripts/preflight-postgres.mjs");
  for (const token of ["DATABASE_URL", "information_schema.tables", "information_schema.columns", "users", "sessions", "account_data", "revision"]) assert.match(source, new RegExp(token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")));
});
