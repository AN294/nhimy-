# NHIMY Estudante 3.18

Projeto web modular para apoio ao estudante, com Estudar, Trabalhos, Organizar, Ferramentas, Biblioteca, autenticação e administração protegida.

## Execução

```bash
npm install
npm start
```

## Testes

```bash
npm test
```

## Persistência PostgreSQL

```bash
npm run preflight:postgres
npm run db:migrate
```

As validações reais de PostgreSQL/deploy devem ser executadas no ambiente correspondente antes da publicação.

## Segurança

O painel administrativo e as APIs administrativas exigem sessão autenticada e papel `admin`.
