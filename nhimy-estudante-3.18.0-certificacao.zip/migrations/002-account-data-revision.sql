-- NHIMY 3.14 — revisão otimista para sincronização segura.
-- Aplicar depois de 001-initial-postgres.sql.

ALTER TABLE account_data
  ADD COLUMN IF NOT EXISTS revision BIGINT NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS account_data_revision_idx
  ON account_data(revision);
