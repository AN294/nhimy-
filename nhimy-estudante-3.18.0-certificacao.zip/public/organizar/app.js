"use strict";

import { getOrganizeSummary } from "/js/core/organize/summary.js";

const $ = selector => document.querySelector(selector);
const pending = $("#summary-pending");
const goals = $("#summary-goals");
const events = $("#summary-events");
const progress = $("#summary-progress");
const taskNote = $("#summary-task-note");
const goalNote = $("#summary-goal-note");
const eventNote = $("#summary-event-note");
const focus = $("#organize-focus");
const focusEmpty = $("#organize-focus-empty");
const recentNotes = $("#organize-recent-notes");
const recentEmpty = $("#organize-recent-empty");

function escapeHtml(value) {
  return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
}

function formatDate(value) {
  if (!value) return "";
  const parts = String(value).split("-");
  return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : String(value);
}

function formatDateTime(date) {
  if (!(date instanceof Date) || Number.isNaN(date.getTime())) return "";
  return date.toLocaleString("pt-PT", { dateStyle: "short", timeStyle: "short" });
}

function renderFocus(summary) {
  const items = [];
  for (const task of summary.overdueTasks.slice(0, 3)) items.push({ type: "Atrasada", title: task.title, meta: task.dueDate ? `Prazo: ${formatDate(task.dueDate)}` : "Sem prazo", href: "/organizar/tarefas/", className: "is-danger" });
  for (const task of summary.todayTasks.slice(0, 3)) items.push({ type: "Hoje", title: task.title, meta: "Tarefa com prazo para hoje", href: "/organizar/tarefas/", className: "is-today" });
  for (const event of summary.todayEvents.slice(0, 3)) items.push({ type: "Agenda", title: event.title, meta: `${formatDate(event.date)}${event.time ? ` • ${event.time}` : ""}`, href: "/organizar/agenda/", className: "is-event" });
  if (!items.length && summary.highPriority.length) items.push(...summary.highPriority.slice(0, 3).map(task => ({ type: "Prioridade alta", title: task.title, meta: task.dueDate ? `Prazo: ${formatDate(task.dueDate)}` : "Sem prazo", href: "/organizar/tarefas/", className: "is-priority" })));

  focus.innerHTML = items.slice(0, 6).map(item => `<a class="organize-focus-card ${item.className}" href="${item.href}"><span>${escapeHtml(item.type)}</span><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.meta)}</small></a>`).join("");
  focus.hidden = !items.length;
  focusEmpty.hidden = Boolean(items.length);
}

function renderNotes(summary) {
  recentNotes.innerHTML = summary.recentNotes.map(note => `<a class="organize-note-card" href="/organizar/notas/"><strong>${escapeHtml(note.title || "Sem título")}</strong><p>${escapeHtml(note.content || "Sem conteúdo")}</p><small>${formatDateTime(new Date(note.updatedAt))}</small></a>`).join("");
  recentNotes.hidden = !summary.recentNotes.length;
  recentEmpty.hidden = Boolean(summary.recentNotes.length);
}

function render() {
  const summary = getOrganizeSummary();
  pending.textContent = summary.pendingTasks;
  goals.textContent = summary.activeGoals.length;
  events.textContent = summary.upcomingEvents.length;
  progress.textContent = `${summary.taskCompletion}%`;
  taskNote.textContent = summary.overdueTasks.length ? `${summary.overdueTasks.length} atrasada(s)` : summary.todayTasks.length ? `${summary.todayTasks.length} para hoje` : "Nada urgente";
  goalNote.textContent = summary.activeGoals.length ? `${summary.completedGoals} concluída(s)` : "Comece uma meta";
  eventNote.textContent = summary.todayEvents.length ? `${summary.todayEvents.length} hoje` : summary.upcomingEvents.length ? "Há compromissos marcados" : "Agenda livre";
  $("#organize-task-count").textContent = summary.pendingTasks;
  $("#organize-goal-count").textContent = summary.activeGoals.length;
  $("#organize-note-count").textContent = summary.notes.length;
  $("#organize-event-count").textContent = summary.upcomingEvents.length;
  renderFocus(summary);
  renderNotes(summary);
}

render();
