"use strict";

import { createTask, getTasks, updateTask, toggleTask, deleteTask } from "/js/core/organize/tasks.js";

const form = document.querySelector("#task-form");
const titleInput = document.querySelector("#task-title");
const dueDateInput = document.querySelector("#task-due-date");
const priorityInput = document.querySelector("#task-priority");
const searchInput = document.querySelector("#task-search");
const statusFilter = document.querySelector("#task-status-filter");
const priorityFilter = document.querySelector("#task-priority-filter");
const taskList = document.querySelector("#task-list");
const taskEmpty = document.querySelector("#task-empty");
const taskCount = document.querySelector("#task-count");
let editingId = null;

function escapeHtml(value) { return String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;"); }
function formatDate(value) { if (!value) return ""; const parts = String(value).split("-"); return parts.length === 3 ? `${parts[2]}/${parts[1]}/${parts[0]}` : String(value); }
function priorityLabel(value) { return ({ high: "Alta", medium: "Normal", low: "Baixa" })[value] || "Normal"; }
function priorityOrder(value) { return ({ high: 0, medium: 1, low: 2 })[value] ?? 1; }
function getButton() { return form.querySelector("button[type=submit]"); }
function resetForm() { editingId = null; form.reset(); priorityInput.value = "medium"; getButton().textContent = "Adicionar tarefa"; }

function visibleTasks() {
  const query = searchInput.value.trim().toLocaleLowerCase("pt");
  const status = statusFilter.value;
  const priority = priorityFilter.value;
  return getTasks().filter(task => {
    if (status === "pending" && task.completed) return false;
    if (status === "completed" && !task.completed) return false;
    if (priority !== "all" && task.priority !== priority) return false;
    if (query && !`${task.title} ${task.category}`.toLocaleLowerCase("pt").includes(query)) return false;
    return true;
  }).sort((a, b) => {
    if (a.completed !== b.completed) return a.completed ? 1 : -1;
    if (priorityOrder(a.priority) !== priorityOrder(b.priority)) return priorityOrder(a.priority) - priorityOrder(b.priority);
    if (a.dueDate && b.dueDate && a.dueDate !== b.dueDate) return a.dueDate.localeCompare(b.dueDate);
    if (a.dueDate && !b.dueDate) return -1;
    if (!a.dueDate && b.dueDate) return 1;
    return a.title.localeCompare(b.title, "pt");
  });
}

function render() {
  const all = getTasks();
  const tasks = visibleTasks();
  taskList.innerHTML = "";
  taskCount.textContent = `${tasks.length} de ${all.length} ${all.length === 1 ? "tarefa" : "tarefas"}`;
  taskEmpty.hidden = tasks.length > 0;
  if (!tasks.length) return;

  for (const task of tasks) {
    const article = document.createElement("article");
    article.className = `task-item priority-${task.priority}${task.completed ? " is-completed" : ""}`;
    article.dataset.id = task.id;
    article.innerHTML = `
      <div class="task-check"><button type="button" class="task-toggle" data-action="toggle" aria-label="${task.completed ? "Reabrir tarefa" : "Concluir tarefa"}" title="${task.completed ? "Reabrir tarefa" : "Concluir tarefa"}">${task.completed ? "✓" : ""}</button></div>
      <div class="task-main">
        <strong class="task-title">${escapeHtml(task.title)}</strong>
        <div class="task-meta">
          <span class="task-priority-badge">${escapeHtml(priorityLabel(task.priority))}</span>
          ${task.dueDate ? `<small class="task-due">📅 ${escapeHtml(formatDate(task.dueDate))}</small>` : ""}
        </div>
      </div>
      <div class="task-actions"><button type="button" class="btn btn-sm btn-secondary" data-action="edit">Editar</button><button type="button" class="btn btn-sm btn-ghost" data-action="delete">Excluir</button></div>`;
    taskList.appendChild(article);
  }
}

form.addEventListener("submit", event => {
  event.preventDefault();
  const title = titleInput.value.trim();
  if (!title) { titleInput.focus(); return; }
  const payload = { title, dueDate: dueDateInput.value, priority: priorityInput.value };
  const result = editingId ? updateTask(editingId, payload) : createTask(payload);
  if (!result) return;
  resetForm(); render(); titleInput.focus();
});

taskList.addEventListener("click", event => {
  const button = event.target.closest("button[data-action]");
  const item = button?.closest(".task-item");
  if (!button || !item) return;
  const id = item.dataset.id;
  if (button.dataset.action === "toggle") { toggleTask(id); render(); return; }
  if (button.dataset.action === "delete") { deleteTask(id); if (editingId === id) resetForm(); render(); return; }
  if (button.dataset.action === "edit") {
    const task = getTasks().find(item => item.id === id);
    if (!task) return;
    editingId = id; titleInput.value = task.title; dueDateInput.value = task.dueDate || ""; priorityInput.value = task.priority || "medium"; getButton().textContent = "Salvar alterações"; titleInput.focus();
  }
});

[searchInput, statusFilter, priorityFilter].forEach(control => control.addEventListener("input", render));
render();
