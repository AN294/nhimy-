"use strict";

/* Compatibilidade: a página Ferramentas usa agora o runtime modular em /js/core/app.js. */
