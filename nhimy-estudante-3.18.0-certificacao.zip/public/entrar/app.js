"use strict";
import { getCurrentUser, login, register } from "/js/core/auth/client.js";
import { syncLocalDataToAccount } from "/js/core/account/data.js";

const $ = (id) => document.getElementById(id);
function status(id, message, kind = "") { const el = $(id); el.textContent = message; el.className = `auth-status ${kind}`.trim(); }

try {
  const user = await getCurrentUser();
  if (user) window.location.replace("/");
} catch (_) {}

$("loginForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  status("loginStatus", "A entrar...");
  try { await login($("loginEmail").value, $("loginPassword").value); await syncLocalDataToAccount(); window.location.replace("/"); }
  catch (error) { status("loginStatus", error.message, "error"); }
});

$("registerForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  status("registerStatus", "A criar conta...");
  try { await register($("registerEmail").value, $("registerPassword").value, $("registerName").value); await syncLocalDataToAccount(); window.location.replace("/"); }
  catch (error) { status("registerStatus", error.message, "error"); }
});
