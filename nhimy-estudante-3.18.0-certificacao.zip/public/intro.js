"use strict";

/*
 * NHIMY 3.0 — ASSINATURA DE ENTRADA
 *
 * Responsabilidade:
 * Controlar exclusivamente a experiência de abertura
 * do NHIMY. Não interfere na lógica das ferramentas.
 *
 * A apresentação aparece na primeira entrada da sessão.
 * Depois, pode voltar automaticamente após 3 minutos de
 * inatividade e sai sozinha sem interromper o trabalho do usuário.
 */

(() => {
  const INTRO_KEY = "nhimy_intro_shown";
  const AUTO_ENTER_DELAY = 12000;
  const IDLE_RETURN_DELAY = 180000;
  const EXIT_DURATION = 650;

  const intro = document.getElementById("nhimyIntro");
  if (!intro) return;

  const reduceMotion = window.matchMedia(
    "(prefers-reduced-motion: reduce)"
  ).matches;

  let introTimer = null;
  let idleTimer = null;
  let visible = false;

  const clearIntroTimer = () => {
    if (introTimer) {
      clearTimeout(introTimer);
      introTimer = null;
    }
  };

  const clearIdleTimer = () => {
    if (idleTimer) {
      clearTimeout(idleTimer);
      idleTimer = null;
    }
  };

  const hideIntro = () => {
    clearIntroTimer();
    intro.classList.add("is-leaving");
    visible = false;

    window.setTimeout(() => {
      intro.style.display = "none";
      intro.setAttribute("aria-hidden", "true");
      intro.classList.remove("is-leaving");
    }, reduceMotion ? 120 : EXIT_DURATION);
  };

  const enterNHIMY = () => {
    if (!visible) return;
    hideIntro();
    scheduleIdleReturn();
  };

  const showIntro = () => {
    clearIdleTimer();
    clearIntroTimer();

    intro.style.display = "grid";
    intro.removeAttribute("aria-hidden");
    intro.classList.remove("is-leaving");

    /* Reinicia a assinatura visual para cada retorno. */
    void intro.offsetWidth;

    visible = true;

    if (reduceMotion) {
      introTimer = window.setTimeout(enterNHIMY, 120);
      return;
    }

    introTimer = window.setTimeout(enterNHIMY, AUTO_ENTER_DELAY);
  };

  const scheduleIdleReturn = () => {
    clearIdleTimer();
    idleTimer = window.setTimeout(showIntro, IDLE_RETURN_DELAY);
  };

  const markActivity = () => {
    if (visible) {
      return;
    }

    scheduleIdleReturn();
  };

  [
    "pointerdown",
    "pointermove",
    "keydown",
    "touchstart",
    "wheel",
    "scroll"
  ].forEach((eventName) => {
    window.addEventListener(eventName, markActivity, {
      passive: true,
      capture: true
    });
  });

  intro.addEventListener("click", (event) => {
    if (event.target.closest(".nhimy-intro-skip")) {
      enterNHIMY();
    }
  });

  const alreadyShown =
    sessionStorage.getItem(INTRO_KEY) === "1";

  if (alreadyShown) {
    intro.style.display = "none";
    intro.setAttribute("aria-hidden", "true");
    scheduleIdleReturn();
    return;
  }

  sessionStorage.setItem(INTRO_KEY, "1");
  showIntro();
})();
