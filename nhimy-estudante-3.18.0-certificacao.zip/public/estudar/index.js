"use strict";
import { getStudySession, startStudySession } from "/js/core/study/storage.js";
import { getStudyProgress, getStudyRoute } from "/js/core/study/workflow.js";

const withContent = document.getElementById("withContent");
const withTopic = document.getElementById("withTopic");
const form = document.getElementById("startForm");
const label = document.getElementById("startLabel");
const input = document.getElementById("startInput");
const help = document.getElementById("startHelp");
const button = document.getElementById("startButton");
const message = document.getElementById("startMessage");
let mode = "content";

function choose(next) {
  mode = next;
  form.hidden = false;
  label.textContent = mode === "topic" ? "O que queres estudar?" : "O teu conteúdo";
  input.placeholder = mode === "topic"
    ? "Ex.: fotossíntese, anatomia do coração, equações do 2.º grau..."
    : "Cole ou escreva aqui o conteúdo que queres estudar...";
  help.textContent = mode === "topic"
    ? "Não precisas ter material pronto. O Nhimy cria um roteiro inicial e indica como avançar sem inventar conteúdo que não recebeu."
    : "O conteúdo será organizado antes de entrares nas etapas de compreensão e prática.";
  message.textContent = "";
  input.value = "";
  input.focus();
}

withContent.addEventListener("click", () => choose("content"));
withTopic.addEventListener("click", () => choose("topic"));

button.addEventListener("click", () => {
  const value = input.value.trim();
  if (!value) {
    message.textContent = "Diz-nos por onde queres começar.";
    input.focus();
    return;
  }
  if (mode === "content" && value.length < 20) {
    message.textContent = "Adiciona pelo menos algumas frases para termos uma base útil. Se só tens o assunto, escolhe a opção de estudar por tema.";
    return;
  }
  startStudySession({
    topic: mode === "topic" ? value : "",
    source: mode === "content" ? value : "",
    sourceType: mode,
    stage: "preparar"
  });
  window.location.href = "/estudar/preparar/";
});

const session = getStudySession();
const continuePanel = document.getElementById("continuePanel");
if (session?.stage && continuePanel) {
  continuePanel.hidden = false;
  document.getElementById("continueText").textContent = session.topic || "Sessão com conteúdo";
  const progress = getStudyProgress(session);
  document.getElementById("continueProgress").style.width = `${progress}%`;
  document.getElementById("continueProgressLabel").textContent = `${progress}%`;
  document.getElementById("continueButton").href = getStudyRoute(session.stage);
}
