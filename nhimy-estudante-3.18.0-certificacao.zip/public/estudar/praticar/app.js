"use strict";
import { getStudySession, setStudySession, setPracticeResult } from "/js/core/study/storage.js";
import { guardStudyStage } from "/js/core/study/workflow.js";

const session = getStudySession();
if (!guardStudyStage("praticar", session)) {
  throw new Error("Etapa de estudo indisponível");
}
const empty = document.getElementById("empty");
const practice = document.getElementById("practice");
const title = document.getElementById("practiceTitle");
const progress = document.getElementById("practiceProgress");
const prompt = document.getElementById("challengePrompt");
const answer = document.getElementById("challengeAnswer");
const feedback = document.getElementById("challengeFeedback");
const check = document.getElementById("checkChallenge");
const skip = document.getElementById("skipChallenge");
const confidencePanel = document.getElementById("confidencePanel");
const finish = document.getElementById("finishPractice");
const note = document.getElementById("practiceNote");
const confidenceButtons = [...document.querySelectorAll("[data-confidence]")];

if (!session?.prepared) {
  empty.hidden = false;
} else {
  practice.hidden = false;

  const source = (session.source || session.prepared || session.topic || "este assunto").trim();
  const sentences = source.split(/(?<=[.!?])\s+/).map(s => s.trim()).filter(Boolean);
  const idea = sentences.find(s => s.length > 35) || source;
  const topic = session.topic || "este assunto";
  const challenges = [
    { label: "Recuperar", prompt: `Sem consultar a preparação, explica com as tuas palavras qual é a ideia mais importante sobre ${topic}.`, hint: `Uma boa resposta deve identificar a ideia central e não apenas repetir palavras do material. Pense em: “o que isto significa e por que importa?”` },
    { label: "Relacionar", prompt: `Escolhe duas ideias que apareceram no estudo de ${topic} e explica como elas se relacionam.`, hint: `Procura uma relação de causa, sequência, comparação, parte e todo, condição ou consequência.` },
    { label: "Aplicar", prompt: `Imagina uma situação nova em que o conhecimento sobre ${topic} seria útil. O que farias ou explicarias nessa situação?`, hint: `Não precisas copiar um exemplo do material. Mostra como transferir a ideia para um caso diferente.` }
  ];

  let index = 0;
  let attempts = 0;
  let selectedConfidence = "";
  let revealed = false;

  function render() {
    const item = challenges[index];
    title.textContent = `Desafio ${index + 1} de ${challenges.length} · ${item.label}`;
    progress.textContent = `Prática guiada sobre ${topic}`;
    prompt.textContent = item.prompt;
    answer.value = "";
    feedback.hidden = true;
    feedback.textContent = "";
    revealed = false;
    check.textContent = "Ver orientação →";
    skip.textContent = "Preciso de uma pista";
    answer.focus();
  }

  function reveal(kind = "feedback") {
    attempts++;
    const item = challenges[index];
    feedback.hidden = false;
    feedback.className = "study-feedback";
    if (kind === "hint") {
      feedback.innerHTML = `<strong>Pista</strong><p>${item.hint}</p>`;
      skip.textContent = "Já consigo tentar →";
      return;
    }
    const own = answer.value.trim();
    const useful = own.length >= 20;
    feedback.innerHTML = `<strong>${useful ? "Boa tentativa." : "Ainda falta desenvolver."}</strong><p>${item.hint}</p>${index === 0 ? `<p><strong>Base do estudo:</strong> ${idea.slice(0, 420)}</p>` : ""}`;
    revealed = true;
    check.textContent = index + 1 < challenges.length ? "Próximo desafio →" : "Avaliar minha prática →";
  }

  check.addEventListener("click", () => {
    if (!revealed) { reveal(); return; }
    index++;
    if (index >= challenges.length) {
      confidencePanel.hidden = false;
      confidencePanel.scrollIntoView({ behavior: "smooth", block: "start" });
      check.disabled = true;
      skip.disabled = true;
      return;
    }
    render();
  });

  skip.addEventListener("click", () => reveal("hint"));

  confidenceButtons.forEach(button => button.addEventListener("click", () => {
    confidenceButtons.forEach(item => item.classList.remove("selected"));
    button.classList.add("selected");
    selectedConfidence = button.dataset.confidence || "";
  }));

  finish.addEventListener("click", () => {
    if (!selectedConfidence) {
      confidencePanel.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    const result = setPracticeResult({ attempts, completed: true, confidence: selectedConfidence, note: note.value });
    setStudySession({ stage: "resultado", practiceCompleted: true, practiceResult: result });
    window.location.href = "/estudar/resultado/";
  });

  render();
}
