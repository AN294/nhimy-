"use strict";
import { getStudySession, setStudySession, setSummary } from "/js/core/study/storage.js";
import { guardStudyStage } from "/js/core/study/workflow.js";

const session = getStudySession();
if (!guardStudyStage("preparar", session)) {
  throw new Error("Etapa de estudo indisponível");
}
const empty = document.getElementById("empty");
const ready = document.getElementById("ready");

function cleanSentences(text) {
  return text
    .split(/(?<=[.!?])\s+/)
    .map(item => item.trim())
    .filter(Boolean);
}

function buildPreparation(s) {
  const raw = (s.source || s.topic || "").trim();
  if (s.source) {
    const sentences = cleanSentences(raw);
    const main = sentences[0] || raw;
    const keyPoints = sentences.slice(0, 5);
    const questions = [
      "Qual é a ideia central deste conteúdo?",
      "Quais conceitos preciso conseguir explicar sem consultar o texto?",
      "Que relação existe entre as ideias principais?",
      "Que exemplo consigo dar com as minhas próprias palavras?"
    ];
    return [
      `IDEIA CENTRAL\n${main}`,
      `\nPONTOS PARA OBSERVAR\n${keyPoints.map((p, i) => `${i + 1}. ${p}`).join("\n")}`,
      `\nPERGUNTAS-GUIA\n${questions.map((q, i) => `${i + 1}. ${q}`).join("\n")}`,
      "\nPRÓXIMO PASSO\nLê esta base, confirma se as ideias fazem sentido e segue para Compreender. O Nhimy não substitui a tua leitura crítica."
    ].join("\n");
  }

  return [
    `TEMA\n${s.topic}`,
    "\nAULA DE ARRANQUE\nO Nhimy vai acompanhar-te mesmo quando ainda não tens material. Nesta primeira passagem vamos construir um mapa para transformar o assunto em conhecimento.",
    `\nPERGUNTA CENTRAL\nO que precisas conseguir explicar sobre “${s.topic}” quando terminares o estudo?`,
    "\nCAMINHO DE APRENDIZAGEM\n1. Descobrir o significado e o contexto do tema.\n2. Identificar os conceitos que sustentam o assunto.\n3. Relacionar causas, partes, etapas, consequências ou aplicações.\n4. Trabalhar um exemplo concreto.\n5. Explicar com as tuas palavras.\n6. Praticar com uma situação nova.",
    "\nIMPORTANTE\nEste arranque é uma estrutura pedagógica. Quando estiver disponível uma fonte de conteúdo ou pesquisa adequada, ela deve preencher as afirmações factuais e permitir ao Nhimy explicar, exemplificar e verificar o que aprendeste.",
    "\nPRÓXIMO PASSO\nDiz o que já sabes sobre o tema — mesmo que seja pouco. O Nhimy usa isso para adaptar a explicação e identificar o que precisas aprender primeiro."
  ].join("\n");
}

if (!session) {
  empty.hidden = false;
  ready.hidden = true;
} else {
  const raw = session.source || session.topic;
  document.getElementById("topicTitle").textContent = session.topic ? `Vamos estudar: ${session.topic}` : "Conteúdo recebido";
  document.getElementById("sourceText").textContent = session.source
    ? `${raw.length} caracteres recebidos. Vamos transformar o material em uma base de estudo.`
    : "Temos apenas o assunto. Vamos criar um roteiro seguro para começar.";
  document.getElementById("preparedBox").textContent = buildPreparation(session);

  document.getElementById("prepare").addEventListener("click", () => {
    const focus = document.getElementById("focus").value.trim();
    const prepared = buildPreparation(session) + `\n\nFOCO DO ESTUDANTE\n${focus || "Compreender as ideias principais, conceitos, relações e aplicações."}`;
    setStudySession({ prepared, focus, stage: "compreender" });
    setSummary({ result: prepared, request: { mode: "study", label: "Preparação de estudo", instruction: "Continue para compreender o conteúdo." } });
    window.location.href = "/estudar/compreender/";
  });
}
