"use strict";
import { getStudySession, setStudySession } from "/js/core/study/storage.js";
import { guardStudyStage } from "/js/core/study/workflow.js";

const session = getStudySession();
if (!guardStudyStage("compreender", session)) {
  throw new Error("Etapa de estudo indisponível");
}
const box = document.getElementById("content");
const next = document.getElementById("next");
const explainLink = document.getElementById("explainLink");
const question = document.getElementById("question");
const checks = [...document.querySelectorAll("[data-comprehension]")];

if (!session?.prepared) {
  box.textContent = "Nenhuma preparação encontrada. Volta ao início para começar.";
  next.disabled = true;
} else {
  box.textContent = session.prepared;
  explainLink.href = "/estudar/explicar/";

  checks.forEach(button => button.addEventListener("click", () => {
    checks.forEach(item => item.classList.remove("selected"));
    button.classList.add("selected");
  }));

  next.addEventListener("click", () => {
    const selected = document.querySelector("[data-comprehension].selected");
    const comprehension = selected?.dataset.comprehension || "essencial";
    setStudySession({
      comprehension,
      comprehensionNote: question.value.trim(),
      stage: "revisar"
    });
    window.location.href = "/estudar/revisar/";
  });
}
