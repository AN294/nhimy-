"use strict";
import { getStudySession, getQuizResult, getPracticeResult, isReviewed, setStudySession } from "/js/core/study/storage.js";
import { guardStudyStage } from "/js/core/study/workflow.js";

const session = getStudySession();
if (!guardStudyStage("resultado", session)) {
  throw new Error("Etapa de estudo indisponível");
}
const quiz = getQuizResult();
const practice = getPracticeResult();

if (session) {
  document.getElementById("title").textContent = session.topic ? `Resultado: ${session.topic}` : "Resultado da sessão";
  document.getElementById("score").textContent = quiz && Number.isFinite(Number(quiz.total)) ? `${quiz.score}/${quiz.total}` : "Ainda não feito";
  document.getElementById("review").textContent = isReviewed() ? "Feita" : "Pendente";
  document.getElementById("cards").textContent = session.flashcardsCompleted ? "Feitos" : "Em aberto";
  const practiceMetric = document.getElementById("practice");
  if (practiceMetric) practiceMetric.textContent = practice?.completed ? "Feita" : "Pendente";

  const good = quiz && Number(quiz.total) > 0 ? Number(quiz.score) / Number(quiz.total) >= 0.7 : false;
  document.getElementById("message").textContent = quiz
    ? good
      ? "Boa base. Agora reforça o que erraste e volta ao assunto depois."
      : "O resultado mostra os pontos a reforçar. Isso faz parte de aprender."
    : session.flashcardsCompleted
      ? "Já fizeste uma prática. Completa o quiz quando quiseres medir melhor a compreensão."
      : "A sessão está preparada. Escolhe uma prática para obter evidências da tua aprendizagem.";

  const next = document.getElementById("next");
  if (quiz) {
    document.getElementById("nextText").textContent = good
      ? "Revisa os pontos difíceis e, se quiseres, inicia uma nova sessão mais tarde."
      : "Volta à revisão, identifica o que falhou e pratica novamente.";
    next.href = "/estudar/revisar/";
  } else if (session.flashcardsCompleted) {
    document.getElementById("nextText").textContent = "O próximo passo mais útil é fazer o quiz.";
    next.href = "/estudar/quiz/";
  } else {
    document.getElementById("nextText").textContent = "Começa pelos flashcards ou pelo quiz para transformar compreensão em prática.";
    next.href = "/estudar/praticar/";
  }
  setStudySession({ stage: "resultado", quizCompleted: Boolean(quiz), quizResult: quiz || null, practiceCompleted: Boolean(practice?.completed), practiceResult: practice || null });
} else {
  document.getElementById("message").textContent = "Nenhuma sessão encontrada.";
  document.getElementById("next").href = "/estudar/";
}
