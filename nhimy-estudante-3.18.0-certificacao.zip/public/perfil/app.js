import {getProfile,setProfile,clearProfile} from "/js/core/student/profile.js";
const name=document.querySelector('#name'),course=document.querySelector('#course'),institution=document.querySelector('#institution'),form=document.querySelector('#profileForm'),clear=document.querySelector('#clear'),status=document.querySelector('#status');
function render(){const p=getProfile();name.value=p.name;course.value=p.course;institution.value=p.institution}
form.addEventListener('submit',e=>{e.preventDefault();if(setProfile({name:name.value,course:course.value,institution:institution.value})){status.textContent='✓ Perfil guardado.'}else status.textContent='Não foi possível guardar agora.'});
clear.addEventListener('click',()=>{clearProfile();render();status.textContent='Perfil limpo.'});render();
