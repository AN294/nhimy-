import { touch } from "/js/core/student/session.js";
import { initAccountSync } from "/js/core/account/sync.js";
"use strict";

function closeMenu(button, nav) {
  nav.classList.remove("is-open");
  button.setAttribute("aria-expanded", "false");
  button.setAttribute("aria-label", "Abrir menu");
}

export function initNavigation() {
  initAccountSync();
  touch(document.body?.dataset?.module || document.title.split(" — ")[0] || "", window.location.pathname);
  const menus = document.querySelectorAll(".menu-button");

  menus.forEach((button) => {
    if (button.dataset.navigationReady === "true") return;
    const header = button.closest(".header-inner, .header-content, .site-header");
    const nav = header?.querySelector(".desktop-nav, .main-nav");
    if (!nav) return;

    button.dataset.navigationReady = "true";
    button.setAttribute("aria-expanded", "false");
    button.setAttribute("aria-controls", nav.id || "nhimy-mobile-nav");
    if (!nav.id) nav.id = "nhimy-mobile-nav";

    button.addEventListener("click", () => {
      const open = !nav.classList.contains("is-open");
      nav.classList.toggle("is-open", open);
      button.setAttribute("aria-expanded", String(open));
      button.setAttribute("aria-label", open ? "Fechar menu" : "Abrir menu");
    });

    nav.querySelectorAll("a").forEach((link) => {
      link.addEventListener("click", () => closeMenu(button, nav));
    });

    window.addEventListener("resize", () => {
      if (window.innerWidth >= 768) closeMenu(button, nav);
    });
  });

  // Same-page anchors (used by Ferramentas and lightweight landing sections).
  document.querySelectorAll('a[href^="#"]').forEach((link) => {
    if (link.dataset.anchorReady === "true") return;
    link.dataset.anchorReady = "true";
    link.addEventListener("click", (event) => {
      const targetId = link.getAttribute("href");
      if (!targetId || targetId === "#") return;
      const target = document.querySelector(targetId);
      if (!target) return;
      event.preventDefault();
      target.scrollIntoView({ behavior: "smooth", block: "start" });
      history.replaceState(null, "", targetId);
    });
  });
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initNavigation, { once: true });
} else {
  initNavigation();
}
