const CONSENT_KEY = "nhimy.ads.consent";

export function getAdConsent() {
  try { return localStorage.getItem(CONSENT_KEY) || "unknown"; } catch (_) { return "unknown"; }
}

export function setAdConsent(value) {
  const normalized = ["granted", "denied"].includes(value) ? value : "unknown";
  try { localStorage.setItem(CONSENT_KEY, normalized); } catch (_) {}
  return normalized;
}

export function monetizationEnabled(config = {}) {
  return config.enabled === true && Boolean(config.provider) && Boolean(config.publisherId);
}

export function createAdPlaceholder(label = "Espaço publicitário") {
  const el = document.createElement("div");
  el.className = "nhimy-ad-slot";
  el.setAttribute("data-monetization", "prepared");
  el.setAttribute("aria-label", label);
  el.textContent = "Publicidade — preparada, não ativada";
  return el;
}
