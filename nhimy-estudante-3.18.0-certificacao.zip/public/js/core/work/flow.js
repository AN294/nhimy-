"use strict";

import { getCompletedWorkStages, getWorkProgress as calculateWorkProgress } from "./workflow.js";

export function getWorkProgress(project) {
  return calculateWorkProgress(project);
}

export function updateWorkProgress(project) {
  const progress = document.querySelector(".work-progress");
  if (!progress) return;
  const currentStage = progress.dataset.currentStage || "";
  const completed = getCompletedWorkStages(project);
  const steps = progress.querySelectorAll(".work-progress-step");
  steps.forEach((step, index) => {
    step.classList.remove("active", "completed");
    const stageKey = ["criar", "orientar", "estruturar", "desenvolver", "revisar", "finalizar"][index];
    if (stageKey === currentStage) step.classList.add("active");
    else if (completed.has(stageKey)) step.classList.add("completed");
  });
  progress.dataset.progress = String(calculateWorkProgress(project));
}

export function initWorkProgress(project) { updateWorkProgress(project); }
