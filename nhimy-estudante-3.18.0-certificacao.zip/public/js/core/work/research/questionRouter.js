"use strict";

import { selectResearchSection } from "./sectionSelector.js";

function normalizeText(value) { return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim(); }
function domain(subject, topic) {
  const s = normalizeText(`${subject} ${topic}`);
  if (/saude|biologia|medicina|enfermagem|farmacia|nutricao|quimica|microbiologia/.test(s)) return "science";
  if (/historia|geografia|sociologia|filosofia|politica|direito|economia|educacao|literatura|lingua|portugues|artes/.test(s)) return "humanities";
  if (/informatica|computacao|programacao|tecnologia|engenharia/.test(s)) return "technology";
  return "general";
}
const intentTerms = {
  definition: ["definition", "concept", "what is", "context", "origin"],
  factors: ["causes", "factors", "risk", "associated", "why"],
  consequences: ["effects", "impact", "consequences", "results", "outcomes"],
  symptoms: ["symptoms", "signs", "manifestations"],
  diagnosis: ["diagnosis", "screening", "assessment"],
  prevention: ["prevention", "prevent", "avoid", "measures"],
  treatment: ["treatment", "therapy", "intervention", "care"],
  importance: ["importance", "relevance", "why is it important"],
  conclusion: ["conclusion", "synthesis", "summary"]
};
function detectIntent(question) {
  const q = normalizeText(question);
  for (const [intent, terms] of Object.entries(intentTerms)) if (terms.some(t => q.includes(t))) return intent;
  return "general";
}
function buildQuery(question, topic, subject, intent) {
  const d = domain(subject, topic);
  const core = [topic, subject].filter(Boolean).join(" ");
  const intentMap = { definition: "definition concept context", factors: "causes factors associated", consequences: "effects impact consequences", importance: "importance relevance", prevention: "prevention measures", treatment: "treatment intervention", conclusion: "review synthesis", general: "overview" };
  if (d === "science") return `${core} ${intentMap[intent] || "overview"}`.trim();
  return `${core} ${intentMap[intent] || "overview"}`.trim();
}

export function routeResearchQuestion(question, { topic = "", subject = "", sections = [] } = {}) {
  if (typeof question !== "string" || !question.trim()) throw new Error("Pergunta de pesquisa inválida.");
  const sectionResult = selectResearchSection(question, { sections });
  const intent = sectionResult.intent || detectIntent(question);
  return { question: question.trim(), topic: String(topic || "").trim(), subject: String(subject || "").trim(), section: sectionResult.section, intent, confidence: sectionResult.confidence, reason: sectionResult.reason, researchType: domain(subject, topic) === "science" ? intent : "general", providerHint: domain(subject, topic), query: buildQuery(question, topic, subject, intent), status: "ready" };
}
