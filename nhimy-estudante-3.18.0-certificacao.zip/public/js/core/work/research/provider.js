"use strict";

const EUROPE_PMC_URL = "https://www.ebi.ac.uk/europepmc/webservices/rest/search";
const WIKIPEDIA_API = "https://pt.wikipedia.org/w/api.php";

async function fetchJson(url, timeout = 15000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);
  try {
    const response = await fetch(url, { signal: controller.signal, headers: { "User-Agent": "Nhimy/3.0" } });
    if (!response.ok) throw new Error(`Provider respondeu com HTTP ${response.status}.`);
    return await response.json();
  } finally { clearTimeout(timer); }
}

export async function searchEuropePMC(query, { pageSize = 5 } = {}) {
  if (!String(query || "").trim()) throw new Error("Query de pesquisa inválida.");
  const url = new URL(EUROPE_PMC_URL);
  url.searchParams.set("query", query.trim()); url.searchParams.set("resultType", "core"); url.searchParams.set("format", "json"); url.searchParams.set("pageSize", String(pageSize));
  return fetchJson(url.toString(), 20000);
}

export function normalizeEuropePMCResult(article = {}) {
  const title = typeof article.title === "string" ? article.title.trim() : "";
  const url = article.fullTextUrlList?.fullTextUrl?.[0]?.url || (article.pmid ? `https://pubmed.ncbi.nlm.nih.gov/${article.pmid}/` : "");
  return { title, url, publisher: article.journalTitle || "Europe PMC", abstract: typeof article.abstractText === "string" ? article.abstractText.trim() : "", authors: Array.isArray(article.authorList?.author) ? article.authorList.author.map(a => ({ firstName: a.firstName || "", lastName: a.lastName || "" })) : [], publicationDate: article.firstPublicationDate || "", sourceId: article.id || "", sourceDatabase: article.source || "Europe PMC" };
}
export function normalizeEuropePMCResults(data = {}) { return Array.isArray(data.resultList?.result) ? data.resultList.result.map(normalizeEuropePMCResult).filter(a => a.title && a.url) : []; }

export async function searchWikipedia(query, { pageSize = 5 } = {}) {
  if (!String(query || "").trim()) throw new Error("Query de pesquisa inválida.");
  const url = new URL(WIKIPEDIA_API);
  url.searchParams.set("action", "query"); url.searchParams.set("format", "json"); url.searchParams.set("origin", "*"); url.searchParams.set("generator", "search"); url.searchParams.set("gsrsearch", query.trim()); url.searchParams.set("gsrlimit", String(pageSize)); url.searchParams.set("prop", "extracts|info"); url.searchParams.set("exintro", "1"); url.searchParams.set("explaintext", "1"); url.searchParams.set("inprop", "url");
  return fetchJson(url.toString(), 15000);
}
export function normalizeWikipediaResults(data = {}) {
  return Object.values(data.query?.pages || {}).map(page => ({ title: String(page.title || "").trim(), url: page.fullurl || `https://pt.wikipedia.org/wiki/${encodeURIComponent(page.title || "").replaceAll("%20", "_")}`, publisher: "Wikipédia", abstract: String(page.extract || "").trim(), authors: [], publicationDate: "", sourceId: `wikipedia:${page.pageid || page.title}`, sourceDatabase: "Wikipédia" })).filter(x => x.title && x.url);
}

export async function searchWorkSources(query, { provider = "general", pageSize = 5 } = {}) {
  if (provider === "science") {
    try { return { provider: "europe-pmc", articles: normalizeEuropePMCResults(await searchEuropePMC(query, { pageSize })) }; }
    catch (error) { console.warn("Europe PMC indisponível; tentando fonte geral.", error.message); }
  }
  const data = await searchWikipedia(query, { pageSize });
  return { provider: "wikipedia", articles: normalizeWikipediaResults(data) };
}
