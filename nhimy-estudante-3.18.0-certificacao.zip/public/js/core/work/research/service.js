"use strict";
import { collectResearch as collectResearchFromCollector } from "./collector.js";
import { createResearchResult } from "../research.js";

export function validateResearchRequest(request) {
  if (!request || typeof request !== "object") return { valid: false, error: "Research request inválido." };
  if (request.type !== "work-research-request") return { valid: false, error: "Tipo de Research request inválido." };
  if (typeof request.topic !== "string" || !request.topic.trim()) return { valid: false, error: "O tema da pesquisa é obrigatório." };
  if (request.topic.length > 500) return { valid: false, error: "O tema é demasiado longo." };
  const hasQuestions = Array.isArray(request.questions) && request.questions.length;
  const hasUnits = Array.isArray(request.researchUnits) && request.researchUnits.length;
  if (!hasQuestions && !hasUnits) return { valid: false, error: "As perguntas ou unidades de pesquisa são obrigatórias." };
  if (hasQuestions && request.questions.length > 20) return { valid: false, error: "A pesquisa pode conter no máximo 20 perguntas." };
  if (hasUnits && request.researchUnits.length > 20) return { valid: false, error: "A pesquisa pode conter no máximo 20 unidades." };
  if (request.subject != null && typeof request.subject !== "string") return { valid: false, error: "Formato de disciplina inválido." };
  if (typeof request.subject === "string" && request.subject.length > 300) return { valid: false, error: "A disciplina é demasiado longa." };
  if (request.sectionTargets != null && !Array.isArray(request.sectionTargets)) return { valid: false, error: "Formato de seções inválido." };
  if (request.queries != null && !Array.isArray(request.queries)) return { valid: false, error: "Formato de queries inválido." };

  const questionItems = hasQuestions ? request.questions : [];
  for (const item of questionItems) {
    if (typeof item === "string") {
      if (item.trim().length > 500) return { valid: false, error: "Uma pergunta é demasiado longa." };
      continue;
    }
    if (!item || typeof item !== "object") return { valid: false, error: "Formato de pergunta inválido." };
    for (const field of ["question", "query", "intent", "researchType", "section"]) {
      if (item[field] != null && typeof item[field] !== "string") return { valid: false, error: `Campo de pergunta inválido: ${field}.` };
      if (typeof item[field] === "string" && item[field].length > 500) return { valid: false, error: `Campo de pergunta demasiado longo: ${field}.` };
    }
  }

  const unitItems = hasUnits ? request.researchUnits : [];
  for (const item of unitItems) {
    if (!item || typeof item !== "object" || Array.isArray(item)) return { valid: false, error: "Formato de unidade de pesquisa inválido." };
    for (const field of ["question", "query", "intent", "researchType", "section", "providerHint"]) {
      if (item[field] != null && typeof item[field] !== "string") return { valid: false, error: `Campo de unidade inválido: ${field}.` };
      if (typeof item[field] === "string" && item[field].length > 500) return { valid: false, error: `Campo de unidade demasiado longo: ${field}.` };
    }
    if (!String(item.query || item.question || "").trim()) return { valid: false, error: "Cada unidade precisa de uma pergunta ou query." };
  }

  return { valid: true };
}

export async function collectResearch(request) {
  const validation = validateResearchRequest(request);
  if (!validation.valid) throw new Error(validation.error);
  const collected = await collectResearchFromCollector(request);
  return createResearchResult({ topic: collected.topic, findings: collected.findings, sources: collected.findings.flatMap(f => Array.isArray(f.sources) ? f.sources : []) });
}
