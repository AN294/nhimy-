"use strict";

/**
 * NHIMY — Work Research Collector
 *
 * Responsabilidades:
 *
 * 1. Receber um work-research-request.
 * 2. Executar pesquisas através dos providers.
 * 3. Filtrar artigos relevantes.
 * 4. Associar resultados às perguntas e seções.
 * 5. Evitar duplicações.
 * 6. Produzir findings estruturados.
 *
 * O Collector NÃO:
 * - cria perguntas;
 * - constrói queries;
 * - decide a intenção.
 *
 * Essas responsabilidades pertencem ao:
 * - sectionSelector
 * - questionRouter
 * - requestBuilder
 */

import {
  searchWorkSources
} from "./provider.js";


/**
 * Normaliza texto para comparação.
 */
function normalizeText(value) {
  return String(value || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}


/**
 * Cria uma requisição própria do Collector.
 */
export function createCollectorRequest(request) {
  if (
    !request ||
    typeof request !== "object"
  ) {
    throw new Error(
      "Research request inválido."
    );
  }

  if (
    request.type !== "work-research-request"
  ) {
    throw new Error(
      "Tipo de Research request inválido."
    );
  }

  const sectionTargets =
    Array.isArray(request.sectionTargets)
      ? request.sectionTargets
      : [];

  const existingUnits =
    Array.isArray(request.researchUnits)
      ? request.researchUnits
      : [];

  const questions =
    Array.isArray(request.questions)
      ? request.questions
      : [];

  const researchUnits =
    existingUnits.length
      ? existingUnits
      : questions.map(
          (question, index) => ({
            question:
              typeof question === "string"
                ? question
                : question?.question || "",

            query:
              typeof question === "string"
                ? question
                : question?.query ||
                  question?.question ||
                  "",

            intent:
              typeof question === "object"
                ? question?.intent || ""
                : "",

            researchType:
              typeof question === "object"
                ? question?.researchType || ""
                : "",

            section:
              typeof question === "object"
                ? question?.section ||
                  ""
                : sectionTargets[index] ||
                  sectionTargets[0] ||
                  ""
          })
        )
      .filter(
        unit =>
          unit.question ||
          unit.query
      );

  return {
    status: "success",

    type:
      "work-research-collect-request",

    topic:
      request.topic || "",

    subject:
      request.subject || "",

    researchUnits,

    queries:
      Array.isArray(request.queries)
        ? request.queries
        : [],

    sectionTargets,

    sourcePolicy:
      request.sourcePolicy || {
        requireSource: true,
        preserveSourceDetails: true,
        allowStudentMaterials: true,
        allowExternalSources: true
      },

    nextStep: "collect"
  };
}


/**
 * Normaliza um finding.
 */
export function normalizeFinding(
  finding = {}
) {
  return {
    section:
      finding.section || "",

    question:
      finding.question || "",

    intent:
      finding.intent || "",

    researchType:
      finding.researchType || "",

    text:
      finding.text || "",

    sourceIds:
      Array.isArray(finding.sourceIds)
        ? finding.sourceIds
        : [],

    sources:
      Array.isArray(finding.sources)
        ? finding.sources
        : [],

    relevance:
      Number(
        finding.relevance || 0
      )
  };
}


/**
 * Normaliza uma fonte.
 */
export function normalizeSource(
  source = {}
) {
  const title =
    source.title ||
    "";

  const url =
    source.url ||
    "";

  const id =
    source.id ||
    source.pmid ||
    source.pmcid ||
    url ||
    title;

  return {
    id: String(id || ""),

    title:
      String(title || ""),

    url:
      String(url || ""),

    publisher:
      String(
        source.publisher ||
        source.sourceDatabase ||
        "Fonte externa"
      ),

    doi:
      String(
        source.doi ||
        ""
      ),

    authors:
      Array.isArray(source.authors)
        ? source.authors
        : [],

    year:
      source.year ||
      source.publicationYear ||
      ""
  };
}


/**
 * Extrai termos úteis de uma query.
 *
 * Não tentamos interpretar operadores booleanos.
 * O objetivo aqui é apenas obter palavras científicas
 * que possam aparecer no artigo.
 */
function extractTerms(value) {
  return normalizeText(value).split(/\s+/).map(x => x.replace(/[^a-z0-9-]/g, "")).filter(x => x.length >= 4 && !["sobre","para","com","qual","quais","como","este","esta","esse","essa","sao","dos","das","uma","uns","por","entre","mais","menos"].includes(x));
}
function calculateRelevance(article, unit = {}, topic = "") {
  const text = normalizeText(`${article?.title || ""} ${article?.abstract || ""}`);
  const terms = [...new Set([...extractTerms(topic), ...extractTerms(unit.query || "")])];
  let score = 0;
  terms.forEach(term => { if (normalizeText(article?.title).includes(term)) score += 3; else if (text.includes(term)) score += 1; });
  if (article?.abstract) score += 1;
  return score;
}
export function isRelevantArticle(article, queryOrContext, topic = "") {
  if (!article || typeof article !== "object") return false;
  const context = queryOrContext && typeof queryOrContext === "object" ? queryOrContext : { query: String(queryOrContext || ""), topic };
  return calculateRelevance(article, context, context.topic || topic) >= 2;
}

/**
 * Cria um finding a partir de um artigo.
 */
function createFinding(
  article,
  unit,
  topic
) {
  const source =
    normalizeSource(
      article
    );

  const relevance =
    calculateRelevance(
      article,
      unit,
      topic
    );

  return normalizeFinding({
    section:
      unit.section || "",

    question:
      unit.question || "",

    intent:
      unit.intent || "",

    researchType:
      unit.researchType || "",

    text:
      article.abstract ||
      article.title ||
      "",

    sourceIds: [
      source.id
    ].filter(Boolean),

    sources: [
      source
    ].filter(
      item =>
        item.title ||
        item.url
    ),

    relevance
  });
}


/**
 * Remove findings duplicados.
 */
function deduplicateFindings(
  findings
) {
  const seen =
    new Set();

  return findings.filter(
    finding => {

      const sourceId =
        finding.sourceIds?.[0] ||
        finding.sources?.[0]?.id ||
        finding.sources?.[0]?.url ||
        finding.text;

      if (!sourceId) {
        return true;
      }

      if (
        seen.has(sourceId)
      ) {
        return false;
      }

      seen.add(sourceId);

      return true;
    }
  );
}


/**
 * Executa uma unidade de pesquisa.
 */
async function collectResearchUnit(unit, { topic, subject, pageSize = 5 } = {}) {
  if (!unit?.query) return [];
  const provider = unit.providerHint || (unit.researchType && unit.researchType !== "general" ? "science" : "general");
  const result = await searchWorkSources(unit.query, { provider, pageSize });
  return result.articles.filter(article => isRelevantArticle(article, { query: unit.query, topic, subject, intent: unit.intent }, topic)).map(article => createFinding(article, { ...unit, provider: result.provider }, topic));
}

/**
 * Executa a coleta completa.
 */
export async function collectResearch(
  request,
  {
    pageSize = 5
  } = {}
) {
  const normalizedRequest =
    createCollectorRequest(
      request
    );

  const findings = [];

  for (
    const unit
    of normalizedRequest.researchUnits
  ) {
    const unitFindings =
      await collectResearchUnit(
        unit,
        {
          topic:
            normalizedRequest.topic,

          subject:
            normalizedRequest.subject,

          pageSize
        }
      );

    findings.push(
      ...unitFindings
    );
  }

  const uniqueFindings =
    deduplicateFindings(
      findings
    );

  const sourceMap =
    new Map();

  for (
    const finding
    of uniqueFindings
  ) {
    for (
      const source
      of finding.sources || []
    ) {
      const id =
        source.id ||
        source.url ||
        source.title;

      if (
        id &&
        !sourceMap.has(id)
      ) {
        sourceMap.set(
          id,
          source
        );
      }
    }
  }

  return {
    status:
      "success",

    type:
      "work-research-collect-result",

    topic:
      normalizedRequest.topic,

    subject:
      normalizedRequest.subject,

    findings:
      uniqueFindings,

    totalFindings:
      uniqueFindings.length,

    sourceCount:
      sourceMap.size,

    nextStep:
      "integrate"
  };
}
