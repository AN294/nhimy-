"use strict";

import { normalizeStructure, uid } from "./storage.js";

const PURPOSES = {
  introducao: "Apresentar o tema, contextualizar o assunto e indicar o objetivo do trabalho.",
  objetivos: "Definir o que o trabalho pretende analisar, explicar ou demonstrar.",
  justificativa: "Explicar a relevância do tema e a razão de abordar este assunto.",
  fundamentacao: "Apresentar conceitos, conhecimentos e referências que sustentam o trabalho.",
  metodologia: "Explicar como as informações foram pesquisadas, selecionadas ou analisadas.",
  desenvolvimento: "Desenvolver os principais aspectos do tema com explicações e evidências.",
  analise: "Interpretar as informações encontradas e relacioná-las com o tema.",
  resultados: "Apresentar os principais resultados ou descobertas do trabalho.",
  conclusao: "Retomar as ideias centrais, responder ao objetivo e sintetizar o que foi desenvolvido.",
  referencias: "Registar apenas as fontes realmente utilizadas na construção do trabalho."
};

function key(title) {
  return String(title || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9 ]/g, "");
}
function section(title, purpose) { return { id: uid("sec"), title, purpose: purpose || PURPOSES[key(title).split(" ")[0]] || "Desenvolver esta parte de forma coerente com o tema e o objetivo do trabalho.", order: 0 }; }

export function suggestStructure({ type = "", subject = "", orientationContext = "", researchPlan = null } = {}) {
  const t = String(type || "").toLowerCase();
  const subjectText = String(subject || "").toLowerCase();
  const requested = Array.isArray(researchPlan?.sections) ? researchPlan.sections : [];
  if (requested.length) return normalizeStructure(requested.map((s, i) => ({ ...s, id: s.id || uid("sec"), order: i })));

  let titles;
  if (t.includes("relatorio")) titles = ["Introdução", "Objetivos", "Metodologia", "Desenvolvimento", "Resultados", "Conclusão", "Referências"];
  else if (t.includes("pesquisa")) titles = ["Introdução", "Contextualização do tema", "Fundamentação teórica", "Desenvolvimento", "Análise", "Conclusão", "Referências"];
  else if (t.includes("apresent")) titles = ["Introdução", "Tema principal", "Pontos essenciais", "Conclusão"];
  else titles = ["Introdução", "Desenvolvimento", "Conclusão", "Referências"];

  if (/saude|biologia|quimica|fisica|medicina|enfermagem|farmacia|nutricao/.test(subjectText) && t.includes("pesquisa")) {
    titles = ["Introdução", "Contextualização", "Fundamentação teórica", "Principais aspectos", "Prevenção e/ou aplicações", "Conclusão", "Referências"];
  }
  if (orientationContext && /metodologia|método|metodo/.test(orientationContext)) {
    if (!titles.includes("Metodologia")) titles.splice(2, 0, "Metodologia");
  }
  return titles.map((title, i) => ({ ...section(title), order: i }));
}
