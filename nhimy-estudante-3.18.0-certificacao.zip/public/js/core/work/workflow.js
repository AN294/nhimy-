"use strict";

/**
 * NHIMY — TRABALHOS / WORKFLOW 2
 * Fonte única para prontidão, etapa atual e navegação.
 * Não grava estado.
 */

const STAGES = Object.freeze([
  { key: "criar", route: "/trabalhos/criar/", label: "Criar" },
  { key: "orientar", route: "/trabalhos/orientar/", label: "Orientar" },
  { key: "estruturar", route: "/trabalhos/estruturar/", label: "Estruturar" },
  { key: "desenvolver", route: "/trabalhos/desenvolver/", label: "Desenvolver" },
  { key: "revisar", route: "/trabalhos/revisar/", label: "Revisar" },
  { key: "finalizar", route: "/trabalhos/finalizar/", label: "Finalizar" }
]);

function hasText(value) { return typeof value === "string" && value.trim().length > 0; }
function hasStructure(project) { return Array.isArray(project?.structure) && project.structure.length > 0; }
function filledSections(project) {
  const structure = Array.isArray(project?.structure) ? project.structure : [];
  const content = project?.content && typeof project.content === "object" ? project.content : {};
  return structure.filter(section => hasText(content[section.id])).length;
}
function hasAllContent(project) { return hasStructure(project) && filledSections(project) === project.structure.length; }

export function getWorkReadiness(project) {
  const exists = !!project;
  const identity = exists && hasText(project.title) && hasText(project.subject);
  const orientation = identity && project.orientationReady === true;
  const structure = orientation && hasStructure(project);
  const development = structure && hasAllContent(project);
  const review = development && project.reviewed === true;
  const finalized = review && project.finalized === true;
  return Object.freeze({ exists, identity, orientation, structure, development, review, finalized });
}

export function getCurrentWorkStage(project) {
  const ready = getWorkReadiness(project);
  if (!ready.exists) return "criar";
  if (!ready.identity || !ready.orientation) return "orientar";
  if (!ready.structure) return "estruturar";
  if (!ready.development) return "desenvolver";
  if (!ready.review) return "revisar";
  return "finalizar";
}

export function getWorkRoute(project) {
  const key = getCurrentWorkStage(project);
  return STAGES.find(stage => stage.key === key)?.route || "/trabalhos/criar/";
}

export function canAccessWorkStage(project, stageKey) {
  if (stageKey === "criar") return true;
  const ready = getWorkReadiness(project);
  if (!ready.exists) return false;
  if (stageKey === "orientar") return ready.exists && hasText(project.subject);
  if (stageKey === "estruturar") return ready.orientation;
  if (stageKey === "desenvolver") return ready.structure;
  if (stageKey === "revisar") return ready.development;
  if (stageKey === "finalizar") return ready.review;
  return false;
}

export function guardWorkStage(project, stageKey) {
  if (canAccessWorkStage(project, stageKey)) return true;
  window.location.replace(getWorkRoute(project));
  return false;
}

export function getCompletedWorkStages(project) {
  const ready = getWorkReadiness(project);
  const completed = new Set();
  if (ready.identity) completed.add("criar");
  if (ready.orientation) completed.add("orientar");
  if (ready.structure) completed.add("estruturar");
  if (ready.development) completed.add("desenvolver");
  if (ready.review) completed.add("revisar");
  if (ready.finalized) completed.add("finalizar");
  return completed;
}

export function getWorkProgress(project) {
  const ready = getWorkReadiness(project);
  if (!ready.exists) return 0;
  const checks = [ready.identity, ready.orientation, ready.structure, ready.development, ready.review, ready.finalized];
  return Math.round(checks.filter(Boolean).length / checks.length * 100);
}

export { STAGES };
