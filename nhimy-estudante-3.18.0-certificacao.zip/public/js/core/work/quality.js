"use strict";

function words(value) { return String(value || "").trim().split(/\s+/).filter(Boolean).length; }
function normalize(value) { return String(value || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, ""); }

export function analyzeWork(project = {}) {
  const structure = Array.isArray(project.structure) ? project.structure : [];
  const content = project.content && typeof project.content === "object" ? project.content : {};
  const issues = [];
  const warnings = [];
  let filled = 0;
  const texts = [];

  structure.forEach(section => {
    const value = typeof content[section.id] === "string" ? content[section.id].trim() : "";
    const count = words(value);
    if (value) filled++;
    if (!value) issues.push({ code: "empty-section", severity: "high", sectionId: section.id, message: `A seção “${section.title}” ainda está vazia.` });
    else if (count < 25 && !/refer/i.test(section.title)) warnings.push({ code: "short-section", severity: "medium", sectionId: section.id, message: `A seção “${section.title}” está muito curta (${count} palavras).` });
    texts.push({ id: section.id, title: section.title, normalized: normalize(value) });
  });

  for (let i = 0; i < texts.length; i++) for (let j = i + 1; j < texts.length; j++) {
    if (texts[i].normalized && texts[i].normalized === texts[j].normalized) warnings.push({ code: "duplicate-section", severity: "medium", sectionId: texts[j].id, message: `“${texts[i].title}” e “${texts[j].title}” têm conteúdo idêntico.` });
  }

  const references = structure.find(s => /refer/i.test(s.title));
  if (project.research?.sourceCount > 0 && references && !String(content[references.id] || "").trim()) issues.push({ code: "missing-references", severity: "high", sectionId: references.id, message: "Há fontes pesquisadas, mas a seção de referências está vazia." });
  if (!project.title) issues.push({ code: "missing-title", severity: "high", message: "O trabalho precisa de um tema ou título." });
  if (!project.subject) warnings.push({ code: "missing-subject", severity: "medium", message: "A disciplina ainda não foi identificada." });

  const total = structure.length;
  const completion = total ? Math.round((filled / total) * 100) : 0;
  const score = Math.max(0, Math.min(100, completion - issues.length * 12 - warnings.length * 4));
  const status = issues.length ? "attention" : warnings.length ? "improve" : completion === 100 ? "ready" : "incomplete";
  return { status, score, completion, totalSections: total, filledSections: filled, issues, warnings, checkedAt: new Date().toISOString() };
}
