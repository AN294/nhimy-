"use strict";

import { emitStateChange } from "../student/events.js";

const KEY = "nhimy.work.project";
const VERSION = 5;

const LIMITS = Object.freeze({
  title: 200,
  subject: 200,
  type: 100,
  orientation: 5000,
  orientationContext: 10000,
  sectionTitle: 200,
  sectionPurpose: 1000,
  sectionContent: 50000,
  totalContent: 300000,
  researchPlan: 50000,
  researchRequest: 50000,
  research: 150000,
  qualityReport: 30000,
  reviewChecks: 2000
});

function uid(prefix = "sec") {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
}

function text(value, max = Number.MAX_SAFE_INTEGER) {
  if (typeof value !== "string") return "";
  return value.trim().slice(0, max);
}

function safeObject(value, maxBytes) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  try {
    const json = JSON.stringify(value);
    return json.length <= maxBytes ? { ...value } : null;
  } catch {
    return null;
  }
}

function normalizeSection(section, index = 0) {
  if (typeof section === "string") {
    const title = text(section, LIMITS.sectionTitle) || `Seção ${index + 1}`;
    return { id: `legacy-${index + 1}-${slug(title)}`, title, purpose: "", order: index };
  }
  if (!section || typeof section !== "object") return null;
  const title = text(section.title, LIMITS.sectionTitle) || `Seção ${index + 1}`;
  return {
    id: text(section.id) || uid("sec"),
    title,
    purpose: text(section.purpose, LIMITS.sectionPurpose),
    order: Number.isFinite(section.order) ? section.order : index
  };
}

function slug(value) {
  return text(value).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 42) || "secao";
}

function normalizeStructure(value) {
  if (!Array.isArray(value)) return [];
  const used = new Set();
  return value.map((item, index) => normalizeSection(item, index)).filter(Boolean).map((item, index) => {
    let id = item.id;
    while (used.has(id)) id = uid("sec");
    used.add(id);
    return { ...item, id, order: index };
  });
}

function migrateContent(rawContent, oldStructure, structure) {
  const source = rawContent && typeof rawContent === "object" && !Array.isArray(rawContent) ? rawContent : {};
  const result = {};
  let total = 0;
  const old = Array.isArray(oldStructure) ? oldStructure : [];
  const oldWasStable = old.some(item => item && typeof item === "object" && item.id);
  if (oldWasStable) {
    structure.forEach(section => {
      const value = source[section.id];
      if (typeof value === "string") { const safe = value.slice(0, LIMITS.sectionContent); if (total + safe.length <= LIMITS.totalContent) { result[section.id] = safe; total += safe.length; } }
    });
    return result;
  }
  structure.forEach((section, index) => {
    const candidates = [source[index], source[String(index)], source[section.title]];
    const value = candidates.find(item => typeof item === "string");
    if (typeof value === "string") { const safe = value.slice(0, LIMITS.sectionContent); if (total + safe.length <= LIMITS.totalContent) { result[section.id] = safe; total += safe.length; } }
  });
  return result;
}

function migrateChecks(rawChecks, oldStructure, structure) {
  const source = rawChecks && typeof rawChecks === "object" ? rawChecks : {};
  const result = {};
  const old = Array.isArray(oldStructure) ? oldStructure : [];
  const stable = old.some(item => item && typeof item === "object" && item.id);
  if (stable) return { ...source };
  structure.forEach((section, index) => {
    ["content", "clarity", "sources"].forEach(kind => {
      const value = source[`${index}.${kind}`];
      if (value === true) result[`${section.id}.${kind}`] = true;
    });
  });
  return result;
}

function invalidateDownstream(project, changed) {
  if (!changed) return project;
  return {
    ...project,
    orientationReady: false,
    researchReady: false,
    researchStatus: "pending",
    researchPlan: null,
    researchRequest: null,
    research: null,
    structure: [],
    content: {},
    reviewed: false,
    reviewChecks: {},
    qualityReport: null,
    finalized: false,
    finalVersion: null
  };
}

function normalizeProject(input = {}) {
  const raw = input && typeof input === "object" ? input : {};
  const oldStructure = Array.isArray(raw.structure) ? raw.structure : [];
  const structure = normalizeStructure(oldStructure);
  const project = {
    version: VERSION,
    id: text(raw.id) || uid("work"),
    title: text(raw.title, LIMITS.title),
    subject: text(raw.subject, LIMITS.subject),
    type: text(raw.type, LIMITS.type),
    orientation: text(raw.orientation, LIMITS.orientation),
    orientationContext: text(raw.orientationContext, LIMITS.orientationContext),
    orientationReady: raw.orientationReady === true,
    researchReady: raw.researchReady === true,
    researchStatus: text(raw.researchStatus) || "pending",
    researchPlan: safeObject(raw.researchPlan, LIMITS.researchPlan),
    researchRequest: safeObject(raw.researchRequest, LIMITS.researchRequest),
    research: safeObject(raw.research, LIMITS.research),
    structure,
    content: migrateContent(raw.content, oldStructure, structure),
    reviewed: raw.reviewed === true,
    reviewChecks: Object.fromEntries(Object.entries(migrateChecks(raw.reviewChecks, oldStructure, structure)).slice(0, LIMITS.reviewChecks)),
    qualityReport: safeObject(raw.qualityReport, LIMITS.qualityReport),
    finalized: raw.finalized === true,
    finalVersion: raw.finalVersion && typeof raw.finalVersion === "object" ? raw.finalVersion : null,
    updatedAt: raw.updatedAt || new Date().toISOString()
  };
  return project;
}

function read() {
  try {
    const stored = sessionStorage.getItem(KEY);
    return stored ? normalizeProject(JSON.parse(stored)) : null;
  } catch (error) {
    console.error("Erro ao ler estado do trabalho.", error);
    return null;
  }
}

function write(project) {
  sessionStorage.setItem(KEY, JSON.stringify(normalizeProject(project)));
  emitStateChange("work");
}

function saveIdentity(project, { title, subject, type, orientation } = {}) {
  const current = normalizeProject(project);
  const next = {
    ...current,
    title: text(title, LIMITS.title),
    subject: text(subject, LIMITS.subject),
    type: text(type, LIMITS.type),
    orientation: text(orientation, LIMITS.orientation)
  };
  const changed = current.title !== next.title || current.subject !== next.subject || current.type !== next.type || current.orientation !== next.orientation;
  return changed ? invalidateDownstream(next, true) : next;
}

function saveOrientation(project, { title, orientation, orientationContext, researchPlan, researchRequest, research, researchStatus } = {}) {
  const current = normalizeProject(project);
  const nextTitle = text(title ?? current.title, LIMITS.title);
  const nextOrientation = text(orientation ?? current.orientation, LIMITS.orientation);
  const nextContext = text(orientationContext ?? current.orientationContext, LIMITS.orientationContext);
  const changed = current.title !== nextTitle || current.orientation !== nextOrientation || current.orientationContext !== nextContext;
  return normalizeProject({
    ...current,
    title: nextTitle,
    orientation: nextOrientation,
    orientationContext: nextContext,
    orientationReady: true,
    researchReady: Boolean(research?.readyForStructure),
    researchStatus: text(researchStatus) || (research?.readyForStructure ? "ready" : "partial"),
    researchPlan: researchPlan || null,
    researchRequest: researchRequest || null,
    research: research || null,
    structure: changed ? [] : current.structure,
    content: changed ? {} : current.content,
    reviewed: false,
    reviewChecks: {},
    qualityReport: null,
    finalized: false,
    finalVersion: null
  });
}

function saveStructure(project, structure) {
  const current = normalizeProject(project);
  const normalized = normalizeStructure(structure).map((section, index) => ({ ...section, order: index }));
  const previousIds = current.structure.map(section => section.id).join("|");
  const nextIds = normalized.map(section => section.id).join("|");
  const changed = previousIds !== nextIds || normalized.some(section => {
    const old = current.structure.find(item => item.id === section.id);
    return !old || old.title !== section.title || old.purpose !== section.purpose;
  });
  const content = migrateContent(current.content, current.structure, normalized);
  return normalizeProject({ ...current, structure: normalized, content, reviewed: changed ? false : current.reviewed, reviewChecks: changed ? {} : current.reviewChecks, qualityReport: changed ? null : current.qualityReport, finalized: changed ? false : current.finalized, finalVersion: changed ? null : current.finalVersion });
}

function saveSectionContent(project, sectionId, value) {
  const current = normalizeProject(project);
  const id = text(sectionId);
  if (!id || !current.structure.some(section => section.id === id)) return current;
  const safeValue = typeof value === "string" ? value.trim().slice(0, LIMITS.sectionContent) : "";
  const content = { ...current.content, [id]: safeValue };
  let totalContent = 0;
  for (const [key, item] of Object.entries(content)) {
    const safe = typeof item === "string" ? item.slice(0, LIMITS.sectionContent) : "";
    if (totalContent + safe.length > LIMITS.totalContent) delete content[key];
    else { content[key] = safe; totalContent += safe.length; }
  }
  return normalizeProject({ ...current, content, reviewed: false, reviewChecks: {}, qualityReport: null, finalized: false, finalVersion: null });
}

function saveReview(project, reviewChecks, qualityReport, reviewed = false) {
  const current = normalizeProject(project);
  return normalizeProject({ ...current, reviewChecks: reviewChecks && typeof reviewChecks === "object" ? { ...reviewChecks } : {}, qualityReport: qualityReport || null, reviewed: reviewed === true, finalized: false, finalVersion: null });
}

function finalizeProject(project) {
  const current = normalizeProject(project);
  if (!current.reviewed || !current.structure.length) return current;
  return normalizeProject({ ...current, finalized: true, finalVersion: { number: Number(current.finalVersion?.number || 0) + 1, createdAt: new Date().toISOString() } });
}

function createProject(data = {}) {
  const base = normalizeProject(data);
  return {
    ...base,
    id: text(data.id) || base.id,
    orientationReady: false,
    researchReady: false,
    researchStatus: "pending",
    researchPlan: null,
    researchRequest: null,
    research: null,
    structure: [],
    content: {},
    reviewed: false,
    reviewChecks: {},
    qualityReport: null,
    finalized: false,
    finalVersion: null,
    updatedAt: new Date().toISOString()
  };
}

function getProject() { return read(); }

function setProject(project) {
  if (!project || typeof project !== "object") return false;
  try { write({ ...project, updatedAt: new Date().toISOString() }); return true; }
  catch (error) { console.error("Erro ao guardar trabalho.", error); return false; }
}

function updateProject(mutator) {
  const current = getProject();
  if (!current) return null;
  const next = typeof mutator === "function" ? mutator(current) : { ...current, ...(mutator || {}) };
  setProject(next);
  return getProject();
}

function clearProject() { sessionStorage.removeItem(KEY); emitStateChange("work"); }

export { KEY, VERSION, LIMITS, uid, slug, normalizeSection, normalizeStructure, normalizeProject, createProject, getProject, setProject, updateProject, clearProject, invalidateDownstream, saveIdentity, saveOrientation, saveStructure, saveSectionContent, saveReview, finalizeProject };
