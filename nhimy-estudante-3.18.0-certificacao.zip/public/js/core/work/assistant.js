"use strict";

function words(value) { return String(value || "").trim().split(/\s+/).filter(Boolean).length; }
function escape(value) { return String(value || "").trim(); }

function normalize(value) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function evidenceFor(project, section) {
  const findings = Array.isArray(project.research?.findings) ? project.research.findings : [];
  const wanted = normalize(section?.title);
  if (!wanted) return [];

  const aliases = {
    introducao: ["introducao", "contextualizacao", "conceitos", "definicao"],
    desenvolvimento: ["desenvolvimento", "fatores", "fatores relacionados", "analise"],
    analise: ["analise", "desenvolvimento", "fatores", "consequencias", "impactos"],
    "conceitos e caracteristicas": ["introducao", "conceitos", "definicao", "desenvolvimento"],
    "fatores relacionados": ["desenvolvimento", "fatores", "fatores relacionados", "analise"],
    "consequencias e impactos": ["conclusao", "consequencias", "impactos", "desenvolvimento"],
    conclusao: ["conclusao", "consequencias", "impactos"],
    "contextualizacao do tema": ["introducao", "contextualizacao", "desenvolvimento"]
  };
  const targets = new Set([wanted, ...(aliases[wanted] || [])]);

  return findings.filter(f => {
    const target = normalize(f?.section);
    if (targets.has(target)) return true;
    const question = normalize(f?.question);
    if (wanted.includes("conceitos") && (question.includes("o que e") || question.includes("defin"))) return true;
    if (wanted.includes("fatores") && (question.includes("fatores") || question.includes("relacion"))) return true;
    if (wanted.includes("consequencias") && (question.includes("consequ") || question.includes("impact"))) return true;
    return false;
  }).slice(0, 4);
}

export function getSectionSupport(project, index) {
  const section = project?.structure?.[index];
  if (!section) return { section: null, evidence: [], words: 0 };
  const value = typeof project.content?.[section.id] === "string" ? project.content[section.id] : "";
  return { section, evidence: evidenceFor(project, section), words: words(value) };
}

export function buildWritingGuide(project, index) {
  const support = getSectionSupport(project, index);
  const title = support.section?.title || "esta seção";
  const lower = title.toLowerCase();
  let prompts = [
    `Qual é a ideia principal que esta seção precisa explicar sobre “${project.title}”?`,
    "Que informação, exemplo ou evidência ajuda o leitor a compreender essa ideia?",
    "Como esta parte se liga à seção anterior e prepara a próxima?"
  ];
  if (lower.includes("introdu")) prompts = ["Apresente o tema e o contexto.", "Explique por que o assunto merece atenção.", "Indique o objetivo do trabalho."];
  if (lower.includes("conclus")) prompts = ["Retome as ideias mais importantes.", "Responda ao objetivo do trabalho.", "Feche com uma síntese clara, sem introduzir um assunto novo."];
  if (lower.includes("refer")) prompts = ["Registe as fontes realmente utilizadas.", "Confira título, autor, ano e endereço quando disponíveis.", "Não invente referências."];
  return { objective: support.section?.purpose || `Construir uma seção clara sobre ${project.title}.`, prompts, evidence: support.evidence, words: support.words };
}

export function buildSectionDraft(project, index) {
  const support = getSectionSupport(project, index);
  const section = support.section;
  if (!section) return "";
  const evidence = support.evidence;
  const topic = escape(project.title);
  const subject = escape(project.subject);
  const title = section.title;
  const lines = [`RASCUNHO NHIMY — ${title}`, `Tema: ${topic}${subject ? ` | Disciplina: ${subject}` : ""}`, ""];
  lines.push(section.purpose || `Desenvolvimento da seção ${title}.`);
  if (evidence.length) {
    lines.push("", "Pontos apoiados pela pesquisa:");
    evidence.forEach((item, i) => {
      const source = item.sources?.[0]?.title || (Array.isArray(item.sourceIds) && item.sourceIds.length ? item.sourceIds.join(", ") : "Fonte pesquisada");
      const snippet = String(item.text || "").replace(/\s+/g, " ").trim();
      lines.push(`${i + 1}. ${snippet.slice(0, 420)}${snippet.length > 420 ? "…" : ""} [Fonte: ${source}]`);
    });
  } else {
    lines.push("", "A pesquisa ainda não trouxe evidência específica para esta seção. Desenvolva apenas afirmações que possam ser verificadas ou aprofunde a pesquisa antes da entrega.");
  }
  return lines.join("\n");
}

export function buildProjectText(project) {
  const structure = Array.isArray(project?.structure) ? project.structure : [];
  const content = project?.content || {};
  return [project.title, project.subject ? `Disciplina: ${project.subject}` : "", ...structure.map(s => `${s.title}\n${content[s.id] || ""}`)].filter(Boolean).join("\n\n");
}
