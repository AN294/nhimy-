"use strict";

import { initNavigation } from "../ui/navigation.js";
import { initQrTool } from "../modules/qr.js";
import { initImageCompressor } from "../modules/image-compressor.js";
import { initImageResizer } from "../modules/image-resizer.js";
import { initPdfTool } from "../modules/pdf.js";
import { initPasswordTool } from "../modules/password.js";
import { initTextTools } from "../modules/text.js";
import { initPercentageTool } from "../modules/calculator.js";
import { initConverterTool } from "../modules/converter.js";
import { initUrlTool } from "../modules/url.js";
import { initJsonTool } from "../modules/json.js";
import { initGeneratorTool } from "../modules/generator.js";

function initToolSearch() {
  const input = document.getElementById("toolSearch");
  const cards = Array.from(document.querySelectorAll(".tool-card"));
  const empty = document.getElementById("noResults");
  if (!input || !cards.length) return;

  const update = () => {
    const query = input.value.trim().toLowerCase();
    let visible = 0;
    cards.forEach((card) => {
      const text = [
        card.dataset.tool || "",
        card.querySelector("h3")?.textContent || "",
        card.querySelector("p")?.textContent || ""
      ].join(" ").toLowerCase();
      const match = !query || text.includes(query);
      card.hidden = !match;
      if (match) visible += 1;
    });
    if (empty) empty.hidden = visible !== 0;
  };

  input.addEventListener("input", update);
  update();
}

function initApp() {
  initToolSearch();
  initNavigation();

  initQrTool();
  initImageCompressor();
  initImageResizer();
  initPdfTool();
  initPasswordTool();
  initTextTools();
  initPercentageTool();
  initConverterTool();
  initUrlTool();
  initJsonTool();
  initGeneratorTool();
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initApp);
} else {
  initApp();
}
