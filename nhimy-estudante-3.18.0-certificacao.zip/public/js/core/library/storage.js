"use strict";

import { emitStateChange } from "../student/events.js";

const KEY = "nhimy.library.state";
const VERSION = 1;
const LIMITS = Object.freeze({ title: 200, content: 50000, source: 500, type: 80, tags: 500, items: 200 });

function getStorage() {
  try { if (typeof localStorage !== "undefined") return localStorage; } catch (_) {}
  try { if (typeof sessionStorage !== "undefined") return sessionStorage; } catch (_) {}
  return null;
}
function readRaw() {
  const storage=getStorage(); if(!storage) return null;
  try { const raw=storage.getItem(KEY); return raw ? JSON.parse(raw) : null; } catch (_) { return null; }
}
function text(value,max) { return typeof value === "string" ? value.trim().slice(0,max) : ""; }
function createState(data={}) {
  return { version: VERSION, items: Array.isArray(data.items) ? data.items.slice(0,LIMITS.items).map(normalizeItem).filter(Boolean) : [] };
}
function normalizeItem(item={}) {
  if (!item || typeof item !== "object" || Array.isArray(item)) return null;
  const title=text(item.title,LIMITS.title), content=text(item.content,LIMITS.content);
  if(!title && !content) return null;
  return {
    id: typeof item.id === "string" && item.id ? item.id : `lib-${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
    title: title || "Sem título", content, type:text(item.type,LIMITS.type) || "material",
    source:text(item.source,LIMITS.source), tags:text(item.tags,LIMITS.tags),
    createdAt:typeof item.createdAt === "string" ? item.createdAt : new Date().toISOString(),
    updatedAt:typeof item.updatedAt === "string" ? item.updatedAt : new Date().toISOString()
  };
}
function getState() { return createState(readRaw() || {}); }
function setState(state) {
  const storage=getStorage(); if(!storage || !state || typeof state !== "object" || Array.isArray(state)) return false;
  try { storage.setItem(KEY, JSON.stringify(createState(state))); emitStateChange("library"); return true; } catch (_) { return false; }
}
function createItem(data={}) {
  const item=normalizeItem(data); if(!item) return null;
  const state=getState(); if(state.items.length>=LIMITS.items) return null;
  state.items.unshift(item); return setState(state) ? item : null;
}
function getItems() { return [...getState().items]; }
function getItem(id) { return getState().items.find(item=>item.id===id) || null; }
function updateItem(id,data={}) {
  const state=getState(), index=state.items.findIndex(item=>item.id===id); if(index<0) return null;
  const current=state.items[index]; const next=normalizeItem({...current,...data,updatedAt:new Date().toISOString(),id:current.id,createdAt:current.createdAt});
  if(!next) return null; state.items[index]=next; return setState(state) ? next : null;
}
function deleteItem(id) {
  const state=getState(), before=state.items.length; state.items=state.items.filter(item=>item.id!==id);
  return state.items.length!==before && setState(state);
}
function clearState(){ const storage=getStorage(); try{storage?.removeItem(KEY);}catch(_){} emitStateChange("library"); }
function searchItems(query="") {
  const q=text(query,200).toLowerCase(); if(!q) return getItems();
  return getItems().filter(item=>[item.title,item.content,item.source,item.type,item.tags].some(v=>v.toLowerCase().includes(q)));
}
export { KEY, VERSION, LIMITS, createState, getState, setState, createItem, getItems, getItem, updateItem, deleteItem, clearState, searchItems };
