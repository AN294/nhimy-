"use strict";

import { getHomeState } from "./state.js";
import { onStateChange } from "../student/events.js";
import { getJourneyIntelligence } from "../student/intelligence.js";
import { getStudyRoute } from "../study/workflow.js";
import { getContinueItems, getHomeSuggestions } from "./derived.js";

const $ = selector => document.querySelector(selector);
const escapeHtml = value => String(value ?? "").replace(/[&<>'"]/g, char => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[char]));
const clamp = value => Math.max(0, Math.min(100, Number(value) || 0));
const progressClass = value => `progress-${Math.round(clamp(value))}`;

function progressRow(label, value, detail) {
  const percent = clamp(value);
  return `<div class="progress-row"><div class="progress-row-head"><strong>${escapeHtml(label)}</strong><span>${percent}%</span></div><div class="student-progress-bar"><span class="student-progress-value ${progressClass(percent)}"></span></div><small>${escapeHtml(detail)}</small></div>`;
}

function buildContinue(state) {
  return getContinueItems(state).map(item => `<a class="continue-card" href="${escapeHtml(item.href)}"><span class="continue-icon">${item.icon}</span><span class="continue-body"><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.meta)}</small><span class="student-progress-bar"><span class="student-progress-value ${progressClass(item.progress)}"></span></span></span><span class="continue-arrow">→</span></a>`).join("");
}

function buildSuggestions(state) {
  return getHomeSuggestions(state).map(s => `<a class="suggestion-card" href="${escapeHtml(s.href)}"><span class="suggestion-icon">${s.icon}</span><span><strong>${escapeHtml(s.title)}</strong><small>${escapeHtml(s.text)}</small></span><span>→</span></a>`).join("");
}

function renderActionPlan(state) {
  const root = $("#actionPlan");
  if (!root) return;
  const intelligence = getJourneyIntelligence(state);
  const primary = intelligence.primary;
  const alternatives = intelligence.alternatives;
  const alternativesHtml = alternatives.length
    ? `<div class="journey-alternatives"><span class="journey-alt-label">Outras opções</span>${alternatives.map(item => `<a href="${escapeHtml(item.href)}" class="journey-alt"><span>${item.icon}</span><span><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.text)}</small></span><span>→</span></a>`).join("")}</div>`
    : "";

  root.innerHTML = `<article class="journey-primary" data-action-id="${escapeHtml(primary.id)}"><div class="journey-primary-head"><span class="action-source">PRÓXIMO PASSO</span><span class="journey-mode">${intelligence.mode === "guided" ? "Sugestão do Nhimy" : "Você escolhe"}</span></div><div class="journey-primary-body"><span class="journey-primary-icon">${primary.icon}</span><div><h3>${escapeHtml(primary.title)}</h3><p>${escapeHtml(primary.text)}</p><small><strong>Por quê?</strong> ${escapeHtml(primary.reason)}</small></div></div><div class="action-card-actions"><a class="button button-primary" href="${escapeHtml(primary.href)}">${escapeHtml(primary.actionLabel)}</a></div></article>${alternativesHtml}`;
}

function render(state) {
  renderActionPlan(state);
  $("#continueGrid").innerHTML = buildContinue(state);
  $("#progressList").innerHTML = [progressRow("Estudar", state.study.progress, `${state.study.completedStages.length}/6 etapas concluídas`), progressRow("Trabalhos", state.work.progress, `${state.work.completed.length}/6 etapas concluídas`), progressRow("Organizar", state.organize.progress, state.organize.trackable ? `${state.organize.completed}/${state.organize.trackable} itens concluídos` : "Sem itens acompanháveis ainda")].join("");
  $("#organizeStats").innerHTML = [["☑️", "Tarefas", state.organize.tasks.length], ["🎯", "Metas", state.organize.goals.length], ["🗒️", "Notas", state.organize.notes.length], ["📅", "Eventos", state.organize.events.length]].map(([icon,label,value]) => `<div class="stat-card"><span>${icon}</span><strong>${value}</strong><small>${label}</small></div>`).join("");
  $("#suggestionsGrid").innerHTML = buildSuggestions(state);
  const notifications = [];
  const pending = state.organizeSummary?.pendingTasks ?? state.organize.tasks.filter(t => !t.completed).length;
  if (pending) notifications.push(`Você tem ${pending} tarefa(s) pendente(s).`);
  if (state.work.active && state.work.progress < 100) notifications.push(`Seu trabalho “${state.work.title}” está em ${state.work.progress}%.`);
  if (state.study.session && state.study.progress < 100) notifications.push(`Seu estudo tem uma próxima etapa: ${state.study.current}.`);
  $("#notificationList").innerHTML = notifications.length ? notifications.map(n => `<p class="notification-item">${escapeHtml(n)}</p>`).join("") : `<p class="notification-empty">Nenhuma notificação nova.</p>`;
}

function search(query) {
  const q = query.trim().toLowerCase();
  if (!q) return { href: "/", label: "Digite algo para pesquisar." };
  const routes = [
    ["estudar", "/estudar/", "Estudar"], ["resumo", "/estudar/resumir/", "Resumir"], ["resumir", "/estudar/resumir/", "Resumir"], ["explicar", "/estudar/explicar/", "Explicar"], ["flashcard", "/estudar/flashcards/", "Flashcards"], ["quiz", "/estudar/quiz/", "Quiz"], ["revisar", "/estudar/revisar/", "Revisar"], ["trabalho", "/trabalhos/", "Trabalhos"], ["criar", "/trabalhos/criar/", "Criar trabalho"], ["orientar", "/trabalhos/orientar/", "Orientar"], ["estruturar", "/trabalhos/estruturar/", "Estruturar"], ["desenvolver", "/trabalhos/desenvolver/", "Desenvolver"], ["organizar", "/organizar/", "Organizar"], ["biblioteca", "/biblioteca/", "Biblioteca"], ["tarefa", "/organizar/tarefas/", "Tarefas"], ["meta", "/organizar/metas/", "Metas"], ["nota", "/organizar/notas/", "Notas"], ["agenda", "/organizar/agenda/", "Agenda"], ["ferramenta", "/ferramentas/", "Ferramentas"], ["pdf", "/ferramentas/#pdf", "PDF"], ["imagem", "/ferramentas/#imagem", "Imagem"], ["converter", "/ferramentas/#converter", "Converter"], ["texto", "/ferramentas/#texto", "Texto"]
  ];
  const match = routes.find(([term]) => q.includes(term));
  return match ? { href: match[1], label: `Abrindo ${match[2]}…` } : { href: "/estudar/", label: "Não encontrei uma ação específica. Abrindo Estudar para continuar." };
}

function initSearch() {
  $("#homeSearch").addEventListener("submit", event => { event.preventDefault(); const result = search($("#homeSearchInput").value); $("#homeSearchMessage").textContent = result.label; if (result.href !== "/") window.location.href = result.href; });
}
function initNotifications() {
  const panel = $("#notificationPanel"); const button = $("#homeNotifications"); const close = $("#closeNotifications");
  const toggle = () => { panel.hidden = !panel.hidden; button.setAttribute("aria-expanded", String(!panel.hidden)); };
  button.addEventListener("click", toggle); close.addEventListener("click", toggle);
}

function init() {
  const refresh = () => render(getHomeState());
  refresh();
  initSearch();
  initNotifications();
  onStateChange(refresh);
  window.addEventListener("pageshow", refresh);
  window.addEventListener("visibilitychange", () => { if (!document.hidden) refresh(); });
}
if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init); else init();
