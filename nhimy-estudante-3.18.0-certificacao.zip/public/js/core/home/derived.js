"use strict";

import { getStudyRoute } from "../study/workflow.js";
import { getWorkRoute } from "../work/workflow.js";

export function getContinueItems(state) {
  const items = [];
  if (state?.work?.active && state.work.progress < 100) {
    items.push({
      icon: "📝",
      title: state.work.title || "Trabalho em andamento",
      meta: `Trabalhos · ${state.work.current}`,
      progress: state.work.progress,
      href: getWorkRoute(state.work.project)
    });
  }
  if (state?.study?.session && state.study.progress < 100) {
    items.push({
      icon: "📚",
      title: state.study.session.topic || "Seu estudo mais recente",
      meta: `Estudar · ${state.study.current}`,
      progress: state.study.progress,
      href: getStudyRoute(state.study.current)
    });
  }
  const pendingTasks = state?.organizeSummary?.pendingTasks ?? state?.organize?.pendingTasks ?? state?.organize?.tasks?.filter(t => !t.completed).length ?? 0;
  if (pendingTasks) {
    items.push({
      icon: "☑️",
      title: "Tarefas pendentes",
      meta: `${pendingTasks} para organizar`,
      progress: state.organize.progress,
      href: "/organizar/tarefas/"
    });
  }
  if (!items.length) {
    items.push({
      icon: "✨",
      title: "Começar uma nova jornada",
      meta: "Escolha uma área para começar",
      progress: 0,
      href: "/estudar/"
    });
  }
  return items.slice(0, 3);
}

export function getHomeSuggestions(state) {
  const suggestions = [];
  if (state?.work?.active && state.work.progress < 100) suggestions.push({ title: "Continue seu trabalho", text: `Avance para ${state.work.current}.`, href: getWorkRoute(state.work.project), icon: "📝" });
  if (state?.study?.session && state.study.progress < 100) suggestions.push({ title: "Continue seu estudo", text: `A próxima etapa é ${state.study.current}.`, href: getStudyRoute(state.study.current), icon: "📚" });
  const pending = state?.organizeSummary?.pendingTasks ?? state?.organize?.tasks?.filter(t => !t.completed).length ?? 0;
  if (pending) suggestions.push({ title: "Organize suas tarefas", text: `${pending} tarefa(s) pendente(s).`, href: "/organizar/tarefas/", icon: "☑️" });
  const activeGoals = state?.organizeSummary?.activeGoals?.length ?? state?.organize?.goals?.filter(g => !g.completed).length ?? 0;
  if (activeGoals) suggestions.push({ title: "Acompanhe suas metas", text: `${activeGoals} meta(s) em andamento.`, href: "/organizar/metas/", icon: "🎯" });
  if (!suggestions.length) suggestions.push({ title: "Tudo pronto para começar", text: "Escolha uma área e continue seu fluxo.", href: "/estudar/", icon: "✨" });
  return suggestions.slice(0, 4);
}
