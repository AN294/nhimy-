"use strict";

import { getStudentState } from "../student/state.js";

export function getHomeState() {
  const state = getStudentState();
  return {
    ...state,
    organizeSummary: state.organize,
    organize: {
      tasks: state.organize.tasks,
      goals: state.organize.goals,
      notes: state.organize.notes,
      events: state.organize.events,
      completed: state.organize.completed,
      trackable: state.organize.trackable,
      progress: state.organize.progress
    }
  };
}

export { getStudentState };
