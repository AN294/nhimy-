"use strict";

import { emitStateChange } from "../student/events.js";

/*
 * NHIMY — ORGANIZAR STORAGE v2
 *
 * Fonte central e persistente do estado de Organizar.
 * Migra automaticamente o estado legado que estava em
 * sessionStorage para localStorage.
 */

const KEY = "nhimy.organize.state";
const LEGACY_KEY = KEY;
const VERSION = 2;

function getStorage() {
  try {
    if (typeof localStorage !== "undefined") return localStorage;
  } catch (_) {}
  try {
    if (typeof sessionStorage !== "undefined") return sessionStorage;
  } catch (_) {}
  return null;
}

function readRaw(storage) {
  if (!storage) return null;
  const stored = storage.getItem(KEY);
  if (!stored) return null;
  try { return JSON.parse(stored); } catch (error) {
    console.error("Erro ao ler estado de organização.", error);
    return null;
  }
}

function migrateLegacy() {
  let legacy = null;
  try {
    if (typeof sessionStorage !== "undefined") legacy = readRaw(sessionStorage);
  } catch (_) {}
  if (!legacy) return null;

  const storage = getStorage();
  if (storage) {
    try { storage.setItem(KEY, JSON.stringify(legacy)); } catch (_) {}
  }
  return legacy;
}

function createState(data = {}) {
  return {
    version: VERSION,
    tasks: Array.isArray(data.tasks) ? [...data.tasks] : [],
    goals: Array.isArray(data.goals) ? [...data.goals] : [],
    notes: Array.isArray(data.notes) ? [...data.notes] : [],
    events: Array.isArray(data.events) ? [...data.events] : [],
    files: Array.isArray(data.files) ? [...data.files] : []
  };
}

function getState() {
  const storage = getStorage();
  const state = readRaw(storage) || migrateLegacy();
  return createState(state || {});
}

function setState(state) {
  if (!state || typeof state !== "object" || Array.isArray(state)) return false;
  const storage = getStorage();
  if (!storage) return false;
  try {
    storage.setItem(KEY, JSON.stringify(createState(state)));
    emitStateChange("organize");
    return true;
  } catch (error) {
    console.error("Não foi possível guardar o estado de organização.", error);
    return false;
  }
}

function clearState() {
  const storage = getStorage();
  try { storage?.removeItem(KEY); } catch (_) {}
  try { sessionStorage?.removeItem(LEGACY_KEY); } catch (_) {}
  emitStateChange("organize");
}

export { KEY, VERSION, createState, getState, setState, clearState };
