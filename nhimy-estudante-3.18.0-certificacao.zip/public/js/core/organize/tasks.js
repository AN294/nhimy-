"use strict";

import { getState, setState } from "./storage.js";

const PRIORITIES = ["low", "medium", "high"];

function generateId() {
  if (typeof crypto !== "undefined" && typeof crypto.randomUUID === "function") return crypto.randomUUID();
  return `task-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}

function normalizeTask(task = {}) {
  const now = new Date().toISOString();
  const priority = PRIORITIES.includes(task.priority) ? task.priority : "medium";
  return {
    id: task.id || generateId(),
    title: typeof task.title === "string" ? task.title.trim() : "",
    dueDate: typeof task.dueDate === "string" ? task.dueDate : "",
    priority,
    category: typeof task.category === "string" ? task.category.trim() : "",
    completed: Boolean(task.completed),
    createdAt: typeof task.createdAt === "string" ? task.createdAt : now,
    updatedAt: typeof task.updatedAt === "string" ? task.updatedAt : now
  };
}

function createTask(data = {}) {
  const title = typeof data.title === "string" ? data.title.trim() : "";
  if (!title) return null;
  const state = getState();
  const task = normalizeTask({ title, dueDate: data.dueDate || "", priority: data.priority, category: data.category || "", completed: false });
  state.tasks.push(task);
  setState(state);
  return task;
}

function getTasks() { return getState().tasks.map(normalizeTask); }
function getTask(id) { return getTasks().find(task => task.id === id) || null; }

function updateTask(id, data = {}) {
  const state = getState();
  const index = state.tasks.findIndex(task => task.id === id);
  if (index === -1) return null;
  const current = normalizeTask(state.tasks[index]);
  const title = data.title !== undefined ? String(data.title).trim() : current.title;
  if (!title) return null;
  state.tasks[index] = normalizeTask({
    ...current,
    title,
    dueDate: data.dueDate !== undefined ? String(data.dueDate) : current.dueDate,
    priority: data.priority !== undefined ? data.priority : current.priority,
    category: data.category !== undefined ? String(data.category).trim() : current.category,
    updatedAt: new Date().toISOString()
  });
  setState(state);
  return state.tasks[index];
}

function toggleTask(id) {
  const state = getState();
  const index = state.tasks.findIndex(task => task.id === id);
  if (index === -1) return null;
  state.tasks[index] = normalizeTask({ ...state.tasks[index], completed: !state.tasks[index].completed, updatedAt: new Date().toISOString() });
  setState(state);
  return state.tasks[index];
}

function deleteTask(id) {
  const state = getState();
  const index = state.tasks.findIndex(task => task.id === id);
  if (index === -1) return false;
  state.tasks.splice(index, 1);
  setState(state);
  return true;
}

export { PRIORITIES, createTask, getTasks, getTask, updateTask, toggleTask, deleteTask };
