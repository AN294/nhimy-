"use strict";

import { getTasks } from "./tasks.js";
import { getGoals } from "./goals.js";
import { getNotes } from "./notes.js";
import { getEvents } from "./events.js";

function dayKey(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${y}-${m}-${day}`;
}

function eventDate(event) {
  if (!event.date) return null;
  const value = event.time ? `${event.date}T${event.time}` : `${event.date}T23:59:59`;
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? null : date;
}

function taskDate(task) {
  if (!task.dueDate) return null;
  const date = new Date(`${task.dueDate}T23:59:59`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function getOrganizeSummary(now = new Date()) {
  const tasks = getTasks();
  const goals = getGoals();
  const notes = getNotes();
  const events = getEvents();
  const today = dayKey(now);
  const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  const pendingTasks = tasks.filter(t => !t.completed);
  const overdueTasks = pendingTasks.filter(t => {
    const date = taskDate(t);
    return date && date < todayStart;
  });
  const todayTasks = pendingTasks.filter(t => t.dueDate === today);
  const highPriority = pendingTasks.filter(t => t.priority === "high");
  const activeGoals = goals.filter(g => !g.completed);
  const upcomingEvents = events
    .filter(e => !e.completed)
    .map(e => ({ ...e, _date: eventDate(e) }))
    .filter(e => e._date && e._date >= now)
    .sort((a, b) => a._date - b._date);
  const todayEvents = upcomingEvents.filter(e => dayKey(e._date) === today);
  const completedTasks = tasks.filter(t => t.completed).length;
  const trackable = [...tasks, ...goals];
  const completed = trackable.filter(item => item.completed === true).length;
  const progress = trackable.length ? Math.round((completed / trackable.length) * 100) : 0;
  const taskCompletion = tasks.length ? Math.round((completedTasks / tasks.length) * 100) : 0;

  return {
    tasks, goals, notes, events,
    totalTasks: tasks.length,
    pendingTasks: pendingTasks.length,
    completedTasks,
    overdueTasks,
    todayTasks,
    highPriority,
    activeGoals,
    completedGoals: goals.filter(g => g.completed).length,
    upcomingEvents,
    todayEvents,
    recentNotes: [...notes].sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt))).slice(0, 3),
    taskCompletion,
    completed,
    trackable: trackable.length,
    progress,
    hasFocus: Boolean(overdueTasks.length || todayTasks.length || highPriority.length || todayEvents.length)
  };
}

export { dayKey, getOrganizeSummary };
