"use strict";

const EVENT_NAME = "nhimy:state-change";

export function emitStateChange(source = "unknown") {
  if (typeof globalThis === "undefined" || typeof globalThis.dispatchEvent !== "function") return;
  try {
    globalThis.dispatchEvent(new CustomEvent(EVENT_NAME, { detail: { source, at: new Date().toISOString() } }));
  } catch (_) {}
}

export function onStateChange(listener) {
  if (typeof globalThis === "undefined") return () => {};
  const customHandler = event => listener(event?.detail || {});
  const storageHandler = event => {
    if (!event?.key || event.key.startsWith("nhimy.")) {
      listener({ source: "storage", key: event?.key || null, at: new Date().toISOString() });
    }
  };
  if (typeof globalThis.addEventListener !== "function") return () => {};
  globalThis.addEventListener(EVENT_NAME, customHandler);
  globalThis.addEventListener("storage", storageHandler);
  return () => {
    globalThis.removeEventListener?.(EVENT_NAME, customHandler);
    globalThis.removeEventListener?.("storage", storageHandler);
  };
}

export { EVENT_NAME };
