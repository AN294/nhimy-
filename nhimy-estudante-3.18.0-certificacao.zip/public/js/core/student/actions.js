"use strict";

/* Ações explícitas de integração. Elas usam as APIs oficiais dos módulos. */
import { getStudySession } from "../study/storage.js";
import { getProject, createProject, setProject } from "../work/storage.js";
import { createTask } from "../organize/tasks.js";
import { createNote, getNote } from "../organize/notes.js";
import { createItem, getItems } from "../library/storage.js";

export function createTaskFromCurrentStudy(overrides = {}) {
  const study = getStudySession();
  if (!study) return null;
  const topic = String(study.topic || "estudo").trim();
  return createTask({
    title: overrides.title || `Continuar estudo: ${topic}`,
    category: overrides.category || "Estudar",
    priority: overrides.priority || "medium",
    dueDate: overrides.dueDate || ""
  });
}

export function createTaskFromCurrentWork(overrides = {}) {
  const project = getProject();
  if (!project) return null;
  const title = String(project.title || "trabalho").trim();
  return createTask({
    title: overrides.title || `Avançar trabalho: ${title}`,
    category: overrides.category || "Trabalhos",
    priority: overrides.priority || "high",
    dueDate: overrides.dueDate || ""
  });
}

export function createNoteFromCurrentStudy() {
  const study = getStudySession();
  if (!study) return null;
  const topic = String(study.topic || "Estudo").trim();
  const content = String(study.prepared || study.source || "").trim();
  return createNote({ title: `Material de estudo — ${topic}`, content });
}


export function createWorkFromCurrentStudy(overrides = {}) {
  const study = getStudySession();
  if (!study || getProject()) return null;
  const topic = String(overrides.title || study.topic || "Trabalho baseado no estudo").trim();
  if (!topic) return null;
  const subject = String(overrides.subject || "A definir").trim();
  const context = String(overrides.orientationContext || study.prepared || study.source || study.topic || "").trim();
  const project = createProject({
    title: topic,
    subject,
    type: overrides.type || "Trabalho baseado em estudo",
    orientation: "tema",
    orientationContext: context
  });
  setProject(project);
  return project;
}


export function createLibraryItemFromCurrentStudy(overrides = {}) {
  const study = getStudySession();
  if (!study) return null;
  const topic = String(overrides.title || study.topic || "Material de estudo").trim();
  const content = String(overrides.content || study.prepared || study.source || "").trim();
  if (!content) return null;
  return createItem({
    title: topic,
    content,
    type: overrides.type || "estudo",
    source: overrides.source || study.sourceType || "sessão de estudo",
    tags: overrides.tags || "estudo"
  });
}

export function createLibraryItemFromNote(noteId, overrides = {}) {
  const note = getNote(noteId);
  if (!note) return null;
  const title = String(overrides.title || note.title || "Nota").trim();
  const content = String(overrides.content ?? note.content ?? "").trim();
  if (!content) return null;
  const source = overrides.source || "Organizar · Notas";
  const tags = overrides.tags || "nota, organizar";
  const existing = getItems().find(item => item.source === source && item.content === content);
  return existing || createItem({ title, content, type: overrides.type || "nota", source, tags });
}

export function createLibraryItemFromCurrentWork(overrides = {}) {
  const project = getProject();
  if (!project || project.finalized !== true) return null;
  const structure = Array.isArray(project.structure) ? project.structure : [];
  const blocks = structure.map(section => {
    const title = String(section?.title || "").trim();
    const content = String(project.content?.[section?.id] || "").trim();
    if (!content) return "";
    return `${title ? `${title}\n` : ""}${content}`;
  }).filter(Boolean);
  const content = blocks.join("\n\n").trim();
  if (!content) return null;
  const title = String(overrides.title || project.title || "Trabalho finalizado").trim();
  const source = overrides.source || "Trabalhos · Finalizado";
  const tags = overrides.tags || "trabalho, finalizado";
  const existing = getItems().find(item => item.source === source && item.title === title && item.content === content);
  return existing || createItem({ title, content, type: overrides.type || "trabalho", source, tags });
}

