"use strict";

/*
 * NHIMY — EVOLUÇÃO 2.3 / INTELIGÊNCIA DO PERCURSO
 *
 * Inteligência determinística, transparente e orientada ao estudante.
 * Apenas lê o estado derivado dos módulos oficiais; não cria armazenamento próprio.
 * Objetivo: identificar uma próxima ação útil sem transformar o percurso em pressão.
 */

import { getStudyRoute } from "../study/workflow.js";
import { getWorkRoute } from "../work/workflow.js";

const PRIORITY = Object.freeze({
  BLOCKED_WORK: 100,
  OVERDUE_TASK: 95,
  TODAY_TASK: 90,
  STUDY_NEXT: 80,
  WORK_NEXT: 78,
  HIGH_TASK: 75,
  ACTIVE_GOAL: 60,
  START_STUDY: 30
});

function text(value, fallback = "") {
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

function pendingTasks(organize) {
  return Array.isArray(organize?.tasks) ? organize.tasks.filter(task => !task.completed) : [];
}

function taskDate(task) {
  if (!task?.dueDate) return null;
  const date = new Date(`${task.dueDate}T23:59:59`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function buildCandidates(state, now = new Date()) {
  const candidates = [];
  const study = state?.study || {};
  const work = state?.work || {};
  const organize = state?.organize || {};
  const pending = pendingTasks(organize);
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (work.active && work.progress < 100 && ["orientar", "estruturar"].includes(work.current)) {
    candidates.push({
      id: "journey-work-blocker",
      score: PRIORITY.BLOCKED_WORK,
      source: "trabalhos",
      icon: "📝",
      title: `Desbloquear ${work.current}`,
      text: `O próximo passo do trabalho é ${work.current}. Avançar aqui libera as etapas seguintes.`,
      reason: "É a próxima etapa necessária para o trabalho continuar.",
      href: getWorkRoute(work.project),
      actionLabel: "Continuar trabalho"
    });
  }

  const overdue = pending.filter(task => {
    const date = taskDate(task);
    return date && date < today;
  }).sort((a, b) => Number(b.priority === "high") - Number(a.priority === "high"));
  if (overdue.length) {
    const task = overdue[0];
    candidates.push({
      id: "journey-overdue-task",
      score: PRIORITY.OVERDUE_TASK,
      source: "organizar",
      icon: "☑️",
      title: text(task.title, "Tarefa em atraso"),
      text: "Esta pendência já passou do prazo. Resolva-a ou ajuste o prazo conforme a sua realidade.",
      reason: "Uma pendência em atraso merece atenção antes de novas tarefas.",
      href: "/organizar/tarefas/",
      actionLabel: "Ver tarefa"
    });
  }

  const todayTasks = pending.filter(task => task.dueDate === `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`);
  if (todayTasks.length) {
    const task = todayTasks.find(item => item.priority === "high") || todayTasks[0];
    candidates.push({
      id: "journey-today-task",
      score: PRIORITY.TODAY_TASK,
      source: "organizar",
      icon: "📅",
      title: text(task.title, "Tarefa de hoje"),
      text: "Há uma tarefa prevista para hoje. Veja-a antes de decidir o próximo passo.",
      reason: "A tarefa tem prazo para hoje.",
      href: "/organizar/tarefas/",
      actionLabel: "Organizar agora"
    });
  }

  if (study.active && study.progress < 100) {
    const topic = text(study.session?.topic, "seu estudo");
    candidates.push({
      id: "journey-study-next",
      score: PRIORITY.STUDY_NEXT,
      source: "estudar",
      icon: "📚",
      title: `Continuar ${topic}`,
      text: `A etapa atual é ${study.current}. Um passo de cada vez já é progresso.`,
      reason: "Existe uma sessão de estudo em andamento com uma etapa seguinte clara.",
      href: getStudyRoute(study.current),
      actionLabel: "Continuar estudo"
    });
  }

  if (work.active && work.progress < 100 && work.current !== "orientar" && work.current !== "estruturar") {
    candidates.push({
      id: "journey-work-next",
      score: PRIORITY.WORK_NEXT,
      source: "trabalhos",
      icon: "📝",
      title: text(work.title, "Trabalho em andamento"),
      text: `A próxima etapa é ${work.current}.`,
      reason: "O trabalho está em andamento e tem uma etapa seguinte definida.",
      href: getWorkRoute(work.project),
      actionLabel: "Continuar trabalho"
    });
  }

  const high = pending.filter(task => task.priority === "high");
  if (high.length) {
    const task = high[0];
    candidates.push({
      id: "journey-high-task",
      score: PRIORITY.HIGH_TASK,
      source: "organizar",
      icon: "🎯",
      title: text(task.title, "Tarefa prioritária"),
      text: "É uma tarefa marcada como prioridade alta.",
      reason: "A própria organização do estudante marcou esta tarefa como prioritária.",
      href: "/organizar/tarefas/",
      actionLabel: "Ver prioridade"
    });
  }

  if (Array.isArray(organize?.activeGoals) && organize.activeGoals.length) {
    const goal = organize.activeGoals[0];
    candidates.push({
      id: "journey-goal",
      score: PRIORITY.ACTIVE_GOAL,
      source: "organizar",
      icon: "🎯",
      title: text(goal.title, "Meta em andamento"),
      text: "Uma meta está em andamento. Um pequeno avanço pode mantê-la viva.",
      reason: "Existe uma meta ativa que pode receber um próximo passo.",
      href: "/organizar/metas/",
      actionLabel: "Ver meta"
    });
  }

  if (!candidates.length) {
    candidates.push({
      id: "journey-start",
      score: PRIORITY.START_STUDY,
      source: "nhimy",
      icon: "✨",
      title: "Escolha o que faz sentido para você agora",
      text: "Você pode começar um estudo, criar um trabalho ou organizar uma pendência.",
      reason: "Ainda não há uma prioridade clara no estado atual.",
      href: "/estudar/",
      actionLabel: "Começar"
    });
  }

  return candidates;
}

export function getJourneyIntelligence(state, now = new Date()) {
  const candidates = buildCandidates(state, now);
  const ranked = candidates
    .slice()
    .sort((a, b) => b.score - a.score)
    .map((item, index) => ({ ...item, rank: index + 1 }));
  const primary = ranked[0];

  return Object.freeze({
    version: 1,
    primary,
    alternatives: ranked.slice(1, 3),
    candidates: ranked,
    mode: primary.id === "journey-start" ? "open" : "guided",
    principle: "orientar-sem-pressionar"
  });
}

export { buildCandidates };
