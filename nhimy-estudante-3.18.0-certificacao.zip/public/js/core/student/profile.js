"use strict";
const KEY = "nhimy.student.profile";
const VERSION = 1;
const LIMITS = Object.freeze({name:80, course:120, institution:160});
function storage(){try{return localStorage}catch(_){return null}}
function text(v,max){return typeof v==='string'?v.trim().slice(0,max):''}
function normalize(data={}){return {version:VERSION,name:text(data.name,LIMITS.name),course:text(data.course,LIMITS.course),institution:text(data.institution,LIMITS.institution)}}
function getProfile(){const s=storage();if(!s)return normalize();try{return normalize(JSON.parse(s.getItem(KEY)||'{}'))}catch(_){return normalize()}}
function setProfile(data={}){const s=storage();if(!s)return false;try{s.setItem(KEY,JSON.stringify(normalize(data)));return true}catch(_){return false}}
function clearProfile(){const s=storage();try{s?.removeItem(KEY)}catch(_){} }
export {KEY,VERSION,LIMITS,getProfile,setProfile,clearProfile};
