"use strict";

/*
 * NHIMY — ESTADO CENTRAL DO ESTUDANTE / EVOLUÇÃO 2.1
 * Estado derivado: não duplica nem cria uma segunda fonte de verdade.
 * Cada módulo continua responsável pelo seu armazenamento; este módulo
 * apenas consolida o estado atual para a experiência integrada.
 */
import { getStudySession, getQuizResult, isReviewed, isQuizCompleted } from "../study/storage.js";
import { getCurrentStudyStage, getCompletedStudyStages, getStudyProgress } from "../study/workflow.js";
import { getProject } from "../work/storage.js";
import { getOrganizeSummary } from "../organize/summary.js";
import { getCurrentWorkStage, getCompletedWorkStages, getWorkProgress } from "../work/workflow.js";
import { getItems } from "../library/storage.js";
import { getProfile } from "./profile.js";
import { getSession } from "./session.js";

function getStudyState() {
  const session = getStudySession();
  const completedStages = getCompletedStudyStages(session);
  return {
    active: Boolean(session),
    session,
    current: getCurrentStudyStage(session),
    completedStages,
    completed: completedStages.length,
    progress: getStudyProgress(session),
    reviewed: isReviewed(),
    quizCompleted: isQuizCompleted(),
    quizResult: getQuizResult()
  };
}

function getWorkState() {
  const project = getProject();
  const completedStages = [...getCompletedWorkStages(project)];
  return {
    active: Boolean(project),
    project,
    title: project?.title?.trim() || "Trabalho em andamento",
    current: getCurrentWorkStage(project),
    completedStages,
    completed: completedStages.length,
    progress: getWorkProgress(project)
  };
}

function getOrganizeState() {
  const summary = getOrganizeSummary();
  return {
    ...summary,
    active: Boolean(summary.tasks.length || summary.goals.length || summary.notes.length || summary.events.length)
  };
}

export function getStudentState() {
  const libraryItems = getItems();
  const state = {
    version: 3,
    generatedAt: new Date().toISOString(),
    study: getStudyState(),
    work: getWorkState(),
    organize: getOrganizeState(),
    library: { items: libraryItems, count: libraryItems.length },
    profile: getProfile(),
    session: getSession()
  };
  return Object.freeze(state);
}

export { getStudyState, getWorkState, getOrganizeState };
