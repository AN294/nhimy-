"use strict";

const KEY = "nhimy.student.session";
const VERSION = 1;
const LIMITS = Object.freeze({ module: 60, route: 200 });

function storage(){ try { return localStorage; } catch(_) { try { return sessionStorage; } catch(_) { return null; } } }
function text(v,max){ return typeof v === "string" ? v.trim().slice(0,max) : ""; }
function normalize(data={}){
  return { version: VERSION, startedAt: text(data.startedAt,40), lastActiveAt: text(data.lastActiveAt,40), module: text(data.module,LIMITS.module), route: text(data.route,LIMITS.route) };
}
function getSession(){
  const s=storage(); if(!s) return normalize();
  try { return normalize(JSON.parse(s.getItem(KEY)||"{}")); } catch(_) { return normalize(); }
}
function touch(module="", route=""){
  const s=storage(); if(!s) return false;
  const now=new Date().toISOString(); const current=getSession();
  const next=normalize({ ...current, startedAt: current.startedAt || now, lastActiveAt: now, module, route });
  try { s.setItem(KEY,JSON.stringify(next)); return true; } catch(_) { return false; }
}
function clearSession(){ const s=storage(); try { s?.removeItem(KEY); } catch(_) {} }

export { KEY, VERSION, LIMITS, getSession, touch, clearSession };
