"use strict";

import { getStudyRoute } from "../study/workflow.js";
import { getWorkRoute } from "../work/workflow.js";

/*
 * NHIMY — EVOLUÇÃO 2.2
 * Integração funcional entre Estudar, Trabalhos e Organizar.
 * Estado continua derivado das fontes oficiais dos módulos.
 */

function hasText(value) { return typeof value === "string" && value.trim().length > 0; }

export function getIntegratedActions(state) {
  const actions = [];
  const study = state?.study || {};
  const work = state?.work || {};
  const organize = state?.organize || {};
  const library = state?.library || {};

  if (study.active && (library.count ?? 0) === 0 && hasText(study.session?.prepared || study.session?.source)) {
    actions.push({
      id: "study-to-library",
      priority: 4,
      source: "library",
      label: "Guardar estudo na Biblioteca",
      title: study.session?.topic || "Material de estudo",
      text: "Preserva este conhecimento para consultar depois.",
      href: "/biblioteca/"
    });
  }

  if (study.active && study.progress < 100) {
    actions.push({
      id: "study-next",
      priority: 1,
      source: "study",
      label: "Continuar estudo",
      title: study.session?.topic || "Seu estudo",
      text: `Próxima etapa: ${study.current}.`,
      href: getStudyRoute(study.current)
    });
  }

  if (work.active && work.progress < 100) {
    actions.push({
      id: "work-next",
      priority: 2,
      source: "work",
      label: "Continuar trabalho",
      title: work.title || "Trabalho em andamento",
      text: `Próxima etapa: ${work.current}.`,
      href: getWorkRoute(work.project)
    });
  }

  const pending = Number(organize.pendingTasks) || 0;
  if (pending > 0) {
    actions.push({
      id: "organize-pending",
      priority: 3,
      source: "organize",
      label: "Resolver pendências",
      title: `${pending} tarefa(s) pendente(s)`,
      text: organize.overdueTasks?.length ? `${organize.overdueTasks.length} em atraso. Comece por elas.` : "Escolha a próxima tarefa para avançar.",
      href: "/organizar/tarefas/"
    });
  }

  if (study.active && work.active && hasText(study.session?.topic) && hasText(work.project?.subject)) {
    actions.push({
      id: "study-work-bridge",
      priority: 4,
      source: "integration",
      label: "Conectar estudo e trabalho",
      title: study.session.topic,
      text: `Use o estudo atual como apoio ao trabalho de ${work.project.subject}.`,
      href: getWorkRoute(work.project)
    });
  }

  if (study.active && !work.active && hasText(study.session?.topic)) {
    actions.push({
      id: "study-to-work",
      priority: 5,
      source: "integration",
      label: "Levar estudo para um trabalho",
      title: study.session.topic,
      text: "Crie um trabalho a partir do tema que já está estudando.",
      href: "/trabalhos/criar/"
    });
  }

  if (work.active && !pending) {
    actions.push({
      id: "work-to-organize",
      priority: 6,
      source: "integration",
      label: "Organizar próxima entrega",
      title: work.title || "Seu trabalho",
      text: "Registre uma tarefa para acompanhar a próxima etapa.",
      href: "/organizar/tarefas/"
    });
  }

  return actions.sort((a, b) => a.priority - b.priority).slice(0, 5);
}

export function getIntegrationSummary(state) {
  const actions = getIntegratedActions(state);
  const links = [];
  if (state?.study?.active && state?.work?.active) links.push("estudar→trabalhos");
  if (state?.study?.active || state?.work?.active) links.push("fluxo→organizar");
  return Object.freeze({
    actionCount: actions.length,
    primary: actions[0] || null,
    actions,
    links
  });
}
