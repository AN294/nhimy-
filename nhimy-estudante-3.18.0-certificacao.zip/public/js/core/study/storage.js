"use strict";

import { emitStateChange } from "../student/events.js";

/* NHIMY — ESTUDAR: fonte central da sessão e dos resultados. */

const SESSION_KEY = "nhimy.study.session";
const LEGACY_KEYS = Object.freeze({
  summary: "nhimy.study.summary",
  reviewed: "nhimy.study.reviewed",
  quizCompleted: "nhimy.study.quizCompleted",
  quizResult: "nhimy.study.quizResult",
  practiceResult: "nhimy.study.practiceResult"
});

const STAGES = Object.freeze(["conteudo", "preparar", "compreender", "revisar", "praticar", "resultado"]);

function safeRead(key) {
  try { return sessionStorage.getItem(key); } catch { return null; }
}
function safeWrite(key, value) {
  try { sessionStorage.setItem(key, JSON.stringify(value)); return true; } catch { return false; }
}
function parse(raw) {
  if (!raw) return null;
  try { return JSON.parse(raw); } catch { return null; }
}

function normalizeSession(value) {
  if (!value || typeof value !== "object") return null;
  const stage = STAGES.includes(value.stage) ? value.stage : "conteudo";
  return {
    id: typeof value.id === "string" ? value.id : null,
    topic: typeof value.topic === "string" ? value.topic : "",
    source: typeof value.source === "string" ? value.source : "",
    sourceType: value.sourceType === "topic" ? "topic" : "content",
    focus: typeof value.focus === "string" ? value.focus : "",
    prepared: typeof value.prepared === "string" ? value.prepared : "",
    comprehension: typeof value.comprehension === "string" ? value.comprehension : "",
    comprehensionNote: typeof value.comprehensionNote === "string" ? value.comprehensionNote : "",
    practiceCompleted: Boolean(value.practiceCompleted),
    practiceResult: value.practiceResult && typeof value.practiceResult === "object" ? value.practiceResult : null,
    flashcardsCompleted: Boolean(value.flashcardsCompleted),
    quizCompleted: Boolean(value.quizCompleted),
    quizResult: value.quizResult && typeof value.quizResult === "object" ? value.quizResult : null,
    stage,
    createdAt: value.createdAt || null,
    updatedAt: value.updatedAt || null
  };
}

function migrateLegacy() {
  const current = normalizeSession(parse(safeRead(SESSION_KEY)));
  if (current) return current;
  const summary = parse(safeRead(LEGACY_KEYS.summary));
  const reviewed = parse(safeRead(LEGACY_KEYS.reviewed)) === true;
  const quizCompleted = parse(safeRead(LEGACY_KEYS.quizCompleted)) === true;
  const quizResult = parse(safeRead(LEGACY_KEYS.quizResult));
  const practiceResult = parse(safeRead(LEGACY_KEYS.practiceResult));
  if (!summary && !reviewed && !quizCompleted && !practiceResult) return null;
  return normalizeSession({
    source: summary?.result || "",
    sourceType: "content",
    prepared: summary?.result || "",
    stage: quizCompleted ? "resultado" : reviewed ? "revisar" : "preparar",
    practiceCompleted: Boolean(practiceResult?.completed),
    practiceResult,
    quizCompleted,
    quizResult,
    createdAt: new Date().toISOString()
  });
}

function getStudySession() {
  const session = migrateLegacy();
  return session;
}

function startStudySession({ topic = "", source = "", sourceType = "content", stage = "conteudo" } = {}) {
  const now = new Date().toISOString();
  const session = normalizeSession({
    id: `study-${Date.now()}`,
    topic: String(topic).trim(),
    source: String(source).trim(),
    sourceType,
    stage,
    createdAt: now,
    updatedAt: now
  });
  safeWrite(SESSION_KEY, session);
  emitStateChange("study");
  return session;
}

function setStudySession(patch = {}) {
  const current = getStudySession() || startStudySession({});
  const next = normalizeSession({ ...current, ...patch, updatedAt: new Date().toISOString() });
  safeWrite(SESSION_KEY, next);
  emitStateChange("study");
  return next;
}

function clearStudySession() {
  try { sessionStorage.removeItem(SESSION_KEY); Object.values(LEGACY_KEYS).forEach(key => sessionStorage.removeItem(key)); } catch {}
  emitStateChange("study");
}

function getSummary() {
  return getStudySession()?.prepared || parse(safeRead(LEGACY_KEYS.summary))?.result || null;
}
function getSummaryRequest() { return parse(safeRead(LEGACY_KEYS.summary))?.request || null; }
function setSummary(data) {
  if (!data || typeof data.result !== "string" || !data.result.trim()) return false;
  safeWrite(LEGACY_KEYS.summary, { result: data.result.trim(), request: data.request || null });
  setStudySession({ prepared: data.result.trim() });
  return true;
}
function setReviewed(value = true) {
  safeWrite(LEGACY_KEYS.reviewed, Boolean(value));
  setStudySession({ stage: value ? "praticar" : "revisar" });
}
function isReviewed() { return parse(safeRead(LEGACY_KEYS.reviewed)) === true || ["praticar", "resultado"].includes(getStudySession()?.stage); }
function setPracticeResult(result) {
  safeWrite(LEGACY_KEYS.practiceResult, result || null);
  setStudySession({ practiceCompleted: Boolean(result?.completed), practiceResult: result || null, stage: "resultado" });
  return result;
}
function getPracticeResult() { return parse(safeRead(LEGACY_KEYS.practiceResult)) || getStudySession()?.practiceResult || null; }
function setQuizResult(score, total) {
  const result = { score: Number(score) || 0, total: Number(total) || 0 };
  safeWrite(LEGACY_KEYS.quizResult, result);
  safeWrite(LEGACY_KEYS.quizCompleted, true);
  setStudySession({ quizCompleted: true, quizResult: result, stage: "resultado" });
  return result;
}
function getQuizResult() { return parse(safeRead(LEGACY_KEYS.quizResult)) || getStudySession()?.quizResult || null; }
function isQuizCompleted() { return parse(safeRead(LEGACY_KEYS.quizCompleted)) === true || Boolean(getStudySession()?.quizCompleted); }
function setFlashcardsCompleted(value = true) { setStudySession({ flashcardsCompleted: Boolean(value), stage: value ? "praticar" : "revisar" }); return Boolean(value); }
function isFlashcardsCompleted() { return Boolean(getStudySession()?.flashcardsCompleted); }

export {
  SESSION_KEY, LEGACY_KEYS, STAGES,
  getStudySession, startStudySession, setStudySession, clearStudySession,
  getSummary, getSummaryRequest, setSummary,
  setReviewed, isReviewed,
  setPracticeResult, getPracticeResult,
  setQuizResult, getQuizResult, isQuizCompleted,
  setFlashcardsCompleted, isFlashcardsCompleted
};
