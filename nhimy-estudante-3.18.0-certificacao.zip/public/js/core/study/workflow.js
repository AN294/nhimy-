"use strict";

import { getStudySession, STAGES } from "./storage.js";

const ROUTES = Object.freeze({
  conteudo: "/estudar/",
  preparar: "/estudar/preparar/",
  compreender: "/estudar/compreender/",
  revisar: "/estudar/revisar/",
  praticar: "/estudar/praticar/",
  resultado: "/estudar/resultado/"
});

const INDEX = Object.freeze(Object.fromEntries(STAGES.map((stage, i) => [stage, i])));

export function getCurrentStudyStage(session = getStudySession()) {
  return session?.stage && ROUTES[session.stage] ? session.stage : "conteudo";
}
export function getStudyRoute(stage = getCurrentStudyStage()) { return ROUTES[stage] || ROUTES.conteudo; }
export function getCompletedStudyStages(session = getStudySession()) {
  if (!session) return [];
  const stage = getCurrentStudyStage(session);
  const index = INDEX[stage];
  return STAGES.slice(0, index + (stage === "resultado" ? 1 : 0));
}
export function getStudyProgress(session = getStudySession()) {
  if (!session) return 0;
  const stage = getCurrentStudyStage(session);
  return Math.round((INDEX[stage] / (STAGES.length - 1)) * 100);
}
export function getStudyReadiness(session = getStudySession()) {
  const stage = getCurrentStudyStage(session);
  return {
    exists: Boolean(session),
    hasSource: Boolean(session?.source || session?.topic),
    prepared: Boolean(session?.prepared),
    reviewed: ["praticar", "resultado"].includes(stage),
    practiced: Boolean(session?.practiceCompleted),
    measured: Boolean(session?.quizCompleted),
    stage,
    progress: getStudyProgress(session)
  };
}
export function canAccessStudyStage(stage, session = getStudySession()) {
  if (!ROUTES[stage]) return false;
  if (stage === "conteudo") return true;
  if (!session) return false;
  if (stage === "preparar") return Boolean(session.source || session.topic);
  if (stage === "compreender") return Boolean(session.prepared);
  if (stage === "revisar") return Boolean(session.prepared && session.comprehension);
  if (stage === "praticar") return Boolean(session.prepared && session.comprehension && ["praticar", "resultado"].includes(session.stage));
  if (stage === "resultado") return Boolean(session.practiceCompleted || session.quizCompleted);
  return false;
}

export function guardStudyStage(stage, session = getStudySession()) {
  if (canAccessStudyStage(stage, session)) return true;
  if (typeof window !== "undefined" && window.location) {
    window.location.href = session ? getStudyRoute(getCurrentStudyStage(session)) : ROUTES.conteudo;
  }
  return false;
}
