"use strict";

import { getCurrentUser } from "../auth/client.js";

const API_PATH = "/api/me/data";
const DATA_VERSION = 1;

function safeParse(storage, key) {
  try {
    const raw = storage?.getItem(key);
    return raw ? JSON.parse(raw) : null;
  } catch (_) {
    return null;
  }
}

function collectLocalData() {
  const local = typeof localStorage !== "undefined" ? localStorage : null;
  const session = typeof sessionStorage !== "undefined" ? sessionStorage : null;
  return {
    version: DATA_VERSION,
    profile: safeParse(local, "nhimy.student.profile"),
    organize: safeParse(local, "nhimy.organize.state"),
    library: safeParse(local, "nhimy.library.state"),
    study: safeParse(session, "nhimy.study.session"),
    work: safeParse(session, "nhimy.work.project")
  };
}

function hasLocalData(data = collectLocalData()) {
  return Boolean(data.profile || data.organize || data.library || data.study || data.work);
}

async function getAccountData() {
  const response = await fetch(API_PATH, { credentials: "same-origin", headers: { Accept: "application/json" } });
  const data = await response.json().catch(() => null);
  if (!response.ok) throw new Error(data?.error || "Não foi possível carregar os dados da conta.");
  return data?.data || null;
}

async function saveAccountData(data = collectLocalData(), options = {}) {
  const response = await fetch(API_PATH, {
    method: "PUT",
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      ...(Number.isInteger(options.expectedRevision) ? { "If-Match": String(options.expectedRevision) } : {})
    },
    body: JSON.stringify(data)
  });
  const result = await response.json().catch(() => null);
  if (!response.ok) throw new Error(result?.error || "Não foi possível guardar os dados da conta.");
  return result?.data || null;
}

async function syncLocalDataToAccount() {
  const user = await getCurrentUser();
  if (!user) return { authenticated: false, imported: false, data: null };
  const local = collectLocalData();
  const existing = await getAccountData();
  const imported = hasLocalData(local) && !existing?.hasData;
  const data = imported ? await saveAccountData(local) : existing?.data || null;
  return { authenticated: true, imported, data };
}

export { API_PATH, DATA_VERSION, collectLocalData, hasLocalData, getAccountData, saveAccountData, syncLocalDataToAccount };
