"use strict";

import { promises as fs } from "node:fs";
import path from "node:path";

const DATA_DIR = process.env.NHIMY_DATA_DIR || path.join(process.cwd(), ".data", "users");
const MAX_BYTES = 450_000;
const VERSION = 1;
const COLLECTIONS = Object.freeze(["profile", "study", "work", "organize", "library"]);
let writeChain = Promise.resolve();

function fileFor(userId) {
  return path.join(DATA_DIR, `${String(userId).replace(/[^a-zA-Z0-9_-]/g, "")}.json`);
}

function emptyData() {
  return { version: VERSION, profile: null, study: null, work: null, organize: null, library: null, updatedAt: null };
}

function normalizeData(input = {}) {
  const data = emptyData();
  for (const key of COLLECTIONS) {
    if (Object.prototype.hasOwnProperty.call(input, key)) data[key] = input[key] && typeof input[key] === "object" ? input[key] : null;
  }
  data.updatedAt = typeof input.updatedAt === "string" ? input.updatedAt : null;
  return data;
}

function serializedSize(data) {
  return Buffer.byteLength(JSON.stringify(data), "utf8");
}

async function ensureDir() {
  await fs.mkdir(DATA_DIR, { recursive: true, mode: 0o700 });
}

async function getUserData(userId) {
  if (!userId) throw new Error("Utilizador inválido.");
  await ensureDir();
  const file = fileFor(userId);
  try {
    const parsed = JSON.parse(await fs.readFile(file, "utf8"));
    const data = normalizeData(parsed);
    return { hasData: COLLECTIONS.some(key => data[key] !== null), data };
  } catch (error) {
    if (error?.code === "ENOENT") return { hasData: false, data: emptyData() };
    throw new Error("Não foi possível ler os dados da conta.");
  }
}

async function replaceUserData(userId, input) {
  if (!userId) throw new Error("Utilizador inválido.");
  const data = normalizeData(input);
  data.updatedAt = new Date().toISOString();
  if (serializedSize(data) > MAX_BYTES) throw new Error("Os dados da conta excedem o limite permitido.");
  await ensureDir();
  const file = fileFor(userId);
  const payload = JSON.stringify(data, null, 2);
  writeChain = writeChain.then(async () => {
    const temp = `${file}.${process.pid}.tmp`;
    await fs.writeFile(temp, payload, { mode: 0o600 });
    await fs.rename(temp, file);
  });
  await writeChain;
  return data;
}


async function deleteUserData(userId) {
  if (!userId) throw new Error("Utilizador inválido.");
  await ensureDir();
  const file = fileFor(userId);
  try { await fs.unlink(file); }
  catch (error) { if (error?.code !== "ENOENT") throw new Error("Não foi possível apagar os dados da conta."); }
  return true;
}

export { DATA_DIR, MAX_BYTES, VERSION, COLLECTIONS, getUserData, replaceUserData, deleteUserData };
