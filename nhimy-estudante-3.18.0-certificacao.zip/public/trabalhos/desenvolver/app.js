import { getProject, setProject, saveSectionContent } from "/js/core/work/storage.js";
import { initWorkProgress } from "/js/core/work/flow.js";
import { guardWorkStage } from "/js/core/work/workflow.js";
import { buildWritingGuide, buildSectionDraft } from "/js/core/work/assistant.js";
import { analyzeWork } from "/js/core/work/quality.js";

const container = document.querySelector("#structureContainer");
const continueButton = document.querySelector("#continueButton");
const buildAllButton = document.querySelector("#buildAllButton");
const project = getProject();
initWorkProgress(project);
if (!project) { window.location.href="/trabalhos/criar/"; throw new Error("Projeto não encontrado"); }
if (!guardWorkStage(project, "desenvolver")) throw new Error("Etapa anterior incompleta");
const structure = Array.isArray(project.structure) ? project.structure : [];
if (!structure.length) { container.innerHTML=`<div class="work-empty"><strong>Nenhuma estrutura encontrada.</strong><p>Volta à estrutura para criar as partes do trabalho.</p></div>`; continueButton.disabled=true; }

function saveContent(id, value) { const current=getProject(); if(!current)return; setProject(saveSectionContent(current, id, value)); }
function render() {
  const current=getProject() || project; const content=current.content||{};
  container.innerHTML=structure.map((item,index)=>{
    const value=typeof content[item.id]==="string"?content[item.id]:""; const guide=buildWritingGuide(current,index); const evidence=guide.evidence.length?`<div class="work-writing-evidence"><strong>📚 Evidências disponíveis</strong>${guide.evidence.map(e=>`<div><p>${escapeHtml(e.text)}</p><small>${escapeHtml(e.sources?.[0]?.title||"Fonte pesquisada")}</small></div>`).join("")}</div>`:`<div class="work-writing-evidence"><strong>📌 Sem fonte específica nesta parte</strong><p>O Nhimy não vai inventar informação. Podes construir com base no que já foi encontrado ou pesquisar novamente.</p></div>`;
    return `<article class="work-development-block"><div class="work-development-heading"><span class="work-development-number">${String(index+1).padStart(2,"0")}</span><h3>${escapeHtml(item.title)}</h3></div><div class="work-ai-note"><strong>🎯 O que esta parte precisa fazer</strong><p>${escapeHtml(guide.objective)}</p><ul>${guide.prompts.map(p=>`<li>${escapeHtml(p)}</li>`).join("")}</ul></div>${evidence}<div class="work-development-tools"><button type="button" class="button button-secondary auto-draft" data-index="${index}">${value.trim()?"Melhorar orientação":"Criar rascunho com apoio do Nhimy"}</button><span class="work-save-state" data-save="${item.id}">Guardado localmente</span></div><textarea class="work-development-editor" data-id="${item.id}" rows="12" placeholder="O Nhimy pode construir uma primeira versão. Também podes editar tudo livremente.">${escapeHtml(value)}</textarea><small class="work-word-count" data-count="${item.id}">${count(value)} palavras</small></article>`;
  }).join("");
  container.querySelectorAll("textarea").forEach(editor=>editor.addEventListener("input",()=>{saveContent(editor.dataset.id,editor.value); document.querySelector(`[data-save="${CSS.escape(editor.dataset.id)}"]`)?.replaceChildren(document.createTextNode("Guardado agora")); document.querySelector(`[data-count="${CSS.escape(editor.dataset.id)}"]`).textContent=`${count(editor.value)} palavras`; }));
  container.querySelectorAll(".auto-draft").forEach(button=>button.addEventListener("click",()=>{ const i=Number(button.dataset.index); const draft=buildSectionDraft(getProject()||project,i); const editor=container.querySelector(`textarea[data-id="${CSS.escape(structure[i].id)}"]`); if(editor){ editor.value=draft; saveContent(structure[i].id,draft); editor.focus(); button.textContent="Rascunho criado — podes editar"; } }));
}

buildAllButton?.addEventListener("click", () => {
  const current = getProject() || project;
  const nextContent = { ...(current.content || {}) };
  structure.forEach((_, index) => { nextContent[structure[index].id] = buildSectionDraft(current, index); });
  setProject({ ...current, content: nextContent, reviewed: false, qualityReport: null, finalized: false, finalVersion: null });
  render();
  buildAllButton.textContent = "Primeira versão criada — revê e edita";
});
continueButton.onclick=()=>{ const current=getProject(); const report=analyzeWork(current); setProject({...current,qualityReport:report,reviewed:false,finalized:false}); window.location.href="/trabalhos/revisar/"; };
function count(v){return String(v||"").trim()?String(v).trim().split(/\s+/).length:0;} function escapeHtml(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");}
render();
