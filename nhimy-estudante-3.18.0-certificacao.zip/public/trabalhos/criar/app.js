import { getProject, createProject, setProject, saveIdentity } from "/js/core/work/storage.js";
import { initWorkProgress } from "/js/core/work/flow.js";

const form = document.querySelector("#workForm");
const title = document.querySelector("#workTitle");
const subject = document.querySelector("#workSubject");
const type = document.querySelector("#workType");
const orientationOptions = document.querySelectorAll('input[name="workOrientation"]');
const message = document.querySelector("#formMessage");
let existingProject = getProject();
initWorkProgress(existingProject);
if (existingProject?.orientation) document.querySelector(`input[name="workOrientation"][value="${CSS.escape(existingProject.orientation)}"]`)?.click();
if (existingProject) { title.value = existingProject.title || ""; subject.value = existingProject.subject || ""; type.value = existingProject.type || ""; }

function show(messageText, tone="info") { if (message) { message.textContent = messageText; message.dataset.tone = tone; } }
form.addEventListener("submit", event => {
  event.preventDefault();
  const selected = [...orientationOptions].find(o => o.checked);
  const topic = title.value.trim();
  const discipline = subject.value.trim();
  if (!topic && selected?.value !== "zero") { show("Para começar, indique pelo menos o tema. O restante o Nhimy ajuda a construir.", "warning"); title.focus(); return; }
  if (!discipline) { show("Indique a disciplina para o Nhimy adaptar a pesquisa e a estrutura.", "warning"); subject.focus(); return; }
  if (!selected) { show("Escolha como estás a começar. Se só tens o básico, podes escolher “Tenho um tema”.", "warning"); return; }
  let project = existingProject
    ? saveIdentity(existingProject, { title: topic, subject: discipline, type: type.value, orientation: selected.value })
    : createProject({ title: topic, subject: discipline, type: type.value, orientation: selected.value });
  setProject(project);
  window.location.href = "/trabalhos/orientar/";
});
