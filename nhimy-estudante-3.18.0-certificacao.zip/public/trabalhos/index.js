import { createTaskFromCurrentWork } from "/js/core/student/actions.js";
import { getProject } from "/js/core/work/storage.js";
import { getCurrentWorkStage, getWorkRoute, getWorkProgress } from "/js/core/work/workflow.js";

const target = document.querySelector("#currentWork");
const project = getProject();
const stageKey = getCurrentWorkStage(project);
const href = getWorkRoute(project);
const labels = {
  criar: "Começar trabalho",
  orientar: "Continuar orientação",
  estruturar: "Continuar estrutura",
  desenvolver: "Continuar desenvolvimento",
  revisar: "Continuar revisão",
  finalizar: project?.finalized ? "Abrir trabalho finalizado" : "Finalizar trabalho"
};

if (target && project) {
  target.hidden = false;
  target.innerHTML = `
    <div>
      <span class="section-kicker">Projeto atual · ${getWorkProgress(project)}%</span>
      <h2></h2>
      <p></p>
    </div>
    <a class="button button-primary"></a>
  `;
  target.querySelector("h2").textContent = project.title || "Trabalho sem título";
  target.querySelector("p").textContent = project.subject ? `Disciplina: ${project.subject}` : "Continua a partir do ponto em que paraste.";
  const link = target.querySelector("a");
  link.href = href;
  link.textContent = `${labels[stageKey] || "Continuar trabalho"} →`;

  const integration = document.querySelector("#workIntegration");
  if (integration) {
    integration.hidden = false;
    integration.innerHTML = `<button type="button" class="button button-secondary" id="createWorkTask">☑️ Criar tarefa para este trabalho</button><span id="workTaskStatus" role="status"></span>`;
    const button = integration.querySelector("#createWorkTask");
    const status = integration.querySelector("#workTaskStatus");
    button.addEventListener("click", () => {
      const task = createTaskFromCurrentWork();
      if (!task) {
        status.textContent = "Não foi possível criar a tarefa.";
        return;
      }
      button.disabled = true;
      button.textContent = "✓ Tarefa criada";
      status.textContent = `“${task.title}” foi adicionada a Organizar.`;
    });
  }
}
