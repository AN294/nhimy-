import { getProject, setProject, normalizeStructure, uid, saveStructure } from "/js/core/work/storage.js";
import { initWorkProgress } from "/js/core/work/flow.js";
import { guardWorkStage } from "/js/core/work/workflow.js";
import { suggestStructure } from "/js/core/work/structure.js";

const project = getProject();
initWorkProgress(project);
if (!project) { window.location.href = "/trabalhos/criar/"; throw new Error("Projeto não encontrado"); }
if (!guardWorkStage(project, "estruturar")) throw new Error("Etapa anterior incompleta");
const projectTitle = document.querySelector("#projectTitle");
const projectInfo = document.querySelector("#projectInfo");
const sectionTitle = document.querySelector("#sectionTitle");
const addSection = document.querySelector("#addSection");
const structureList = document.querySelector("#structureList");
const continueButton = document.querySelector("#continueButton");
const researchNote = document.querySelector("#researchNote");
let structure = normalizeStructure(project.structure);

if (!structure.length) {
  structure = suggestStructure({ type: project.type, subject: project.subject, orientationContext: project.orientationContext, researchPlan: project.researchPlan });
  save();
}
projectTitle.textContent = project.title || "Seu trabalho";
projectInfo.textContent = `${project.subject ? `Disciplina: ${project.subject}` : ""}${project.research?.sourceCount ? ` · ${project.research.sourceCount} fonte(s) encontrada(s)` : ""}`;
if (researchNote) researchNote.textContent = project.researchStatus === "ready" ? `Pesquisa preparada: ${project.research.sourceCount || 0} fonte(s). A estrutura pode ser ajustada antes da construção.` : "O Nhimy pode construir o trabalho mesmo sem pesquisa externa disponível; quando houver fontes, elas serão associadas às partes adequadas.";

function save() { const current = getProject(); if (current) setProject(saveStructure(current, structure)); }
function render() {
  structureList.innerHTML = "";
  structure.forEach((item, index) => {
    const el = document.createElement("article"); el.className = "work-structure-item";
    el.innerHTML = `<span class="work-structure-number">${String(index+1).padStart(2,"0")}</span><div class="work-structure-main"><strong></strong><small></small></div><div class="work-structure-actions"><button type="button" data-up aria-label="Mover para cima">↑</button><button type="button" data-down aria-label="Mover para baixo">↓</button><button type="button" data-rename>Editar</button><button type="button" data-remove aria-label="Remover tópico">×</button></div>`;
    el.querySelector("strong").textContent = item.title; el.querySelector("small").textContent = item.purpose || "Parte essencial do trabalho.";
    el.querySelector("[data-up]").disabled = index === 0; el.querySelector("[data-down]").disabled = index === structure.length-1;
    el.querySelector("[data-up]").onclick = () => { [structure[index-1],structure[index]]=[structure[index],structure[index-1]]; save(); render(); };
    el.querySelector("[data-down]").onclick = () => { [structure[index+1],structure[index]]=[structure[index],structure[index+1]]; save(); render(); };
    el.querySelector("[data-rename]").onclick = () => { const next = prompt("Nome da seção", item.title); if (next?.trim()) { structure[index] = { ...item, title: next.trim() }; save(); render(); } };
    el.querySelector("[data-remove]").onclick = () => { const current = getProject(); const removedId = structure[index].id; structure.splice(index,1); const content = { ...(current?.content || {}) }; delete content[removedId]; const checks = { ...(current?.reviewChecks || {}) }; Object.keys(checks).filter(k => k.startsWith(`${removedId}.`)).forEach(k => delete checks[k]); setProject(saveStructure({ ...current, content, reviewChecks: checks }, structure)); render(); };
    structureList.appendChild(el);
  });
}
function add() { const value = sectionTitle.value.trim(); if (!value) return sectionTitle.focus(); structure.push({ id: uid("sec"), title:value, purpose:"Desenvolver esta parte de forma coerente com o tema e o objetivo do trabalho.", order:structure.length }); save(); sectionTitle.value=""; render(); sectionTitle.focus(); }
addSection.onclick = add; sectionTitle.onkeydown = e => { if(e.key === "Enter"){e.preventDefault();add();} };
continueButton.onclick = () => { save(); window.location.href="/trabalhos/desenvolver/"; };
render();
