import { getProject, setProject, saveOrientation } from "/js/core/work/storage.js";
import { initWorkProgress } from "/js/core/work/flow.js";
import { guardWorkStage } from "/js/core/work/workflow.js";
import { createResearchPlan } from "/js/core/work/intelligence.js";
import { buildResearchRequest } from "/js/core/work/research/requestBuilder.js";

const project=getProject(); initWorkProgress(project);
if(!project){window.location.href="/trabalhos/criar/";throw new Error("Projeto não encontrado");}
if(!guardWorkStage(project,"orientar")) throw new Error("Etapa anterior incompleta");
const titleEl=document.querySelector("#orientationTitle"), descEl=document.querySelector("#orientationDescription"), contentEl=document.querySelector("#orientationContent"), btn=document.querySelector("#continueButton");
const modes={
 tema:{title:"Já tens o tema. O Nhimy cuida do resto.",description:"Só o tema e a disciplina já são suficientes para começar. A pesquisa, estrutura e construção ficam por nossa conta.",label:"Há alguma instrução ou objetivo do professor?",placeholder:"Opcional — podes deixar em branco.",help:"Se não houver nenhuma instrução, o Nhimy cria um plano adequado ao contexto."},
 ideias:{title:"Tens ideias? O Nhimy transforma-as em trabalho.",description:"Podes trazer ideias, mas elas não são obrigatórias para continuar.",label:"Que ideias ou instruções queres acrescentar?",placeholder:"Opcional — escreve apenas o que achares importante.",help:"O Nhimy organiza e completa as lacunas."},
 inicio:{title:"Já começaste? Vamos aproveitar o que existe.",description:"O conteúdo existente será preservado e integrado ao novo plano.",label:"O que já tens?",placeholder:"Opcional — cola aqui o que já começaste.",help:"Se não tiveres nada, deixa em branco e o Nhimy começa do zero."},
 instrucoes:{title:"Vamos transformar as instruções em requisitos.",description:"As instruções ajudam o Nhimy a respeitar exatamente o que foi pedido.",label:"O que o professor pediu?",placeholder:"Cole aqui as instruções.",help:"Se não tiveres instruções, podemos continuar com o tema e a disciplina."},
 zero:{title:"Não tens um ponto de partida? Tudo bem.",description:"O Nhimy precisa apenas de um tema e uma disciplina para assumir a construção.",label:"Qual é o tema ou assunto, se já souberes?",placeholder:"Ex.: Ansiedade e depressão na gravidez",help:"Se ainda não tens nem tema, será preciso descobrir um antes da pesquisa."}
};
const mode=modes[project.orientation]||modes.tema; titleEl.textContent=mode.title; descEl.textContent=mode.description; const subjectField=project.subject==="A definir" ? `<div class="form-group"><label class="form-label" for="orientationSubject">Disciplina</label><input id="orientationSubject" type="text" value="" placeholder="Ex.: Biologia" autocomplete="off"><span class="form-help">Como este trabalho veio de um estudo, falta apenas confirmar a disciplina.</span></div>` : ""; contentEl.innerHTML=`${subjectField}<div class="work-orientation-form"><label class="form-label" for="orientationInput">${mode.label}</label><textarea id="orientationInput" rows="7" placeholder="${mode.placeholder}">${escapeHtml(project.orientationContext||"")}</textarea><span class="form-help">${mode.help}</span></div>`;
const input=document.querySelector("#orientationInput");
async function run(){
 const current=getProject(); let context=input?.value.trim()||current.orientationContext||""; let topic=current.title||""; const subjectInput=document.querySelector("#orientationSubject"); const subject=subjectInput ? subjectInput.value.trim() : current.subject; if(subjectInput && !subject){ subjectInput.focus(); return; }
 if(!topic && current.orientation==="zero" && context){ topic=context; context=""; }
 if(!topic){ input?.focus(); return; }
 btn.disabled=true;
 try{
   const plan=createResearchPlan({title:topic,subject,orientationContext:context,questions:[],researchNeeds:[],requestedSections:[],materials:[]});
   if(plan.status!=="success") throw new Error(plan.message||"Não foi possível criar o plano.");
   const request=buildResearchRequest({topic:plan.topic,subject:plan.subject,questions:plan.questions.length?plan.questions:[`O que é ${plan.topic} e qual é o seu contexto?`,`Quais são os principais aspectos, causas, características, consequências, aplicações ou desafios de ${plan.topic}?`,`Qual é a importância de ${plan.topic} para a disciplina ${plan.subject||"em estudo"}?`],sections:plan.sections,sourcePolicy:{requireSource:true,preserveSourceDetails:true,allowStudentMaterials:true,allowExternalSources:true}});
   let result=null,status="unavailable";
   try{const r=await fetch("/api/research",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(request)});const d=await r.json();if(r.ok&&d.ok&&d.result){result=d.result;status=result.readyForStructure?"ready":"partial";}}catch(e){console.warn("Research indisponível",e);}
   setProject(saveOrientation({...current,subject},{title:topic,orientation:current.orientation,orientationContext:context,researchReady:!!result?.readyForStructure,researchStatus:status,research:result,researchPlan:plan,researchRequest:request}));
   window.location.href="/trabalhos/estruturar/";
 }catch(e){console.error(e);btn.disabled=false;alert("Não foi possível preparar o trabalho. Tenta novamente.");}
}
btn.addEventListener("click",run); function escapeHtml(v){return String(v??"").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;");}
