/*
 * =========================================================
 * NHIMY — WORK STRUCTURE
 *
 * Motor inicial de sugestão de estrutura para Trabalhos.
 *
 * Não acessa sessionStorage.
 * Recebe dados do projeto e devolve uma estrutura inicial.
 * =========================================================
 */


function suggestStructure({
  type = "",
  orientation = "",
  orientationContext = ""
} = {}) {

  const normalizedType =
    typeof type === "string"
      ? type.trim().toLowerCase()
      : "";

  const normalizedOrientation =
    typeof orientation === "string"
      ? orientation.trim().toLowerCase()
      : "";

  const context =
    typeof orientationContext === "string"
      ? orientationContext.trim()
      : "";


  if (
    normalizedType === "apresentacao"
  ) {
    return [
      "Introdução",
      "Desenvolvimento",
      "Conclusão"
    ];
  }


  if (
    normalizedType === "relatorio"
  ) {
    return [
      "Introdução",
      "Objetivos",
      "Desenvolvimento",
      "Resultados",
      "Conclusão"
    ];
  }


  if (
    normalizedType === "pesquisa"
  ) {
    return [
      "Introdução",
      "Contextualização do tema",
      "Desenvolvimento",
      "Análise",
      "Conclusão",
      "Referências"
    ];
  }


  if (
    normalizedOrientation === "zero" &&
    !context
  ) {
    return [
      "Introdução",
      "Desenvolvimento",
      "Conclusão"
    ];
  }


  return [
    "Introdução",
    "Desenvolvimento",
    "Conclusão"
  ];
}


export {
  suggestStructure
};
