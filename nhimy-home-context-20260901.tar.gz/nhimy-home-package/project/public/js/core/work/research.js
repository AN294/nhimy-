"use strict";

import { buildResearchRequest } from "./research/requestBuilder.js";

/*
 * =========================================================
 * NHIMY — WORK / RESEARCH
 *
 * Camada responsável por organizar a pesquisa do trabalho.
 *
 * IMPORTANTE:
 * Esta camada não inventa fontes nem transforma
 * automaticamente informações em texto final.
 *
 * Ela prepara solicitações de pesquisa e organiza
 * posteriormente os resultados obtidos.
 * =========================================================
 */

function isValidText(value) {
  return (
    typeof value === "string" &&
    value.trim().length > 0
  );
}


export function createResearchRequest(input = {}) {
  try {
    return buildResearchRequest({
      topic:
        typeof input.topic === "string"
          ? input.topic
          : "",

      subject:
        typeof input.subject === "string"
          ? input.subject
          : "",

      questions:
        Array.isArray(input.questions)
          ? input.questions
          : [],

      sections:
        Array.isArray(input.sections)
          ? input.sections
          : [],

      sourcePolicy:
        input.sourcePolicy || {}
    });
  } catch (error) {
    return {
      status: "error",
      type: "work-research-request",
      message:
        error?.message ||
        "Não foi possível criar a solicitação de pesquisa."
    };
  }
}

export function createResearchResult(input = {}) {

  const topic =
    isValidText(input.topic)
      ? input.topic.trim()
      : "";

  const findings =
    Array.isArray(input.findings)
      ? input.findings.filter(Boolean)
      : [];

  const sources =
    Array.isArray(input.sources)
      ? input.sources.filter(Boolean)
      : [];

  if (!topic) {
    return {
      status: "error",
      type: "work-research-result",
      message: "O tema da pesquisa é obrigatório."
    };
  }

  return {
    status: "success",
    type: "work-research-result",

    topic,

    findings,

    sources,

    sourceCount: sources.length,

    readyForStructure:
      findings.length > 0 &&
      sources.length > 0,

    nextStep:
      findings.length > 0 &&
      sources.length > 0
        ? "structure"
        : "collect"
  };
}
