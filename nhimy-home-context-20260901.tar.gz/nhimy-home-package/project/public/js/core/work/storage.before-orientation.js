"use strict";

/*
 * =========================================================
 * NHIMY — WORK STORAGE
 *
 * Fonte central do estado de Trabalhos.
 *
 * Nenhum módulo de Trabalhos deve acessar
 * diretamente o sessionStorage.
 * =========================================================
 */

const KEY = "nhimy.work.project";


function read() {
  const stored = sessionStorage.getItem(KEY);

  if (!stored) {
    return null;
  }

  try {
    return JSON.parse(stored);
  } catch (error) {
    console.error(
      "Erro ao ler estado do trabalho.",
      error
    );

    return null;
  }
}


function write(project) {
  sessionStorage.setItem(
    KEY,
    JSON.stringify(project)
  );
}


function getProject() {
  return read();
}


function setProject(project) {
  if (
    !project ||
    typeof project !== "object"
  ) {
    return false;
  }

  write(project);

  return true;
}


function clearProject() {
  sessionStorage.removeItem(KEY);
}


export {
  KEY,
  getProject,
  setProject,
  clearProject
};
