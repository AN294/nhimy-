import {
  getProject,
  setProject
} from "/js/core/work/storage.js";


const project = getProject();


if (!project) {
  window.location.href = "/trabalhos/criar/";
}


const orientationTitle =
  document.querySelector("#orientationTitle");

const orientationDescription =
  document.querySelector("#orientationDescription");

const orientationContent =
  document.querySelector("#orientationContent");

const continueButton =
  document.querySelector("#continueButton");


const orientations = {

  tema: {
    title: "Você já tem um tema. Vamos transformá-lo em um trabalho.",
    description:
      "O próximo passo é descobrir o que precisa ser desenvolvido a partir desse tema.",
    prompt:
      "Vamos identificar o objetivo, os pontos principais e uma possível estrutura para o seu trabalho."
  },

  ideias: {
    title: "Você já tem ideias. Agora vamos colocá-las em ordem.",
    description:
      "Não precisa organizar tudo sozinho.",
    prompt:
      "Vamos reunir suas ideias, identificar o que está relacionado e transformar isso em uma estrutura."
  },

  inicio: {
    title: "Você já começou. Vamos continuar de onde parou.",
    description:
      "O que você escreveu pode servir como ponto de partida.",
    prompt:
      "Vamos analisar o que já existe e descobrir o que ainda precisa ser desenvolvido."
  },

  instrucoes: {
    title: "Vamos transformar as instruções do professor em um plano.",
    description:
      "As instruções são importantes para saber exatamente o que o trabalho precisa conter.",
    prompt:
      "Vamos organizar essas orientações e transformá-las em passos claros."
  },

  zero: {
    title: "Tudo bem não saber por onde começar.",
    description:
      "O Nhimy vai ajudar você a dar o primeiro passo.",
    prompt:
      "Vamos começar entendendo o que você precisa fazer e construir o trabalho a partir daí."
  }

};


const current =
  orientations[project?.orientation];


if (current) {

  orientationTitle.textContent =
    current.title;

  orientationDescription.textContent =
    current.description;

  orientationContent.innerHTML = `
    <div class="work-orientation-result">
      <p>${current.prompt}</p>
    </div>
  `;

}


continueButton.addEventListener("click", () => {

  const currentProject = getProject();

  if (!currentProject) {
    window.location.href = "/trabalhos/criar/";
    return;
  }

  setProject({
    ...currentProject,
    orientationReady: true
  });

  window.location.href =
    "/trabalhos/estruturar/";

});
