"use strict";

/*
 * =========================================================
 * NHIMY — ESTUDAR / EXPLICAR / PEDAGOGY
 *
 * Responsabilidade:
 * transformar informações analisadas pelo motor de
 * inteligência em uma explicação organizada para o estudante.
 *
 * Esta camada não conhece a interface.
 * Também não depende de uma IA externa.
 *
 * Futuramente, a IA poderá substituir ou enriquecer
 * esta composição sem alterar o app.js.
 * =========================================================
 */

function addUnique(parts, value) {

  if (!value || !value.trim()) {
    return;
  }

  const normalized = value.trim();

  if (
    !parts.some(
      part => part.toLowerCase() === normalized.toLowerCase()
    )
  ) {
    parts.push(normalized);
  }
}


export function composeExplanation(result) {

  if (!result) {
    return "";
  }

  const parts = [];

  addUnique(parts, result.mainIdea);
  addUnique(parts, result.howItWorks);
  addUnique(parts, result.result);
  addUnique(parts, result.importance);

  return parts.join(" ");
}
