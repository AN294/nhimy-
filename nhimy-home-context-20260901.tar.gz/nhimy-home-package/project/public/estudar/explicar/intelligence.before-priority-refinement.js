"use strict";

/*
 * =========================================================
 * NHIMY — ESTUDAR / EXPLICAR / INTELLIGENCE
 *
 * Motor local de explicação.
 *
 * O conteúdo é analisado por frases e não apenas por
 * parágrafos, permitindo construir uma explicação mais útil.
 *
 * A inteligência externa poderá substituir este motor
 * futuramente sem alterar a interface do estudante.
 * =========================================================
 */

function splitBlocks(content) {

  return content
    .split(/\n+/)
    .map(block => block.trim())
    .filter(Boolean);
}


function splitSentences(text) {

  return text
    .replace(/\s+/g, " ")
    .split(/(?<=[.!?])\s+/)
    .map(sentence => sentence.trim())
    .filter(sentence => sentence.length > 15);
}


function cleanText(text) {

  return text
    .replace(/^#+\s*/, "")
    .replace(/^\*\*(.*?)\*\*$/, "$1")
    .replace(/^[•*-]\s+/, "")
    .replace(/^\d+[.)]\s+/, "")
    .trim();
}


function collectSentences(content) {

  const blocks = splitBlocks(content);

  return blocks
    .flatMap(block => splitSentences(cleanText(block)))
    .filter(Boolean);
}


function scoreSentence(sentence) {

  let score = 0;
  const text = sentence.toLowerCase();

  if (
    /\bé o\b/.test(text) ||
    /\bsão\b/.test(text) ||
    /\bconsiste em\b/.test(text) ||
    /\bsignifica\b/.test(text)
  ) {
    score += 5;
  }

  if (
    /\bimportante\b/.test(text) ||
    /\bfundamental\b/.test(text) ||
    /\bprincipal\b/.test(text) ||
    /\bessencial\b/.test(text)
  ) {
    score += 4;
  }

  if (
    /\bprocesso\b/.test(text) ||
    /\bocorre\b/.test(text) ||
    /\bpermite\b/.test(text) ||
    /\bproduz\b/.test(text) ||
    /\butiliza\b/.test(text)
  ) {
    score += 3;
  }

  if (sentence.length >= 40 && sentence.length <= 280) {
    score += 2;
  }

  return score;
}


function rankSentences(sentences) {

  return sentences
    .map((sentence, index) => ({
      sentence,
      score: scoreSentence(sentence),
      index
    }))
    .sort((a, b) => {

      if (b.score !== a.score) {
        return b.score - a.score;
      }

      return a.index - b.index;
    });
}


function findByPatterns(sentences, patterns) {

  return sentences.find(sentence =>
    patterns.some(pattern => pattern.test(sentence))
  ) || null;
}


function createMainIdea(sentences) {

  const ranked = rankSentences(sentences);

  if (!ranked.length) {
    return "Não foi possível identificar a ideia principal.";
  }

  return ranked[0].sentence;
}


function createExplanation(sentences) {

  if (!sentences.length) {
    return "O conteúdo fornecido é muito curto para gerar uma explicação adequada.";
  }

  const mainIdea = createMainIdea(sentences);

  const supporting = sentences
    .filter(sentence => sentence !== mainIdea)
    .slice(0, 3);

  return [mainIdea, ...supporting].join(" ");
}


function createHowItWorks(sentences) {

  const process = findByPatterns(sentences, [
    /\bprocesso\b/i,
    /\bocorre\b/i,
    /\bdurante\b/i,
    /\butiliza\b/i,
    /\bpermite\b/i,
    /\bproduz\b/i
  ]);

  return process ||
    "O conteúdo não apresenta detalhes suficientes para identificar claramente como o assunto funciona.";
}


function createImportance(sentences) {

  return findByPatterns(sentences, [
    /\bimportante\b/i,
    /\bfundamental\b/i,
    /\bessencial\b/i,
    /\bcontribui\b/i,
    /\bporque\b/i
  ]) ||
    "A importância do assunto pode ser compreendida a partir das informações apresentadas no conteúdo.";
}


function createExample(sentences) {

  return findByPatterns(sentences, [
    /\bpor exemplo\b/i,
    /\bexemplo\b/i,
    /\btal como\b/i
  ]) ||
    "Pense no assunto como uma situação concreta em que as ideias apresentadas acontecem na prática.";
}


function createKeyPoints(sentences) {

  const ranked = rankSentences(sentences);

  const selected = [];
  const seen = new Set();

  for (const item of ranked) {

    const normalized = item.sentence.toLowerCase();

    if (seen.has(normalized)) {
      continue;
    }

    seen.add(normalized);
    selected.push(item.sentence);

    if (selected.length === 5) {
      break;
    }
  }

  return selected.map(sentence => `• ${sentence}`);
}


function createExplanationResult(prepared) {

  const sentences =
    collectSentences(prepared.content);

  return {

    title: "Explicação do conteúdo",

    summary:
      "O Nhimy separou as ideias do conteúdo para facilitar a compreensão.",

    mainIdea:
      createMainIdea(sentences),

    explanation:
      createExplanation(sentences),

    howItWorks:
      createHowItWorks(sentences),

    importance:
      createImportance(sentences),

    example:
      createExample(sentences),

    keyPoints:
      createKeyPoints(sentences),

    words:
      prepared.words,

    characters:
      prepared.characters

  };
}


export function processExplanation(prepared) {

  return createExplanationResult(prepared);

}
