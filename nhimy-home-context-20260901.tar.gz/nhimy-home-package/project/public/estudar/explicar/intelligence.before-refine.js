"use strict";

/*
 * =========================================================
 * NHIMY — ESTUDAR / EXPLICAR / INTELLIGENCE
 *
 * Motor local de explicação.
 *
 * Responsabilidade:
 * transformar o conteúdo preparado em uma explicação
 * organizada para o estudante.
 *
 * A inteligência externa poderá ser conectada futuramente
 * sem alterar a interface do estudante.
 * =========================================================
 */

function splitBlocks(content) {

  return content
    .split(/\n+/)
    .map(block => block.trim())
    .filter(Boolean);
}


function cleanBlock(block) {

  return block
    .replace(/^[•*-]\s+/, "")
    .replace(/^\d+[.)]\s+/, "")
    .trim();
}


function isHeading(block) {

  return (
    /^#+\s+/.test(block) ||
    /^\*\*.+\*\*$/.test(block)
  );
}


function createMainIdea(blocks) {

  const usefulBlocks = blocks
    .filter(block => !isHeading(block))
    .map(cleanBlock)
    .filter(block => block.length > 20);

  return usefulBlocks[0] || "Não foi possível identificar uma ideia principal.";
}


function createSimpleExplanation(blocks) {

  const usefulBlocks = blocks
    .filter(block => !isHeading(block))
    .map(cleanBlock)
    .filter(block => block.length > 20);

  if (!usefulBlocks.length) {
    return "O conteúdo fornecido é muito curto para gerar uma explicação.";
  }

  return usefulBlocks
    .slice(0, 3)
    .join(" ");
}


function createKeyPoints(blocks) {

  return blocks
    .filter(block => !isHeading(block))
    .map(cleanBlock)
    .filter(block => block.length > 20)
    .slice(0, 5)
    .map(block => `• ${block}`);
}


function createExplanation(prepared) {

  const blocks = splitBlocks(prepared.content);

  const mainIdea = createMainIdea(blocks);

  const explanation = createSimpleExplanation(blocks);

  const keyPoints = createKeyPoints(blocks);

  return {

    title: "Explicação do conteúdo",

    summary:
      "Entenda primeiro a ideia principal e depois os pontos que merecem atenção.",

    mainIdea,

    explanation,

    keyPoints,

    words: prepared.words,

    characters: prepared.characters

  };
}


export function processExplanation(prepared) {

  return createExplanation(prepared);

}
