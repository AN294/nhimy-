"use strict";

/*
 * =========================================================
 * NHIMY — ESTUDAR / EXPLICAR / INTELLIGENCE
 *
 * Motor local de explicação.
 *
 * Objetivo:
 * transformar conteúdo bruto em uma estrutura de
 * aprendizagem mais clara.
 *
 * A IA poderá substituir este motor futuramente sem
 * alterar a interface do estudante.
 * =========================================================
 */

function splitBlocks(content) {

  return content
    .split(/\n+/)
    .map(block => block.trim())
    .filter(Boolean);
}


function cleanBlock(block) {

  return block
    .replace(/^#+\s*/, "")
    .replace(/^\*\*(.*?)\*\*$/, "$1")
    .replace(/^[•*-]\s+/, "")
    .replace(/^\d+[.)]\s+/, "")
    .trim();
}


function isHeading(block) {

  return (
    /^#+\s+/.test(block) ||
    /^\*\*.+\*\*$/.test(block)
  );
}


function usefulBlocks(blocks) {

  return blocks
    .filter(block => !isHeading(block))
    .map(cleanBlock)
    .filter(block => block.length > 20);
}


function splitSentences(text) {

  return text
    .split(/(?<=[.!?])\s+/)
    .map(sentence => sentence.trim())
    .filter(sentence => sentence.length > 15);
}


function findDefinition(blocks) {

  const patterns = [
    /\bé o\b/i,
    /\bsão\b/i,
    /\bconsiste em\b/i,
    /\bdefine-se como\b/i,
    /\bchama-se\b/i,
    /\bsignifica\b/i
  ];

  return blocks.find(block =>
    patterns.some(pattern => pattern.test(block))
  ) || null;
}


function findProcess(blocks) {

  const patterns = [
    /\bprocesso\b/i,
    /\bocorre\b/i,
    /\betapa\b/i,
    /\betapas\b/i,
    /\bdurante\b/i,
    /\butiliza\b/i,
    /\bproduz\b/i,
    /\bpermite\b/i
  ];

  return blocks.find(block =>
    patterns.some(pattern => pattern.test(block))
  ) || null;
}


function findExample(blocks) {

  const patterns = [
    /\bpor exemplo\b/i,
    /\bcomo\b/i,
    /\bexemplo\b/i,
    /\btal como\b/i
  ];

  return blocks.find(block =>
    patterns.some(pattern => pattern.test(block))
  ) || null;
}


function scoreBlock(block) {

  let score = 0;
  const text = block.toLowerCase();

  if (/\bé o\b|\bconsiste em\b|\bsignifica\b/.test(text)) {
    score += 5;
  }

  if (/\bimportante\b|\bfundamental\b|\bprincipal\b|\bessencial\b/.test(text)) {
    score += 4;
  }

  if (/\bprocesso\b|\bocorre\b|\bpermite\b|\bproduz\b/.test(text)) {
    score += 3;
  }

  if (block.length >= 40 && block.length <= 300) {
    score += 2;
  }

  return score;
}


function createMainIdea(blocks) {

  const candidates = usefulBlocks(blocks)
    .map((block, index) => ({
      block,
      score: scoreBlock(block),
      index
    }))
    .sort((a, b) => {
      if (b.score !== a.score) {
        return b.score - a.score;
      }

      return a.index - b.index;
    });

  if (!candidates.length) {
    return "Não foi possível identificar uma ideia principal.";
  }

  const sentences = splitSentences(candidates[0].block);

  return sentences.length
    ? sentences[0]
    : candidates[0].block;
}


function buildExplanation(blocks) {

  const candidates = usefulBlocks(blocks);

  if (!candidates.length) {
    return "O conteúdo fornecido é muito curto para gerar uma explicação adequada.";
  }

  const definition = findDefinition(candidates);

  if (definition) {
    return definition;
  }

  const process = findProcess(candidates);

  if (process) {
    return process;
  }

  return candidates
    .slice(0, 2)
    .map(block => {
      const sentences = splitSentences(block);
      return sentences.slice(0, 2).join(" ");
    })
    .join(" ");
}


function createExample(blocks) {

  const example = findExample(blocks);

  if (example) {
    return example;
  }

  return "Um exemplo prático pode ser construído a partir do assunto apresentado no conteúdo.";
}


function createKeyPoints(blocks) {

  const candidates = usefulBlocks(blocks)
    .map((block, index) => ({
      block,
      score: scoreBlock(block),
      index
    }))
    .sort((a, b) => {
      if (b.score !== a.score) {
        return b.score - a.score;
      }

      return a.index - b.index;
    });

  const selected = [];
  const seen = new Set();

  for (const item of candidates) {

    const normalized = item.block.toLowerCase();

    if (seen.has(normalized)) {
      continue;
    }

    seen.add(normalized);
    selected.push(item.block);

    if (selected.length === 5) {
      break;
    }
  }

  return selected.map(block => `• ${block}`);
}


function createExplanation(prepared) {

  const blocks = splitBlocks(prepared.content);

  return {

    title: "Explicação do conteúdo",

    summary:
      "O Nhimy organizou o conteúdo para ajudar você a compreender a ideia central e os pontos mais importantes.",

    mainIdea:
      createMainIdea(blocks),

    explanation:
      buildExplanation(blocks),

    example:
      createExample(blocks),

    keyPoints:
      createKeyPoints(blocks),

    words:
      prepared.words,

    characters:
      prepared.characters

  };
}


export function processExplanation(prepared) {

  return createExplanation(prepared);

}
