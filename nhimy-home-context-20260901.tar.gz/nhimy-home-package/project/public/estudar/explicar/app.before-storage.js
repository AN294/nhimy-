"use strict";

/*
 * =========================================================
 * NHIMY — ESTUDAR / EXPLICAR
 *
 * Motor inicial de explicação.
 *
 * Entrada:
 * - conteúdo preparado pelo Resumir
 * - conteúdo digitado manualmente
 *
 * Preparado para futura integração com IA.
 * =========================================================
 */

const explainText =
  document.getElementById("explainText");

const explainStart =
  document.getElementById("explainStart");

const explainResult =
  document.getElementById("explainResult");

const explainOutput =
  document.getElementById("explainOutput");


function loadStudyContent() {

  const stored =
    sessionStorage.getItem(
      "nhimy.study.summary"
    );

  if (!stored) {
    return null;
  }

  try {

    const studyContent =
      JSON.parse(stored);

    if (
      !studyContent ||
      typeof studyContent.result !== "string"
    ) {
      return null;
    }

    return studyContent.result;

  } catch (error) {

    console.error(
      "Erro ao carregar conteúdo para Explicar:",
      error
    );

    return null;
  }
}


function createExplanation(text) {

  const cleanText =
    text.trim();

  const words =
    cleanText.split(/\s+/);

  const preview =
    words.length > 80
      ? words.slice(0, 80).join(" ") + "…"
      : cleanText;

  return {

    title:
      "Explicação do conteúdo",

    summary:
      "Este conteúdo pode ser compreendido a partir da ideia principal apresentada abaixo.",

    content:
      preview

  };
}


function renderExplanation(result) {

  if (!explainOutput) {
    return;
  }

  explainOutput.innerHTML = "";

  const title =
    document.createElement("h3");

  title.textContent =
    result.title;

  const summary =
    document.createElement("p");

  summary.textContent =
    result.summary;

  const content =
    document.createElement("p");

  content.textContent =
    result.content;

  explainOutput.append(
    title,
    summary,
    content
  );

  if (explainResult) {

    explainResult.hidden = false;

    explainResult.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });

  }
}


function explain() {

  const manualContent =
    explainText
      ? explainText.value.trim()
      : "";

  const storedContent =
    loadStudyContent();

  const content =
    manualContent || storedContent;

  if (!content) {

    if (explainText) {
      explainText.focus();
    }

    return;
  }

  explainStart.disabled = true;

  explainStart.textContent =
    "Explicando...";

  setTimeout(() => {

    try {

      const result =
        createExplanation(content);

      renderExplanation(result);

    } finally {

      explainStart.disabled = false;

      explainStart.textContent =
        "Explicar →";

    }

  }, 400);
}


function prepareStoredContent() {

  const content =
    loadStudyContent();

  if (
    content &&
    explainText &&
    !explainText.value.trim()
  ) {

    explainText.value =
      content;

  }

}


if (explainStart) {

  explainStart.addEventListener(
    "click",
    explain
  );

}


if (explainText) {

  explainText.addEventListener(
    "keydown",
    event => {

      if (
        event.key === "Enter" &&
        event.ctrlKey
      ) {

        event.preventDefault();

        explain();

      }

    }
  );

}


prepareStoredContent();
