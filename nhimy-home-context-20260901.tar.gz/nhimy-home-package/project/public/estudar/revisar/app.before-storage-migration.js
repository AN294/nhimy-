"use strict";

/*
 * =========================================================
 * NHIMY — ESTUDAR / REVISAR
 *
 * Responsabilidade:
 * receber o conteúdo preparado pelo módulo Resumir
 * e apresentá-lo para revisão.
 * =========================================================
 */

const reviewContent = document.getElementById("reviewContent");
const reviewBack = document.getElementById("reviewBack");
const reviewNext = document.getElementById("reviewNext");


function loadStudyContent() {

  const stored = sessionStorage.getItem(
    "nhimy.study.summary"
  );

  if (!stored) {
    return false;
  }

  try {

    const studyContent = JSON.parse(stored);

    if (
      !studyContent ||
      typeof studyContent.result !== "string"
    ) {
      return false;
    }

    reviewContent.value = studyContent.result;

    return true;

  } catch (error) {

    console.error(
      "Erro ao carregar conteúdo de estudo:",
      error
    );

    return false;
  }
}


function initReview() {

  const loaded = loadStudyContent();

  if (!loaded) {

    reviewContent.value =
      "Nenhum conteúdo de estudo foi encontrado.";

  }

}


if (reviewBack) {

  reviewBack.addEventListener("click", () => {
    history.back();
  });

}


if (reviewNext) {

  reviewNext.addEventListener("click", () => {

    sessionStorage.setItem(
      "nhimy.study.reviewed",
      "true"
    );

    reviewNext.blur();

    window.location.href = "/estudar/flashcards/";

  });
}


initReview();
