========================================
NHIMY — PACOTE DE CONTEXTO DA HOME
Data: Tue Sep  1 13:14:39 WAT 2026
Diretório: /home/nhimy
========================================

===== ESTRUTURA =====
/tmp/nhimy-home-package/project/package.json
/tmp/nhimy-home-package/project/public/app.js
/tmp/nhimy-home-package/project/public/css/base/reset.css
/tmp/nhimy-home-package/project/public/css/base/typography.css
/tmp/nhimy-home-package/project/public/css/base/variables.css
/tmp/nhimy-home-package/project/public/css/components/buttons.css
/tmp/nhimy-home-package/project/public/css/components/cards.css
/tmp/nhimy-home-package/project/public/css/components/forms.css
/tmp/nhimy-home-package/project/public/css/components/messages.css
/tmp/nhimy-home-package/project/public/css/layout/container.css
/tmp/nhimy-home-package/project/public/css/layout/footer.css
/tmp/nhimy-home-package/project/public/css/layout/header.css
/tmp/nhimy-home-package/project/public/css/layout/sections.css
/tmp/nhimy-home-package/project/public/css/pages/estudante.css
/tmp/nhimy-home-package/project/public/css/pages/home.css
/tmp/nhimy-home-package/project/public/estudar/explicar/app.before-intelligence.js
/tmp/nhimy-home-package/project/public/estudar/explicar/app.before-result-render.js
/tmp/nhimy-home-package/project/public/estudar/explicar/app.before-rich-render.js
/tmp/nhimy-home-package/project/public/estudar/explicar/app.before-storage.js
/tmp/nhimy-home-package/project/public/estudar/explicar/app.js
/tmp/nhimy-home-package/project/public/estudar/explicar/index.html
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-example-engine.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-example-pedagogy.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-explanation-refinement.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-function-result-refinement.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-how-it-works-connection.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-natural-example.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-pedagogical-layer.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-pedagogy-link.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-priority-refinement.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-refine.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-result-refinement.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-sentence-engine.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.before-topic-example.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.js
/tmp/nhimy-home-package/project/public/estudar/explicar/intelligence.js.bak
/tmp/nhimy-home-package/project/public/estudar/explicar/pedagogy.before-context-example.js
/tmp/nhimy-home-package/project/public/estudar/explicar/pedagogy.before-example-engine.js
/tmp/nhimy-home-package/project/public/estudar/explicar/pedagogy.before-example-fix.js
/tmp/nhimy-home-package/project/public/estudar/explicar/pedagogy.before-how-it-works.js
/tmp/nhimy-home-package/project/public/estudar/explicar/pedagogy.js
/tmp/nhimy-home-package/project/public/estudar/explicar/processor.js
/tmp/nhimy-home-package/project/public/estudar/flashcards/app.before-answer-fix.js
/tmp/nhimy-home-package/project/public/estudar/flashcards/app.before-storage-migration.js
/tmp/nhimy-home-package/project/public/estudar/flashcards/app.js
/tmp/nhimy-home-package/project/public/estudar/flashcards/index.html
/tmp/nhimy-home-package/project/public/estudar/index.html
/tmp/nhimy-home-package/project/public/estudar/quiz/app.before-storage.js
/tmp/nhimy-home-package/project/public/estudar/quiz/app.js
/tmp/nhimy-home-package/project/public/estudar/quiz/index.html
/tmp/nhimy-home-package/project/public/estudar/resumir/app.before-storage-migration.js
/tmp/nhimy-home-package/project/public/estudar/resumir/app.js
/tmp/nhimy-home-package/project/public/estudar/resumir/index.html
/tmp/nhimy-home-package/project/public/estudar/resumir/intelligence.before-intelligence-v2-edit.js
/tmp/nhimy-home-package/project/public/estudar/resumir/intelligence.before-intelligence-v2.js
/tmp/nhimy-home-package/project/public/estudar/resumir/intelligence.before-intent-contract.js
/tmp/nhimy-home-package/project/public/estudar/resumir/intelligence.before-intent-definition.js
/tmp/nhimy-home-package/project/public/estudar/resumir/intelligence.before-intent-fix.js
/tmp/nhimy-home-package/project/public/estudar/resumir/intelligence.js
/tmp/nhimy-home-package/project/public/estudar/resumir/processor.js
/tmp/nhimy-home-package/project/public/estudar/revisar/app.before-navigation-guard.js
/tmp/nhimy-home-package/project/public/estudar/revisar/app.before-storage-migration.js
/tmp/nhimy-home-package/project/public/estudar/revisar/app.js
/tmp/nhimy-home-package/project/public/estudar/revisar/index.html
/tmp/nhimy-home-package/project/public/index.html
/tmp/nhimy-home-package/project/public/index.html.before-cap-only
/tmp/nhimy-home-package/project/public/index.html.before-n-fix
/tmp/nhimy-home-package/project/public/index.html.before-signature-3
/tmp/nhimy-home-package/project/public/index.html.signature-v2.bak
/tmp/nhimy-home-package/project/public/intro.js
/tmp/nhimy-home-package/project/public/intro.js.before-cap-only
/tmp/nhimy-home-package/project/public/intro.js.before-signature-3
/tmp/nhimy-home-package/project/public/intro.js.before-signature-3-final
/tmp/nhimy-home-package/project/public/intro.js.signature-v2.bak
/tmp/nhimy-home-package/project/public/js/core/app.js
/tmp/nhimy-home-package/project/public/js/core/dom.js
/tmp/nhimy-home-package/project/public/js/core/home/index.js
/tmp/nhimy-home-package/project/public/js/core/home/state.js
/tmp/nhimy-home-package/project/public/js/core/organize/events.js
/tmp/nhimy-home-package/project/public/js/core/organize/goals.js
/tmp/nhimy-home-package/project/public/js/core/organize/notes.js
/tmp/nhimy-home-package/project/public/js/core/organize/storage.js
/tmp/nhimy-home-package/project/public/js/core/organize/tasks.js
/tmp/nhimy-home-package/project/public/js/core/study/storage.before-intent-contract.js
/tmp/nhimy-home-package/project/public/js/core/study/storage.before-intent-fix.js
/tmp/nhimy-home-package/project/public/js/core/study/storage.js
/tmp/nhimy-home-package/project/public/js/core/utils.js
/tmp/nhimy-home-package/project/public/js/core/work/development.before-evidence.bak
/tmp/nhimy-home-package/project/public/js/core/work/development.before-writing.bak
/tmp/nhimy-home-package/project/public/js/core/work/development.js
/tmp/nhimy-home-package/project/public/js/core/work/flow.js
/tmp/nhimy-home-package/project/public/js/core/work/intelligence.js
/tmp/nhimy-home-package/project/public/js/core/work/research.js
/tmp/nhimy-home-package/project/public/js/core/work/storage.before-orientation.js
/tmp/nhimy-home-package/project/public/js/core/work/storage.before-project-schema.js
/tmp/nhimy-home-package/project/public/js/core/work/storage.js
/tmp/nhimy-home-package/project/public/js/core/work/structure.before-research-integration.js
/tmp/nhimy-home-package/project/public/js/core/work/structure.before-rules.js
/tmp/nhimy-home-package/project/public/js/core/work/structure.js
/tmp/nhimy-home-package/project/public/js/core/work/writing.before-section-contract.bak
/tmp/nhimy-home-package/project/public/js/core/work/writing.before-section-match-fix.20260901-110819.bak
/tmp/nhimy-home-package/project/public/js/core/work/writing.js
/tmp/nhimy-home-package/project/public/js/modules/calculator.js
/tmp/nhimy-home-package/project/public/js/modules/converter.js
/tmp/nhimy-home-package/project/public/js/modules/generator.js
/tmp/nhimy-home-package/project/public/js/modules/image-compressor.js
/tmp/nhimy-home-package/project/public/js/modules/image-resizer.js
/tmp/nhimy-home-package/project/public/js/modules/json.js
/tmp/nhimy-home-package/project/public/js/modules/password.js
/tmp/nhimy-home-package/project/public/js/modules/pdf.js
/tmp/nhimy-home-package/project/public/js/modules/qr.js
/tmp/nhimy-home-package/project/public/js/modules/text.js
/tmp/nhimy-home-package/project/public/js/modules/url.js
/tmp/nhimy-home-package/project/public/js/ui/clipboard.js
/tmp/nhimy-home-package/project/public/js/ui/messages.js
/tmp/nhimy-home-package/project/public/js/ui/navigation.js
/tmp/nhimy-home-package/project/public/organizar/agenda/app.js
/tmp/nhimy-home-package/project/public/organizar/agenda/app.js.bak
/tmp/nhimy-home-package/project/public/organizar/agenda/index.html
/tmp/nhimy-home-package/project/public/organizar/agenda/style.css
/tmp/nhimy-home-package/project/public/organizar/app.js
/tmp/nhimy-home-package/project/public/organizar/index.html
/tmp/nhimy-home-package/project/public/organizar/index.html.bak
/tmp/nhimy-home-package/project/public/organizar/metas/app.js
/tmp/nhimy-home-package/project/public/organizar/metas/index.html
/tmp/nhimy-home-package/project/public/organizar/metas/style.css
/tmp/nhimy-home-package/project/public/organizar/notas/app.js
/tmp/nhimy-home-package/project/public/organizar/notas/index.html
/tmp/nhimy-home-package/project/public/organizar/notas/style.css
/tmp/nhimy-home-package/project/public/organizar/style.css
/tmp/nhimy-home-package/project/public/organizar/style.css.bak
/tmp/nhimy-home-package/project/public/organizar/tarefas/app.js
/tmp/nhimy-home-package/project/public/organizar/tarefas/index.html
/tmp/nhimy-home-package/project/public/organizar/tarefas/style.css
/tmp/nhimy-home-package/project/public/pages/institucional/contacto.html
/tmp/nhimy-home-package/project/public/pages/institucional/privacidade.html
/tmp/nhimy-home-package/project/public/pages/institucional/sobre.html
/tmp/nhimy-home-package/project/public/pages/institucional/termos.html
/tmp/nhimy-home-package/project/public/style.css
/tmp/nhimy-home-package/project/public/style.css.before-cap-only
/tmp/nhimy-home-package/project/public/style.css.before-n-fix
/tmp/nhimy-home-package/project/public/style.css.before-signature-3
/tmp/nhimy-home-package/project/public/style.css.before-signature-3-css
/tmp/nhimy-home-package/project/public/style.css.signature-v2.bak
/tmp/nhimy-home-package/project/public/trabalhos/criar/app.before-cleanup.js
/tmp/nhimy-home-package/project/public/trabalhos/criar/app.before-flow.js
/tmp/nhimy-home-package/project/public/trabalhos/criar/app.before-orientacao.js
/tmp/nhimy-home-package/project/public/trabalhos/criar/app.before-project-schema.js
/tmp/nhimy-home-package/project/public/trabalhos/criar/app.js
/tmp/nhimy-home-package/project/public/trabalhos/criar/index.before-cleanup.html
/tmp/nhimy-home-package/project/public/trabalhos/criar/index.before-flow-ui.html
/tmp/nhimy-home-package/project/public/trabalhos/criar/index.before-orientacao.html
/tmp/nhimy-home-package/project/public/trabalhos/criar/index.html
/tmp/nhimy-home-package/project/public/trabalhos/desenvolver/app.before-flow.js
/tmp/nhimy-home-package/project/public/trabalhos/desenvolver/app.js
/tmp/nhimy-home-package/project/public/trabalhos/desenvolver/desenvolver.css
/tmp/nhimy-home-package/project/public/trabalhos/desenvolver/index.before-flow-ui.html
/tmp/nhimy-home-package/project/public/trabalhos/desenvolver/index.html
/tmp/nhimy-home-package/project/public/trabalhos/estruturar/app.before-flow.js
/tmp/nhimy-home-package/project/public/trabalhos/estruturar/app.before-research-integration.js
/tmp/nhimy-home-package/project/public/trabalhos/estruturar/app.before-structure-suggestions.js
/tmp/nhimy-home-package/project/public/trabalhos/estruturar/app.js
/tmp/nhimy-home-package/project/public/trabalhos/estruturar/index.before-flow-ui.html
/tmp/nhimy-home-package/project/public/trabalhos/estruturar/index.before-smart-ui.html
/tmp/nhimy-home-package/project/public/trabalhos/estruturar/index.html
/tmp/nhimy-home-package/project/public/trabalhos/finalizar/app.before-flow.js
/tmp/nhimy-home-package/project/public/trabalhos/finalizar/app.js
/tmp/nhimy-home-package/project/public/trabalhos/finalizar/finalizar.css
/tmp/nhimy-home-package/project/public/trabalhos/finalizar/index.before-flow-ui.html
/tmp/nhimy-home-package/project/public/trabalhos/finalizar/index.html
/tmp/nhimy-home-package/project/public/trabalhos/index.before-visual.css.html
/tmp/nhimy-home-package/project/public/trabalhos/index.html
/tmp/nhimy-home-package/project/public/trabalhos/orientar/app.before-auto-flow.js
/tmp/nhimy-home-package/project/public/trabalhos/orientar/app.before-dynamic-orientation.js
/tmp/nhimy-home-package/project/public/trabalhos/orientar/app.before-flexible-context.js
/tmp/nhimy-home-package/project/public/trabalhos/orientar/app.before-flow.js
/tmp/nhimy-home-package/project/public/trabalhos/orientar/app.js
/tmp/nhimy-home-package/project/public/trabalhos/orientar/index.before-dynamic-orientation.html
/tmp/nhimy-home-package/project/public/trabalhos/orientar/index.before-flow-ui.html
/tmp/nhimy-home-package/project/public/trabalhos/orientar/index.html
/tmp/nhimy-home-package/project/public/trabalhos/revisar/app.before-flow.js
/tmp/nhimy-home-package/project/public/trabalhos/revisar/app.js
/tmp/nhimy-home-package/project/public/trabalhos/revisar/index.before-flow-ui.html
/tmp/nhimy-home-package/project/public/trabalhos/revisar/index.html
/tmp/nhimy-home-package/project/public/trabalhos/revisar/revisar.css
/tmp/nhimy-home-package/project/public/trabalhos/trabalhos.before-flow-ui.css
/tmp/nhimy-home-package/project/public/trabalhos/trabalhos.before-orientation-form.css
/tmp/nhimy-home-package/project/public/trabalhos/trabalhos.css
/tmp/nhimy-home-package/project/server.js

===== NODE =====
v22.23.2
10.9.1

===== CHECKS =====
OK  server.js
OK  public/app.js
OK  public/js/core/app.js
OK  public/js/core/home/index.js
OK  public/js/core/home/state.js

===== HOME REFERENCES =====

===== SEGURANÇA =====
Arquivos .env excluídos.
node_modules excluído.
.git excluído.
